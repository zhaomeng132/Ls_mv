clear all
close all
cd ~/downloads/SS

wtnaadp1 = readtable('WT+NAADP 1.xlsx');
wtnaadp2 = readtable('WT+NAADP 2.xlsx');
konaadp1 = readtable('KO+NAADP 1.xlsx');
konaadp2 = readtable('KO+NAADP 2.xlsx');
wtkn93naadp = readtable('WT+KN93+NAADP.xlsx');
wtiso = readtable('WT+Iso.xlsx');
koiso = readtable('KO+Iso.xlsx');

wtnaadp1_ctrl = wtnaadp1.Control;
wtnaadp1_ctrl = (wtnaadp1_ctrl(~isnan(wtnaadp1_ctrl)));

wtnaadp1_naadp = wtnaadp1.x5MinAfterNAADP_AM;
wtnaadp1_naadp = (wtnaadp1_naadp(~isnan(wtnaadp1_naadp)));

mkdir(['./','fig1'])
cd(['./','fig1'])

figure(1)
plot(linspace(1,1000,numel(wtnaadp1_ctrl)),wtnaadp1_ctrl,'k');
hold on
plot(linspace(1,1000,numel(wtnaadp1_naadp)),wtnaadp1_naadp,'r'); 
hold off
ylabel({'Ca^{2+} transient (F/F0)'});xlabel('Time (ms)');     
legend({'WT','NAADP-AM'})
legend boxoff   
ylim([0 9.5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%     ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('F2-1exp'),'-dpng','-r300');
close 

konaadp1_ctrl = konaadp1.Control;
konaadp1_ctrl = (konaadp1_ctrl(~isnan(konaadp1_ctrl)));

konaadp1_naadp = konaadp1.x5MinAfterNAADP_AM;
konaadp1_naadp = (konaadp1_naadp(~isnan(konaadp1_naadp)));

figure(2)
plot(linspace(1,1000,numel(konaadp1_ctrl)),konaadp1_ctrl,'Color','#0000ff');
hold on
plot(linspace(1,1000,numel(konaadp1_naadp)),konaadp1_naadp,'Color','#1f7a1f'); 
hold off
ylabel({'Ca^{2+} transient (F/F0)'});xlabel('Time (ms)');     
legend({'\it Tpcn2^{-/-}','NAADP-AM'})
legend boxoff   
ylim([0 9.5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%     ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('F2-2exp'),'-dpng','-r300');
close 
%%
wtiso_ctrl = wtiso.Control;
wtiso_ctrl = (wtiso_ctrl(~isnan(wtiso_ctrl)));

wtiso_iso = wtiso.Iso;
wtiso_iso = (wtiso_iso(~isnan(wtiso_iso)));

figure(3)
plot(linspace(1,1000,numel(wtiso_ctrl)),wtiso_ctrl,'k');
hold on
plot(linspace(1,1000,numel(wtiso_iso)),wtiso_iso,'r'); 
hold off
ylabel({'Ca^{2+} transient (F/F0)'});xlabel('Time (ms)');   
legend({'WT','ISO'})
legend boxoff   
ylim([0 9.5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%     ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
% saveas(gcf,sprintf('%s fig1-3.png',protocol{P}))
print(gcf,fullfile('F2-3exp'),'-dpng','-r300');


koiso_ctrl = koiso.Control;
koiso_ctrl = (koiso_ctrl(~isnan(koiso_ctrl)));

koiso_iso = koiso.Iso;
koiso_iso = (koiso_iso(~isnan(koiso_iso)));

figure(4)
plot(linspace(1,1000,numel(koiso_ctrl)),koiso_ctrl,'Color','#0000ff');
hold on
plot(linspace(1,1000,numel(koiso_iso)),koiso_iso,'Color','#1f7a1f'); 
hold off
ylabel({'Ca^{2+} transient (F/F0)'});xlabel('Time (ms)');     
legend({'\it Tpcn2^{-/-}','ISO'})
legend boxoff   
ylim([0 9.5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%     ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
% saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
print(gcf,fullfile('F2-4exp'),'-dpng','-r300');
close all


%%
% figure(5)
% plot(p1ot,p1oy(:,39),'Color','#0000ff');
% hold on
% plot(p3ot,p3oy(:,39),'Color','#1f7a1f'); 
% hold off
% ylabel('Vm (mV)');xlabel('Time (ms)');
% legend({'TPC-KO','ISO'})
% legend boxoff   
% xlim([0 50])
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-5.png',protocol{P}))
% print(gcf,fullfile('F2-5'),'-dpng','-r300');
% 
% 
% figure(6)
% plot(p1wt,p1wy(:,39),'k');
% hold on
% plot(p3wt,p3wy(:,39),'r'); 
% hold off
% ylabel('Vm (mV)');xlabel('Time (ms)');
% legend({'WT','ISO'})
% legend boxoff   
% xlim([0 50])
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-6.png',protocol{P}))
% print(gcf,fullfile('F2-6'),'-dpng','-r300');

%%
% wt_naadp = wtkn93naadp.NAADP_AM;
% wt_naadp = (wt_naadp(~isnan(wt_naadp)));
% 
% kn93_naadp = wtkn93naadp.x5MinAfterNAADP_AMInThePresenceOfKN93;
% kn93_naadp = (kn93_naadp(~isnan(kn93_naadp)));
% 
% figure(7)
% plot(linspace(1,1000,numel(wt_naadp)),wt_naadp,'Color','#0000ff');
% hold on
% plot(linspace(1,1000,numel(kn93_naadp)),kn93_naadp,'Color','#1f7a1f'); 
% hold off
% ylabel({'Ca^{2+} transient (F/F0)'});xlabel('Time (ms)'); 
% legend({'KN93','KN93 + NAADP-AM'})
% legend boxoff   
% ylim([0 9.5])
% % ax = gca;
% %     ax.YAxis.Exponent = 2;
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
% print(gcf,fullfile('F2-7exp'),'-dpng','-r300');

close all