clear all
close all

cd ~/downloads/SS/h1_cao1_p123_
load h1_cao1_sf1000_sf343_0.mat
addpath('~/downloads/SS/h50_cao1_p3_')

% herz10
cd ~/downloads/SS/h50_cao1_p3_/h10_cao1_p3__sf1000
load h10_iTPC1.mat
iTPC_1 = h10_iTPC1;
load h10_inoneTPC1.mat
inoneTPC_1 = h10_inoneTPC1;
load h10_inone_0.mat
inone_0 = h10_inone_0;

load h10_beat2_w_1.mat
load h10_beat3_w_1.mat
load h10_beat4_w_1.mat
load h10_beat5_w_1.mat

iTPC_per_2 = numel(intersect(h10_beat2_w_1,iTPC_1));
iTPC_per_3 = numel(intersect(h10_beat3_w_1,iTPC_1));
iTPC_per_4 = numel(intersect(h10_beat4_w_1,iTPC_1));
iTPC_per_5 = numel(intersect(h10_beat5_w_1,iTPC_1));

inoneTPC_1_per_2 = numel(intersect(h10_beat2_w_1,inoneTPC_1));
inoneTPC_1_per_3 = numel(intersect(h10_beat3_w_1,inoneTPC_1));
inoneTPC_1_per_4 = numel(intersect(h10_beat4_w_1,inoneTPC_1));
inoneTPC_1_per_5 = numel(intersect(h10_beat5_w_1,inoneTPC_1));

% cd ~/downloads/SS/h50_cao1_p3_/
% mkdir(['./','h10_nobump'])
% cd(['./','h10_nobump'])

cd ~/downloads/SS/
mkdir(['./','figs3'])
cd(['./','figs3'])
%%
rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                     % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);

sf343 = sf(h1_cao1_sf1000_sf343_0,:);
sf_TPC_1 = sf343(iTPC_1,:);
sf_noneTPC_1 = sf343(inoneTPC_1,:);
sf_none_0 = sf343(inone_0,:);


bx = [
     sf_noneTPC_1(:,1);sf_TPC_1(:,1);sf_none_0(:,1);...
     sf_noneTPC_1(:,2);sf_TPC_1(:,2);sf_none_0(:,2);...
     sf_noneTPC_1(:,3);sf_TPC_1(:,3);sf_none_0(:,3);...
     sf_noneTPC_1(:,4);sf_TPC_1(:,4);sf_none_0(:,4);...
     sf_noneTPC_1(:,5);sf_TPC_1(:,5);sf_none_0(:,5);...
     sf_noneTPC_1(:,6);sf_TPC_1(:,6);sf_none_0(:,6);...
     sf_noneTPC_1(:,7);sf_TPC_1(:,7);sf_none_0(:,7);...
     sf_noneTPC_1(:,8);sf_TPC_1(:,8);sf_none_0(:,8);...
     sf_noneTPC_1(:,9);sf_TPC_1(:,9);sf_none_0(:,9);...
     ];
 
 
by = [ zeros(length(sf_noneTPC_1), 1);1*ones(length([sf_TPC_1]), 1);2*ones(length([sf_none_0]), 1);... 
       3*ones(length([sf_noneTPC_1]), 1);4*ones(length([sf_TPC_1]), 1);5*ones(length([sf_none_0]), 1);... 
       6*ones(length([sf_noneTPC_1]), 1);7*ones(length([sf_TPC_1]), 1);8*ones(length([sf_none_0]), 1);... 
       9*ones(length([sf_noneTPC_1]), 1);10*ones(length([sf_TPC_1]), 1);11*ones(length([sf_none_0]), 1);...
       12*ones(length([sf_noneTPC_1]), 1);13*ones(length([sf_TPC_1]), 1);14*ones(length([sf_none_0]), 1);... 
       15*ones(length([sf_noneTPC_1]), 1);16*ones(length([sf_TPC_1]), 1);17*ones(length([sf_none_0]), 1);...
       18*ones(length([sf_noneTPC_1]), 1);19*ones(length([sf_TPC_1]), 1);20*ones(length([sf_none_0]), 1);...
       21*ones(length([sf_noneTPC_1]), 1);22*ones(length([sf_TPC_1]), 1);23*ones(length([sf_none_0]), 1);...
       24*ones(length([sf_noneTPC_1]), 1);25*ones(length([sf_TPC_1]), 1);26*ones(length([sf_none_0]), 1);...
     ];

figure(1);
boxplot(bx,by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
ylabel({'Variations of Conductances'})
ylim([0.5 3])
set(gca,'TickLabelInterpreter','Tex')
lbl= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
set(gca,'xticklabel',lbl)
set(gca,'xtick',2:3:26)
set(gca,'ytick',0.5:0.5:2)
set(gca,'box','off');
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast');legend boxoff
 
set(gca, 'FontName','Times New Roman','FontSize',35)
% title({'10Hz Fast Pacing and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 1500 600])
print(gcf, fullfile(pwd, 'bp_h10'),'-dpng','-r300')
% close

% ncx - cal
ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,7))
ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,7))
ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,7))
    
% ncx - ryr
ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,5))
ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,5))
ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,5))
    
% ncx - serca
ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,4))
ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,4))
ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,4))
%%
addpath('~/downloads/SS/h50_cao1_p3_')
cd ~/downloads/SS/h50_cao1_p3_/h10_cao1_p3__sf1000
load y175_WT_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3w
S = S(h1_cao1_sf1000_sf343_0);
S3w_TPC_1 = S(iTPC_1);
S3w_noneTPC_1 = S(inoneTPC_1);
S3w_none_0  = S(inone_0);

load y175_j_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wj
S = S(h1_cao1_sf1000_sf343_0);
S3j_TPC_1 = S(iTPC_1);
S3j_noneTPC_1 = S(inoneTPC_1);
S3j_none_0  = S(inone_0);

load y175_i_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wi
S = S(h1_cao1_sf1000_sf343_0);
S3i_TPC_1 = S(iTPC_1);
S3i_noneTPC_1 = S(inoneTPC_1);
S3i_none_0  = S(inone_0);

cd ~/downloads/SS/h50_cao1_p3_/h10_cao1_p3__sf1000/h10_cao1_p3_sf1000_FLUX
load y175_FLUX_WT_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3w
F = F(h1_cao1_sf1000_sf343_0);
F3wt_TPC_1 = F(iTPC_1);
F3wt_noneTPC_1 = F(inoneTPC_1);
F3wt_none_0  = F(inone_0);

load y175_FLUX_j_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wj
F = F(h1_cao1_sf1000_sf343_0);
F3j_TPC_1 = F(iTPC_1);
F3j_noneTPC_1 = F(inoneTPC_1);
F3j_none_0  = F(inone_0);

load y175_FLUX_i_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wi
F = F(h1_cao1_sf1000_sf343_0);
F3i_TPC_1 = F(iTPC_1);
F3i_noneTPC_1 = F(inoneTPC_1);
F3i_none_0  = F(inone_0);

% cd ~/downloads/SS/h50_cao1_p3_/
% mkdir(['./','h10_nobump'])
% cd(['./','h10_nobump'])

cd ~/downloads/SS/
mkdir(['./','figs3'])
cd(['./','figs3'])
%%
close all
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36]; 
%%            17        18     19       20       21             22            23               24       25       26
    T1 = [0 1e3];
    T2 = [1e3 2e3];
    T3 = [2e3 3e3];
    T4 = [3e3 4e3];
    T5 = [4e3 5e3];
 
    ratio = 200;
    calratio = 100;
    ncxratio = 40;
    ryrratio = 500;  %250
    srratio = 10000; %10000
    ls2jratio = 40;
    ls2iratio = 44;
    lsratio = 100;
% wt  
for ipeak = 1:numel(S3w_TPC_1)   
    t1_1 = S3w_TPC_1(ipeak).t;
    y38_1= S3w_TPC_1(ipeak).y(:,38).*1e6;
    y31= S3w_TPC_1(ipeak).y(:,31).*1e6;
    y88= S3w_TPC_1(ipeak).y(:,88).*1e6;
    y36= S3w_TPC_1(ipeak).y(:,36).*1e6;
    y37= S3w_TPC_1(ipeak).y(:,37).*1e6;
    
    tf = F3wt_TPC_1(ipeak).tArray;
    yserca = F3wt_TPC_1(ipeak).Jserca.*1e6;    
    yryr = F3wt_TPC_1(ipeak).J_RyR.*1e6;    
    ycal = abs(F3wt_TPC_1(ipeak).I_Ca_store);    
    yncx = F3wt_TPC_1(ipeak).Incx;    
    yls2j = F3wt_TPC_1(ipeak).JLS2J.*1e6;    
    yls2i = F3wt_TPC_1(ipeak).JLS2I.*1e6;  
%     yjuca = F3wt_TPC_1(ipeak).currents(:,7);   
%     yjusl = F3wt_TPC_1(ipeak).currents(:,8);   
    yjuca = F3wt_TPC_1(ipeak).currents(:,11);   
    yjusl = F3wt_TPC_1(ipeak).currents(:,12);       
    yjucal = F3wt_TPC_1(ipeak).currents(:,9);  
    
%  - find amp, timepoint of beat 2   
    owt_TPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
    owt_TPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    owt_TPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    owt_TPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    owt_TPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    owt_TPC_1y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
    
    owt_TPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    owt_TPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    owt_TPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    owt_TPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    owt_TPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    owt_TPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
    owt_TPC_1juca_b2(ipeak) = peak_marker(tf,T2,yjuca,calratio);   
    owt_TPC_1jusl_b2(ipeak) = peak_marker(tf,T2,yjusl,ncxratio); 
    owt_TPC_1jucal_b2(ipeak) = peak_marker(tf,T2,yjucal,calratio);
    
%  - find amp, timepoint of beat 3   
    owt_TPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
    owt_TPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    owt_TPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
    owt_TPC_1y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    owt_TPC_1y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
    
    owt_TPC_1y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);
    
    owt_TPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    owt_TPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    owt_TPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    owt_TPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    owt_TPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    owt_TPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);
    owt_TPC_1juca_b3(ipeak) = peak_marker(tf,T3,yjuca,calratio);   
    owt_TPC_1jusl_b3(ipeak) = peak_marker(tf,T3,yjusl,ncxratio); 
    owt_TPC_1jucal_b3(ipeak) = peak_marker(tf,T3,yjucal,calratio);
    
%  - find amp, timepoint of beat 4   
    owt_TPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
    owt_TPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    owt_TPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    owt_TPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    owt_TPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
    
    owt_TPC_1y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);    
 
    owt_TPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    owt_TPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    owt_TPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    owt_TPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    owt_TPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    owt_TPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio); 
    owt_TPC_1juca_b4(ipeak) = peak_marker(tf,T4,yjuca,calratio);   
    owt_TPC_1jusl_b4(ipeak) = peak_marker(tf,T4,yjusl,ncxratio); 
    owt_TPC_1jucal_b4(ipeak) = peak_marker(tf,T4,yjucal,calratio);
    
%  - find amp, timepoint of beat 5   
    owt_TPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
    owt_TPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    owt_TPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    owt_TPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    owt_TPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
    
    owt_TPC_1y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);
    
    owt_TPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    owt_TPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    owt_TPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    owt_TPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    owt_TPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    owt_TPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);   
    owt_TPC_1juca_b5(ipeak) = peak_marker(tf,T5,yjuca,calratio);   
    owt_TPC_1jusl_b5(ipeak) = peak_marker(tf,T5,yjusl,ncxratio);
    owt_TPC_1jucal_b5(ipeak) = peak_marker(tf,T5,yjucal,calratio);
end    
%%
for ipeak = 1:numel(S3w_TPC_1)   
    
t1_1 = S3w_TPC_1(ipeak).t;
y31= S3w_TPC_1(ipeak).y(:,31).*1e6;

[~,t2ind] = min(abs(t1_1-T2(1)));
[~,t3ind] = min(abs(t1_1-T3(1)));
[~,t4ind] = min(abs(t1_1-T4(1)));
[~,t5ind] = min(abs(t1_1-T5(1)));

figure(1)    
plot(t1_1,y31);hold on
% plot(t1_1(t2ind+owt_TPC_1y31_y36_b2(ipeak).valleyI),y31(t2ind+owt_TPC_1y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+owt_TPC_1y31_y36_b3(ipeak).valleyI),y31(t3ind+owt_TPC_1y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+owt_TPC_1y31_y36_b4(ipeak).valleyI),y31(t4ind+owt_TPC_1y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+owt_TPC_1y31_y36_b5(ipeak).valleyI),y31(t5ind+owt_TPC_1y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
end
%%
for ipeak = 1:numel(S3w_noneTPC_1)   
    t1_1 = S3w_noneTPC_1(ipeak).t;
    y38_1= S3w_noneTPC_1(ipeak).y(:,38).*1e6;
    y31= S3w_noneTPC_1(ipeak).y(:,31).*1e6;
    y88= S3w_noneTPC_1(ipeak).y(:,88).*1e6;
    y36= S3w_noneTPC_1(ipeak).y(:,36).*1e6;
    y37= S3w_noneTPC_1(ipeak).y(:,37).*1e6;
    
    tf = F3wt_noneTPC_1(ipeak).tArray;
    yserca = F3wt_noneTPC_1(ipeak).Jserca.*1e6;    
    yryr = F3wt_noneTPC_1(ipeak).J_RyR.*1e6;    
    ycal = abs(F3wt_noneTPC_1(ipeak).I_Ca_store);    
    yncx = F3wt_noneTPC_1(ipeak).Incx;    
    yls2j = F3wt_noneTPC_1(ipeak).JLS2J.*1e6;    
    yls2i = F3wt_noneTPC_1(ipeak).JLS2I.*1e6;  
%     yjuca = F3wt_noneTPC_1(ipeak).currents(:,7);   
%     yjusl = F3wt_noneTPC_1(ipeak).currents(:,8);   
    yjuca = F3wt_noneTPC_1(ipeak).currents(:,11);   
    yjusl = F3wt_noneTPC_1(ipeak).currents(:,12);   
    yjucal = F3wt_noneTPC_1(ipeak).currents(:,9);    
    
%  - find amp, timepoint of beat 2   
    owt_noneTPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
    owt_noneTPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    owt_noneTPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    owt_noneTPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    owt_noneTPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    owt_noneTPC_1y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
    
    owt_noneTPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    owt_noneTPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    owt_noneTPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    owt_noneTPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    owt_noneTPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    owt_noneTPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
    owt_noneTPC_1juca_b2(ipeak) = peak_marker(tf,T2,yjuca,calratio);   
    owt_noneTPC_1jusl_b2(ipeak) = peak_marker(tf,T2,yjusl,ncxratio); 
    owt_noneTPC_1jucal_b2(ipeak) = peak_marker(tf,T2,yjucal,calratio); 
    
%  - find amp, timepoint of beat 3   
    owt_noneTPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
    owt_noneTPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    owt_noneTPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
    owt_noneTPC_1y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    owt_noneTPC_1y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
    
    owt_noneTPC_1y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);
    
    owt_noneTPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    owt_noneTPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    owt_noneTPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    owt_noneTPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    owt_noneTPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    owt_noneTPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
    owt_noneTPC_1juca_b3(ipeak) = peak_marker(tf,T3,yjuca,calratio);   
    owt_noneTPC_1jusl_b3(ipeak) = peak_marker(tf,T3,yjusl,ncxratio); 
    owt_noneTPC_1jucal_b3(ipeak) = peak_marker(tf,T3,yjucal,calratio); 
    
%  - find amp, timepoint of beat 4   
    owt_noneTPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
    owt_noneTPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    owt_noneTPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    owt_noneTPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    owt_noneTPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
 
    owt_noneTPC_1y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);
    
    owt_noneTPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    owt_noneTPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    owt_noneTPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    owt_noneTPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    owt_noneTPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    owt_noneTPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);
    owt_noneTPC_1juca_b4(ipeak) = peak_marker(tf,T4,yjuca,calratio);   
    owt_noneTPC_1jusl_b4(ipeak) = peak_marker(tf,T4,yjusl,ncxratio); 
    owt_noneTPC_1jucal_b4(ipeak) = peak_marker(tf,T4,yjucal,calratio);     
    
%  - find amp, timepoint of beat 5   
    owt_noneTPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
    owt_noneTPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    owt_noneTPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    owt_noneTPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    owt_noneTPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
    
    owt_noneTPC_1y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);
 
    owt_noneTPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    owt_noneTPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    owt_noneTPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    owt_noneTPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    owt_noneTPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    owt_noneTPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);    
    owt_noneTPC_1juca_b5(ipeak) = peak_marker(tf,T5,yjuca,calratio);   
    owt_noneTPC_1jusl_b5(ipeak) = peak_marker(tf,T5,yjusl,ncxratio);
    owt_noneTPC_1jucal_b5(ipeak) = peak_marker(tf,T5,yjucal,calratio); 
end   
%%
for ipeak = 1:numel(S3w_noneTPC_1)   
    
t1_1 = S3w_noneTPC_1(ipeak).t;
y31= S3w_noneTPC_1(ipeak).y(:,31).*1e6;

[~,t2ind] = min(abs(t1_1-T2(1)));
[~,t3ind] = min(abs(t1_1-T3(1)));
[~,t4ind] = min(abs(t1_1-T4(1)));
[~,t5ind] = min(abs(t1_1-T5(1)));

figure(2)    
plot(t1_1,y31);hold on
% plot(t1_1(t2ind+owt_noneTPC_1y31_y36_b2(ipeak).valleyI),y31(t2ind+owt_noneTPC_1y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+owt_noneTPC_1y31_y36_b3(ipeak).valleyI),y31(t3ind+owt_noneTPC_1y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+owt_noneTPC_1y31_y36_b4(ipeak).valleyI),y31(t4ind+owt_noneTPC_1y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+owt_noneTPC_1y31_y36_b5(ipeak).valleyI),y31(t5ind+owt_noneTPC_1y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
end
%%
for ipeak = 1:numel(S3w_none_0)   
    t1_1 = S3w_none_0(ipeak).t;
    y38_1= S3w_none_0(ipeak).y(:,38).*1e6;
    y31= S3w_none_0(ipeak).y(:,31).*1e6;
    y88= S3w_none_0(ipeak).y(:,88).*1e6;
    y36= S3w_none_0(ipeak).y(:,36).*1e6;
    y37= S3w_none_0(ipeak).y(:,37).*1e6;
    
    tf = F3wt_none_0(ipeak).tArray;
    yserca = F3wt_none_0(ipeak).Jserca.*1e6;    
    yryr = F3wt_none_0(ipeak).J_RyR.*1e6;    
    ycal = abs(F3wt_none_0(ipeak).I_Ca_store);    
    yncx = F3wt_none_0(ipeak).Incx;    
    yls2j = F3wt_none_0(ipeak).JLS2J.*1e6;    
    yls2i = F3wt_none_0(ipeak).JLS2I.*1e6;  
%     yjuca = F3wt_none_0(ipeak).currents(:,7);   
%     yjusl = F3wt_none_0(ipeak).currents(:,8);   
    yjuca = F3wt_none_0(ipeak).currents(:,11);   
    yjusl = F3wt_none_0(ipeak).currents(:,12);    
    yjucal = F3wt_none_0(ipeak).currents(:,9);    
    
%  - find amp, timepoint of beat 2   
    owt_none_0y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
    owt_none_0y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    owt_none_0y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    owt_none_0y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    owt_none_0y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    owt_none_0y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
        
    owt_none_0ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    owt_none_0ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    owt_none_0serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    owt_none_0ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    owt_none_0cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    owt_none_0ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio);
    owt_none_0juca_b2(ipeak) = peak_marker(tf,T2,yjuca,calratio);   
    owt_none_0jusl_b2(ipeak) = peak_marker(tf,T2,yjusl,ncxratio); 
    owt_none_0jucal_b2(ipeak) = peak_marker(tf,T2,yjucal,calratio); 
    
%  - find amp, timepoint of beat 3   
    owt_none_0y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
    owt_none_0y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    owt_none_0y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
    owt_none_0y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    owt_none_0y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
    
    owt_none_0y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);
    
    owt_none_0ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    owt_none_0ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    owt_none_0serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    owt_none_0ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    owt_none_0cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    owt_none_0ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);  
    owt_none_0juca_b3(ipeak) = peak_marker(tf,T3,yjuca,calratio);   
    owt_none_0jusl_b3(ipeak) = peak_marker(tf,T3,yjusl,ncxratio); 
    owt_none_0jucal_b3(ipeak) = peak_marker(tf,T3,yjucal,calratio); 
    
%  - find amp, timepoint of beat 4   
    owt_none_0y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
    owt_none_0y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    owt_none_0y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    owt_none_0y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    owt_none_0y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
    
    owt_none_0y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);
 
    owt_none_0ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    owt_none_0ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    owt_none_0serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    owt_none_0ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    owt_none_0cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    owt_none_0ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);  
    owt_none_0juca_b4(ipeak) = peak_marker(tf,T4,yjuca,calratio);   
    owt_none_0jusl_b4(ipeak) = peak_marker(tf,T4,yjusl,ncxratio); 
    owt_none_0jucal_b4(ipeak) = peak_marker(tf,T4,yjucal,calratio); 
    
%  - find amp, timepoint of beat 5   
    owt_none_0y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
    owt_none_0y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    owt_none_0y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    owt_none_0y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    owt_none_0y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
    
    owt_none_0y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);
 
    owt_none_0ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    owt_none_0ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    owt_none_0serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    owt_none_0ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    owt_none_0cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    owt_none_0ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio); 
    owt_none_0juca_b5(ipeak) = peak_marker(tf,T5,yjuca,calratio);   
    owt_none_0jusl_b5(ipeak) = peak_marker(tf,T5,yjusl,ncxratio); 
    owt_none_0jucal_b5(ipeak) = peak_marker(tf,T5,yjucal,calratio); 
end    
%%
for ipeak = 1:numel(S3w_none_0)   
    
t1_1 = S3w_none_0(ipeak).t;
y31= S3w_none_0(ipeak).y(:,31).*1e6;

[~,t2ind] = min(abs(t1_1-T2(1)));
[~,t3ind] = min(abs(t1_1-T3(1)));
[~,t4ind] = min(abs(t1_1-T4(1)));
[~,t5ind] = min(abs(t1_1-T5(1)));

figure(3)    
plot(t1_1,y31);hold on
% plot(t1_1(t2ind+owt_none_0y31_y36_b2(ipeak).valleyI),y31(t2ind+owt_none_0y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+owt_none_0y31_y36_b3(ipeak).valleyI),y31(t3ind+owt_none_0y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+owt_none_0y31_y36_b4(ipeak).valleyI),y31(t4ind+owt_none_0y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+owt_none_0y31_y36_b5(ipeak).valleyI),y31(t5ind+owt_none_0y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
end
%% errorbar y31
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1y31_y36_b2(:).integralY]),...
               mean([owt_TPC_1y31_y36_b3(:).integralY]),...
               mean([owt_TPC_1y31_y36_b4(:).integralY]),...
               mean([owt_TPC_1y31_y36_b5(:).integralY])];
err_owt_TPC1 = [std([owt_TPC_1y31_y36_b2(:).integralY])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b3(:).integralY])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b4(:).integralY])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b5(:).integralY])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_y36_b2(:).integralY]),...
                   mean([owt_noneTPC_1y31_y36_b3(:).integralY]),...
                   mean([owt_noneTPC_1y31_y36_b4(:).integralY]),...
                   mean([owt_noneTPC_1y31_y36_b5(:).integralY])];
err_owt_noneTPC1 = [std([owt_noneTPC_1y31_y36_b2(:).integralY])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b3(:).integralY])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b4(:).integralY])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b5(:).integralY])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0y31_y36_b2(:).integralY]),...
                mean([owt_none_0y31_y36_b3(:).integralY]),...
                mean([owt_none_0y31_y36_b4(:).integralY]),...
                mean([owt_none_0y31_y36_b5(:).integralY])];
err_owt_none0 = [std([owt_none_0y31_y36_b2(:).integralY])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b3(:).integralY])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b4(:).integralY])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b5(:).integralY])/sqrt(num_none0)];   
             
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 

ylim([2e7 15e7])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] SR (nM)'})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y31_integral'),'-dpng','-r300')
%% integral y31-y36
close all
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1y31_y36_b2(:).y31_y36_integral]),...
               mean([owt_TPC_1y31_y36_b3(:).y31_y36_integral]),...
               mean([owt_TPC_1y31_y36_b4(:).y31_y36_integral]),...
               mean([owt_TPC_1y31_y36_b5(:).y31_y36_integral])];
err_owt_TPC1 = [std([owt_TPC_1y31_y36_b2(:).y31_y36_integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b3(:).y31_y36_integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b4(:).y31_y36_integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y31_y36_b5(:).y31_y36_integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_y36_b2(:).y31_y36_integral]),...
                   mean([owt_noneTPC_1y31_y36_b3(:).y31_y36_integral]),...
                   mean([owt_noneTPC_1y31_y36_b4(:).y31_y36_integral]),...
                   mean([owt_noneTPC_1y31_y36_b5(:).y31_y36_integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1y31_y36_b2(:).y31_y36_integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b3(:).y31_y36_integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b4(:).y31_y36_integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y31_y36_b5(:).y31_y36_integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0y31_y36_b2(:).y31_y36_integral]),...
                mean([owt_none_0y31_y36_b3(:).y31_y36_integral]),...
                mean([owt_none_0y31_y36_b4(:).y31_y36_integral]),...
                mean([owt_none_0y31_y36_b5(:).y31_y36_integral])];
err_owt_none0 = [std([owt_none_0y31_y36_b2(:).y31_y36_integral])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b3(:).y31_y36_integral])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b4(:).y31_y36_integral])/sqrt(num_none0),...
                 std([owt_none_0y31_y36_b5(:).y31_y36_integral])/sqrt(num_none0)];   
 
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
 
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
 
ylim([3e7 12e7])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Difference of','Junction and SR (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
 
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y31_y36_integral'),'-dpng','-r300')
% close

% %% dad y31-y36
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1y31_y36_b2(:).y31_y36_dad_integral]),...
%                mean([owt_TPC_1y31_y36_b3(:).y31_y36_dad_integral]),...
%                mean([owt_TPC_1y31_y36_b4(:).y31_y36_dad_integral]),...
%                mean([owt_TPC_1y31_y36_b5(:).y31_y36_dad_integral])];
% err_owt_TPC1 = [std([owt_TPC_1y31_y36_b2(:).y31_y36_dad_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b3(:).y31_y36_dad_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b4(:).y31_y36_dad_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b5(:).y31_y36_dad_integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_y36_b2(:).y31_y36_dad_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b3(:).y31_y36_dad_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b4(:).y31_y36_dad_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b5(:).y31_y36_dad_integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1y31_y36_b2(:).y31_y36_dad_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b3(:).y31_y36_dad_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b4(:).y31_y36_dad_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b5(:).y31_y36_dad_integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0y31_y36_b2(:).y31_y36_dad_integral]),...
%                 mean([owt_none_0y31_y36_b3(:).y31_y36_dad_integral]),...
%                 mean([owt_none_0y31_y36_b4(:).y31_y36_dad_integral]),...
%                 mean([owt_none_0y31_y36_b5(:).y31_y36_dad_integral])];
% err_owt_none0 = [std([owt_none_0y31_y36_b2(:).y31_y36_dad_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b3(:).y31_y36_dad_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b4(:).y31_y36_dad_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b5(:).y31_y36_dad_integral])/sqrt(num_none0)];  
%              
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([0e7 6e7])
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Diastolic [Ca] Difference of','Junction and SR (nM)'});
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'y31_y36_dad'),'-dpng','-r300')
% 
% %% peak y31-y36
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1y31_y36_b2(:).y31_y36_peak_integral]),...
%                mean([owt_TPC_1y31_y36_b3(:).y31_y36_peak_integral]),...
%                mean([owt_TPC_1y31_y36_b4(:).y31_y36_peak_integral]),...
%                mean([owt_TPC_1y31_y36_b5(:).y31_y36_peak_integral])];
% err_owt_TPC1 = [std([owt_TPC_1y31_y36_b2(:).y31_y36_peak_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b3(:).y31_y36_peak_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b4(:).y31_y36_peak_integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_y36_b5(:).y31_y36_peak_integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_y36_b2(:).y31_y36_peak_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b3(:).y31_y36_peak_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b4(:).y31_y36_peak_integral]),...
%                    mean([owt_noneTPC_1y31_y36_b5(:).y31_y36_peak_integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1y31_y36_b2(:).y31_y36_peak_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b3(:).y31_y36_peak_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b4(:).y31_y36_peak_integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_y36_b5(:).y31_y36_peak_integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0y31_y36_b2(:).y31_y36_peak_integral]),...
%                 mean([owt_none_0y31_y36_b3(:).y31_y36_peak_integral]),...
%                 mean([owt_none_0y31_y36_b4(:).y31_y36_peak_integral]),...
%                 mean([owt_none_0y31_y36_b5(:).y31_y36_peak_integral])];
% err_owt_none0 = [std([owt_none_0y31_y36_b2(:).y31_y36_peak_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b3(:).y31_y36_peak_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b4(:).y31_y36_peak_integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_y36_b5(:).y31_y36_peak_integral])/sqrt(num_none0)];  
% 
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([1e7 8e7])
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Systolic [Ca] Difference of','Junction and SR (nM)'})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'y31_y36_peak'),'-dpng','-r300')
%% errorbar y88
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1y88_b2(:).integral]),...
               mean([owt_TPC_1y88_b3(:).integral]),...
               mean([owt_TPC_1y88_b4(:).integral]),...
               mean([owt_TPC_1y88_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1y88_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y88_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y88_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y88_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1y88_b2(:).integral]),...
                   mean([owt_noneTPC_1y88_b3(:).integral]),...
                   mean([owt_noneTPC_1y88_b4(:).integral]),...
                   mean([owt_noneTPC_1y88_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1y88_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y88_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y88_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y88_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0y88_b2(:).integral]),...
                mean([owt_none_0y88_b3(:).integral]),...
                mean([owt_none_0y88_b4(:).integral]),...
                mean([owt_none_0y88_b5(:).integral])];
err_owt_none0 = [std([owt_none_0y88_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y88_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y88_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y88_b5(:).integral])/sqrt(num_none0)];   
             
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
 
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
 
ylim([20e5 50e5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Lysosome (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
 
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'er_beat1_5_y88_beat_integral'),'-dpng','-r300')
% close

%% errorbar y38
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1y38_b2(:).integral]),...
               mean([owt_TPC_1y38_b3(:).integral]),...
               mean([owt_TPC_1y38_b4(:).integral]),...
               mean([owt_TPC_1y38_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1y38_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y38_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y38_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y38_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1y38_b2(:).integral]),...
                   mean([owt_noneTPC_1y38_b3(:).integral]),...
                   mean([owt_noneTPC_1y38_b4(:).integral]),...
                   mean([owt_noneTPC_1y38_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1y38_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y38_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y38_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y38_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0y38_b2(:).integral]),...
                mean([owt_none_0y38_b3(:).integral]),...
                mean([owt_none_0y38_b4(:).integral]),...
                mean([owt_none_0y38_b5(:).integral])];
err_owt_none0 = [std([owt_none_0y38_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y38_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y38_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y38_b5(:).integral])/sqrt(num_none0)];   
             
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 

ylim([5e4 50e4])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Cytosol (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'er_beat1_5_y38_beat_integral'),'-dpng','-r300')
% close

% %% errorbar y31
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1y31_b2(:).integral]),...
%                mean([owt_TPC_1y31_b3(:).integral]),...
%                mean([owt_TPC_1y31_b4(:).integral]),...
%                mean([owt_TPC_1y31_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1y31_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_b2(:).integral]),...
%                    mean([owt_noneTPC_1y31_b3(:).integral]),...
%                    mean([owt_noneTPC_1y31_b4(:).integral]),...
%                    mean([owt_noneTPC_1y31_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1y31_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b5(:).integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0y31_b2(:).integral]),...
%                 mean([owt_none_0y31_b3(:).integral]),...
%                 mean([owt_none_0y31_b4(:).integral]),...
%                 mean([owt_none_0y31_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0y31_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b5(:).integral])/sqrt(num_none0)];   
% 
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
% 
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% 
% ylim([2e7 15e7])
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] SR (nM)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
% 
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_y31_beat_integral'),'-dpng','-r300')
% % close

%% errorbar y36
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1y36_b2(:).integral]),...
               mean([owt_TPC_1y36_b3(:).integral]),...
               mean([owt_TPC_1y36_b4(:).integral]),...
               mean([owt_TPC_1y36_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1y36_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y36_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y36_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1y36_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1y36_b2(:).integral]),...
                   mean([owt_noneTPC_1y36_b3(:).integral]),...
                   mean([owt_noneTPC_1y36_b4(:).integral]),...
                   mean([owt_noneTPC_1y36_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1y36_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y36_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y36_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1y36_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0y36_b2(:).integral]),...
                mean([owt_none_0y36_b3(:).integral]),...
                mean([owt_none_0y36_b4(:).integral]),...
                mean([owt_none_0y36_b5(:).integral])];
err_owt_none0 = [std([owt_none_0y36_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y36_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y36_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0y36_b5(:).integral])/sqrt(num_none0)];
             
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 

ylim([4e6 10e6])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'er_beat1_4_y36_beat_integral'),'-dpng','-r300')
% close

% %% errorbar y37
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1y37_b2(:).integral]),...
%                mean([owt_TPC_1y37_b3(:).integral]),...
%                mean([owt_TPC_1y37_b4(:).integral]),...
%                mean([owt_TPC_1y37_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1y37_b2(:).integral])/sqrt(iTPC_per_2),...
%                 std([owt_TPC_1y37_b3(:).integral])/sqrt(iTPC_per_3),...
%                 std([owt_TPC_1y37_b4(:).integral])/sqrt(iTPC_per_4),...
%                 std([owt_TPC_1y37_b5(:).integral])/sqrt(iTPC_per_5)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1y37_b2(:).integral]),...
%                    mean([owt_noneTPC_1y37_b3(:).integral]),...
%                    mean([owt_noneTPC_1y37_b4(:).integral]),...
%                    mean([owt_noneTPC_1y37_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1y37_b2(:).integral])/sqrt(inoneTPC_1_per_2),...
%                     std([owt_noneTPC_1y37_b3(:).integral])/sqrt(inoneTPC_1_per_3),...
%                     std([owt_noneTPC_1y37_b4(:).integral])/sqrt(inoneTPC_1_per_4),...
%                     std([owt_noneTPC_1y37_b5(:).integral])/sqrt(inoneTPC_1_per_5)];   
%  
% ey_owt_none0 = [mean([owt_none_0y37_b2(:).integral]),...
%                 mean([owt_none_0y37_b3(:).integral]),...
%                 mean([owt_none_0y37_b4(:).integral]),...
%                 mean([owt_none_0y37_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0y37_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y37_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y37_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y37_b5(:).integral])/sqrt(num_none0)];
% 
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([4e5 12e5])
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Sarcolemma (nM)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_y37_beat_integral'),'-dpng','-r300')
% % close

% %% errorbar y31 -y36
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1y31_b2(:).integral] - [owt_TPC_1y36_b2(:).integral]),...
%                mean([owt_TPC_1y31_b3(:).integral] - [owt_TPC_1y36_b3(:).integral]),...
%                mean([owt_TPC_1y31_b4(:).integral] - [owt_TPC_1y36_b4(:).integral]),...
%                mean([owt_TPC_1y31_b5(:).integral] - [owt_TPC_1y36_b5(:).integral])];
%            
% err_owt_TPC1 = [std([owt_TPC_1y31_b2(:).integral] - [owt_TPC_1y36_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b3(:).integral] - [owt_TPC_1y36_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b4(:).integral] - [owt_TPC_1y36_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1y31_b5(:).integral] - [owt_TPC_1y36_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1y31_b2(:).integral] - [owt_noneTPC_1y36_b2(:).integral]),...
%                    mean([owt_noneTPC_1y31_b3(:).integral] - [owt_noneTPC_1y36_b3(:).integral]),...
%                    mean([owt_noneTPC_1y31_b4(:).integral] - [owt_noneTPC_1y36_b4(:).integral]),...
%                    mean([owt_noneTPC_1y31_b5(:).integral] - [owt_noneTPC_1y36_b5(:).integral])];
%                
% err_owt_noneTPC1 = [std([owt_noneTPC_1y31_b2(:).integral] - [owt_noneTPC_1y36_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b3(:).integral] - [owt_noneTPC_1y36_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b4(:).integral] - [owt_noneTPC_1y36_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1y31_b5(:).integral] - [owt_noneTPC_1y36_b5(:).integral])/sqrt(num_noneTPC1)];  
%                 
% ey_owt_none0 = [mean([owt_none_0y31_b2(:).integral] - [owt_none_0y36_b2(:).integral]),...
%                    mean([owt_none_0y31_b3(:).integral] - [owt_none_0y36_b3(:).integral]),...
%                    mean([owt_none_0y31_b4(:).integral] - [owt_none_0y36_b4(:).integral]),...
%                    mean([owt_none_0y31_b5(:).integral] - [owt_none_0y36_b5(:).integral])];
%                
% err_owt_none0 = [std([owt_none_0y31_b2(:).integral] - [owt_none_0y36_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b3(:).integral] - [owt_none_0y36_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b4(:).integral] - [owt_none_0y36_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0y31_b5(:).integral] - [owt_none_0y36_b5(:).integral])/sqrt(num_none0)];   
% 
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
% 
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% 
% ylim([2e7 15e7])
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
% 
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_y31-y36_beat_integral'),'-dpng','-r300')
% % close

%% errorbar serca
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1serca_b2(:).integral]),...
               mean([owt_TPC_1serca_b3(:).integral]),...
               mean([owt_TPC_1serca_b4(:).integral]),...
               mean([owt_TPC_1serca_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1serca_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1serca_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1serca_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1serca_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1serca_b2(:).integral]),...
                   mean([owt_noneTPC_1serca_b3(:).integral]),...
                   mean([owt_noneTPC_1serca_b4(:).integral]),...
                   mean([owt_noneTPC_1serca_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1serca_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1serca_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1serca_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1serca_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0serca_b2(:).integral]),...
                mean([owt_none_0serca_b3(:).integral]),...
                mean([owt_none_0serca_b4(:).integral]),...
                mean([owt_none_0serca_b5(:).integral])];
err_owt_none0 = [std([owt_none_0serca_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0serca_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0serca_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0serca_b5(:).integral])/sqrt(num_none0)];
 
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
 
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
 
ylim([8e4 20e4])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
 
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'er_beat1_4_serca_beat_integral'),'-dpng','-r300')
% close

%% errorbar ryr
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1ryr_b2(:).integral]),...
               mean([owt_TPC_1ryr_b3(:).integral]),...
               mean([owt_TPC_1ryr_b4(:).integral]),...
               mean([owt_TPC_1ryr_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1ryr_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1ryr_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1ryr_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1ryr_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1ryr_b2(:).integral]),...
                   mean([owt_noneTPC_1ryr_b3(:).integral]),...
                   mean([owt_noneTPC_1ryr_b4(:).integral]),...
                   mean([owt_noneTPC_1ryr_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1ryr_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1ryr_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1ryr_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1ryr_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0ryr_b2(:).integral]),...
                mean([owt_none_0ryr_b3(:).integral]),...
                mean([owt_none_0ryr_b4(:).integral]),...
                mean([owt_none_0ryr_b5(:).integral])];
err_owt_none0 = [std([owt_none_0ryr_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0ryr_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0ryr_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0ryr_b5(:).integral])/sqrt(num_none0)];
             
errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
 
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
 
ylim([12e5 35e5])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
 
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'er_beat1_4_ryr_beat_integral'),'-dpng','-r300')
% close

% %% errorbar cal
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1cal_b2(:).integral]),...
%                mean([owt_TPC_1cal_b3(:).integral]),...
%                mean([owt_TPC_1cal_b4(:).integral]),...
%                mean([owt_TPC_1cal_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1cal_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1cal_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1cal_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1cal_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1cal_b2(:).integral]),...
%                    mean([owt_noneTPC_1cal_b3(:).integral]),...
%                    mean([owt_noneTPC_1cal_b4(:).integral]),...
%                    mean([owt_noneTPC_1cal_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1cal_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1cal_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1cal_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1cal_b5(:).integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0cal_b2(:).integral]),...
%                 mean([owt_none_0cal_b3(:).integral]),...
%                 mean([owt_none_0cal_b4(:).integral]),...
%                 mean([owt_none_0cal_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0cal_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0cal_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0cal_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0cal_b5(:).integral])/sqrt(num_none0)];
%              
% errorbar(ex, ey_owt_noneTPC1, err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, ey_owt_TPC1, err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_owt_none0, err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([1.5e2 2.6e2])
% ax = gca;
% ax.YAxis.Exponent = 1;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'L-type Current (pA/pF)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_cal_beat_integral'),'-dpng','-r300')
% % close
%% I_Ca_junc
close 
figure(7)
num_TPC1 = numel(S3w_TPC_1); 
num_noneTPC1 = numel(S3w_noneTPC_1);
num_none0 = numel(S3w_none_0);
   
ex = 1:4;
ey_owt_TPC1 = [mean([owt_TPC_1jucal_b2(:).integral]),...
               mean([owt_TPC_1jucal_b3(:).integral]),...
               mean([owt_TPC_1jucal_b4(:).integral]),...
               mean([owt_TPC_1jucal_b5(:).integral])];
err_owt_TPC1 = [std([owt_TPC_1jucal_b2(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1jucal_b3(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1jucal_b4(:).integral])/sqrt(num_TPC1),...
                std([owt_TPC_1jucal_b5(:).integral])/sqrt(num_TPC1)];   
 
ey_owt_noneTPC1 = [mean([owt_noneTPC_1jucal_b2(:).integral]),...
                   mean([owt_noneTPC_1jucal_b3(:).integral]),...
                   mean([owt_noneTPC_1jucal_b4(:).integral]),...
                   mean([owt_noneTPC_1jucal_b5(:).integral])];
err_owt_noneTPC1 = [std([owt_noneTPC_1jucal_b2(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1jucal_b3(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1jucal_b4(:).integral])/sqrt(num_noneTPC1),...
                    std([owt_noneTPC_1jucal_b5(:).integral])/sqrt(num_noneTPC1)];   
 
ey_owt_none0 = [mean([owt_none_0jucal_b2(:).integral]),...
                mean([owt_none_0jucal_b3(:).integral]),...
                mean([owt_none_0jucal_b4(:).integral]),...
                mean([owt_none_0jucal_b5(:).integral])];
err_owt_none0 = [std([owt_none_0jucal_b2(:).integral])/sqrt(num_none0),...
                 std([owt_none_0jucal_b3(:).integral])/sqrt(num_none0),...
                 std([owt_none_0jucal_b4(:).integral])/sqrt(num_none0),...
                 std([owt_none_0jucal_b5(:).integral])/sqrt(num_none0)];
             
errorbar(ex, abs(ey_owt_noneTPC1), err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
errorbar(ex, abs(ey_owt_TPC1), err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, abs(ey_owt_none0), err_owt_none0,'LineWidth', 2,'Color','m'); 
 
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
 
ylim([1.4e2 2.6e2])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 1;
legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'Junctional L-type','Current (pA/pF)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
 
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'I_Ca_junc'),'-dpng','-r300')
% close

% %% errorbar ncx
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1ncx_b2(:).integral]),...
%                mean([owt_TPC_1ncx_b3(:).integral]),...
%                mean([owt_TPC_1ncx_b4(:).integral]),...
%                mean([owt_TPC_1ncx_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1ncx_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1ncx_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1ncx_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1ncx_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1ncx_b2(:).integral]),...
%                    mean([owt_noneTPC_1ncx_b3(:).integral]),...
%                    mean([owt_noneTPC_1ncx_b4(:).integral]),...
%                    mean([owt_noneTPC_1ncx_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1ncx_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1ncx_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1ncx_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1ncx_b5(:).integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0ncx_b2(:).integral]),...
%                 mean([owt_none_0ncx_b3(:).integral]),...
%                 mean([owt_none_0ncx_b4(:).integral]),...
%                 mean([owt_none_0ncx_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0ncx_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0ncx_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0ncx_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0ncx_b5(:).integral])/sqrt(num_none0)];
%              
% errorbar(ex, abs(ey_owt_noneTPC1), err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, abs(ey_owt_TPC1), err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, abs(ey_owt_none0), err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([1.5e2 6e2])
% ax = gca; 
% ax.YAxis.Exponent = 2;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'NCX Current (pA/pF)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_ncx_beat_integral'),'-dpng','-r300')
% % close
% 
% %% errorbar juca I_ncx_junc 
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1juca_b2(:).integral]),...
%                mean([owt_TPC_1juca_b3(:).integral]),...
%                mean([owt_TPC_1juca_b4(:).integral]),...
%                mean([owt_TPC_1juca_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1juca_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1juca_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1juca_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1juca_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1juca_b2(:).integral]),...
%                    mean([owt_noneTPC_1juca_b3(:).integral]),...
%                    mean([owt_noneTPC_1juca_b4(:).integral]),...
%                    mean([owt_noneTPC_1juca_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1juca_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1juca_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1juca_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1juca_b5(:).integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0juca_b2(:).integral]),...
%                 mean([owt_none_0juca_b3(:).integral]),...
%                 mean([owt_none_0juca_b4(:).integral]),...
%                 mean([owt_none_0juca_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0juca_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0juca_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0juca_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0juca_b5(:).integral])/sqrt(num_none0)];
%  
% errorbar(ex, abs(ey_owt_noneTPC1), err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, abs(ey_owt_TPC1), err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, abs(ey_owt_none0), err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% ylim([6e1 22e1])
% ax = gca; 
% ax.YAxis.Exponent = 1;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional NCX','Current (pA/pF)'})
% 
% title({' ',' '})
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'I_ncx_junc'),'-dpng','-r300')
% %% errorbar jusl I_ncx_sl
% close 
% figure(7)
% num_TPC1 = numel(S3w_TPC_1); 
% num_noneTPC1 = numel(S3w_noneTPC_1);
% num_none0 = numel(S3w_none_0);
%    
% ex = 1:4;
% ey_owt_TPC1 = [mean([owt_TPC_1jusl_b2(:).integral]),...
%                mean([owt_TPC_1jusl_b3(:).integral]),...
%                mean([owt_TPC_1jusl_b4(:).integral]),...
%                mean([owt_TPC_1jusl_b5(:).integral])];
% err_owt_TPC1 = [std([owt_TPC_1jusl_b2(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1jusl_b3(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1jusl_b4(:).integral])/sqrt(num_TPC1),...
%                 std([owt_TPC_1jusl_b5(:).integral])/sqrt(num_TPC1)];   
%  
% ey_owt_noneTPC1 = [mean([owt_noneTPC_1jusl_b2(:).integral]),...
%                    mean([owt_noneTPC_1jusl_b3(:).integral]),...
%                    mean([owt_noneTPC_1jusl_b4(:).integral]),...
%                    mean([owt_noneTPC_1jusl_b5(:).integral])];
% err_owt_noneTPC1 = [std([owt_noneTPC_1jusl_b2(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1jusl_b3(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1jusl_b4(:).integral])/sqrt(num_noneTPC1),...
%                     std([owt_noneTPC_1jusl_b5(:).integral])/sqrt(num_noneTPC1)];   
%  
% ey_owt_none0 = [mean([owt_none_0jusl_b2(:).integral]),...
%                 mean([owt_none_0jusl_b3(:).integral]),...
%                 mean([owt_none_0jusl_b4(:).integral]),...
%                 mean([owt_none_0jusl_b5(:).integral])];
% err_owt_none0 = [std([owt_none_0jusl_b2(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0jusl_b3(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0jusl_b4(:).integral])/sqrt(num_none0),...
%                  std([owt_none_0jusl_b5(:).integral])/sqrt(num_none0)];
% 
% errorbar(ex, abs(ey_owt_noneTPC1), err_owt_noneTPC1,'LineWidth', 2,'Color','r'); hold on
% errorbar(ex, abs(ey_owt_TPC1), err_owt_TPC1,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, abs(ey_owt_none0), err_owt_none0,'LineWidth', 2,'Color','m'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% 
% ylim([0.5e2 3e2])
% ax = gca; 
% ax.YAxis.Exponent = 1;
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Sarcolemmal NCX','Current (pA/pF)'})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'I_ncx_sl'),'-dpng','-r300')

% ls2j
% for ipeak = 1:numel(S3j_TPC_1)   
%     t1_1 = S3j_TPC_1(ipeak).t;
%     y38_1= S3j_TPC_1(ipeak).y(:,38).*1e6;
%     y31= S3j_TPC_1(ipeak).y(:,31).*1e6;
%     y88= S3j_TPC_1(ipeak).y(:,88).*1e6;
%     y36= S3j_TPC_1(ipeak).y(:,36).*1e6;
%     y37= S3j_TPC_1(ipeak).y(:,37).*1e6;
%     
%     tf = F3j_TPC_1(ipeak).tArray;
%     yserca = F3j_TPC_1(ipeak).Jserca.*1e6;    
%     yryr = F3j_TPC_1(ipeak).J_RyR.*1e6;    
%     ycal = F3j_TPC_1(ipeak).I_Ca_store;    
%     yncx = F3j_TPC_1(ipeak).Incx;    
%     yls2j = F3j_TPC_1(ipeak).JLS2J.*1e6;    
%     yls2i = F3j_TPC_1(ipeak).JLS2I.*1e6;  
%     
% %  find amp, timepoint of beat 1    
%     ls2j_TPC_1y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2j_TPC_1y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2j_TPC_1y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2j_TPC_1y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2j_TPC_1y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2j_TPC_1ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2j_TPC_1ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2j_TPC_1serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2j_TPC_1ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2j_TPC_1cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2j_TPC_1ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2j_TPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2j_TPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2j_TPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2j_TPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2j_TPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2j_TPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2j_TPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2j_TPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2j_TPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2j_TPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2j_TPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2j_TPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2j_TPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2j_TPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2j_TPC_1y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_TPC_1y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2j_TPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2j_TPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2j_TPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2j_TPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2j_TPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2j_TPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2j_TPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2j_TPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2j_TPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2j_TPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_TPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2j_TPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2j_TPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2j_TPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2j_TPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2j_TPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2j_TPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2j_TPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2j_TPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2j_TPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2j_TPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2j_TPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2j_TPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2j_TPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2j_TPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2j_TPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2j_TPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2j_TPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);       
% end    
% for ipeak = 1:numel(S3j_noneTPC_1)   
%     t1_1 = S3j_noneTPC_1(ipeak).t;
%     y38_1= S3j_noneTPC_1(ipeak).y(:,38).*1e6;
%     y31= S3j_noneTPC_1(ipeak).y(:,31).*1e6;
%     y88= S3j_noneTPC_1(ipeak).y(:,88).*1e6;
%     y36= S3j_noneTPC_1(ipeak).y(:,36).*1e6;
%     y37= S3j_noneTPC_1(ipeak).y(:,37).*1e6;
%     
%     tf = F3j_noneTPC_1(ipeak).tArray;
%     yserca = F3j_noneTPC_1(ipeak).Jserca.*1e6;    
%     yryr = F3j_noneTPC_1(ipeak).J_RyR.*1e6;    
%     ycal = F3j_noneTPC_1(ipeak).I_Ca_store;    
%     yncx = F3j_noneTPC_1(ipeak).Incx;    
%     yls2j = F3j_noneTPC_1(ipeak).JLS2J.*1e6;    
%     yls2i = F3j_noneTPC_1(ipeak).JLS2I.*1e6;  
%     
%    %  find amp, timepoint of beat 1    
%     ls2j_noneTPC_1y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2j_noneTPC_1y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2j_noneTPC_1y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2j_noneTPC_1y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2j_noneTPC_1y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2j_noneTPC_1ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2j_noneTPC_1ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2j_noneTPC_1serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2j_noneTPC_1ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2j_noneTPC_1cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2j_noneTPC_1ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2j_noneTPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2j_noneTPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2j_noneTPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2j_noneTPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2j_noneTPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2j_noneTPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2j_noneTPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2j_noneTPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2j_noneTPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2j_noneTPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2j_noneTPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2j_noneTPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2j_noneTPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2j_noneTPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2j_noneTPC_1y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_noneTPC_1y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2j_noneTPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2j_noneTPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2j_noneTPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2j_noneTPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2j_noneTPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2j_noneTPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2j_noneTPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2j_noneTPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2j_noneTPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2j_noneTPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_noneTPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2j_noneTPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2j_noneTPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2j_noneTPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2j_noneTPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2j_noneTPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2j_noneTPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2j_noneTPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2j_noneTPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2j_noneTPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2j_noneTPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2j_noneTPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2j_noneTPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2j_noneTPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2j_noneTPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2j_noneTPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2j_noneTPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2j_noneTPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);        
% end    
% for ipeak = 1:numel(S3j_none_0)   
%     t1_1 = S3j_none_0(ipeak).t;
%     y38_1= S3j_none_0(ipeak).y(:,38).*1e6;
%     y31= S3j_none_0(ipeak).y(:,31).*1e6;
%     y88= S3j_none_0(ipeak).y(:,88).*1e6;
%     y36= S3j_none_0(ipeak).y(:,36).*1e6;
%     y37= S3j_none_0(ipeak).y(:,37).*1e6;
%     
%     tf = F3j_none_0(ipeak).tArray;
%     yserca = F3j_none_0(ipeak).Jserca.*1e6;    
%     yryr = F3j_none_0(ipeak).J_RyR.*1e6;    
%     ycal = F3j_none_0(ipeak).I_Ca_store;    
%     yncx = F3j_none_0(ipeak).Incx;    
%     yls2j = F3j_none_0(ipeak).JLS2J.*1e6;    
%     yls2i = F3j_none_0(ipeak).JLS2I.*1e6;  
%     
%  %  find amp, timepoint of beat 1    
%     ls2j_none_0y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2j_none_0y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2j_none_0y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2j_none_0y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2j_none_0y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2j_none_0ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2j_none_0ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2j_none_0serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2j_none_0ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2j_none_0cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2j_none_0ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2j_none_0y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2j_none_0y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2j_none_0y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2j_none_0y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2j_none_0y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2j_none_0ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2j_none_0ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2j_none_0serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2j_none_0ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2j_none_0cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2j_none_0ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2j_none_0y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2j_none_0y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2j_none_0y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2j_none_0y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_none_0y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2j_none_0ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2j_none_0ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2j_none_0serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2j_none_0ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2j_none_0cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2j_none_0ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2j_none_0y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2j_none_0y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2j_none_0y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2j_none_0y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2j_none_0y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2j_none_0ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2j_none_0ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2j_none_0serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2j_none_0ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2j_none_0cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2j_none_0ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2j_none_0y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2j_none_0y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2j_none_0y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2j_none_0y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2j_none_0y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2j_none_0ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2j_none_0ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2j_none_0serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2j_none_0ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2j_none_0cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2j_none_0ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);    
% end    
% %ls2i
% for ipeak = 1:numel(S3i_TPC_1)   
%     t1_1 = S3i_TPC_1(ipeak).t;
%     y38_1= S3i_TPC_1(ipeak).y(:,38).*1e6;
%     y31= S3i_TPC_1(ipeak).y(:,31).*1e6;
%     y88= S3i_TPC_1(ipeak).y(:,88).*1e6;
%     y36= S3i_TPC_1(ipeak).y(:,36).*1e6;
%     y37= S3i_TPC_1(ipeak).y(:,37).*1e6;
%     
%     tf = F3i_TPC_1(ipeak).tArray;
%     yserca = F3i_TPC_1(ipeak).Jserca.*1e6;    
%     yryr = F3i_TPC_1(ipeak).J_RyR.*1e6;    
%     ycal = F3i_TPC_1(ipeak).I_Ca_store;    
%     yncx = F3i_TPC_1(ipeak).Incx;    
%     yls2j = F3i_TPC_1(ipeak).JLS2J.*1e6;    
%     yls2i = F3i_TPC_1(ipeak).JLS2I.*1e6;  
%     
% %  find amp, timepoint of beat 1    
%     ls2i_TPC_1y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2i_TPC_1y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2i_TPC_1y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2i_TPC_1y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2i_TPC_1y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2i_TPC_1ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2i_TPC_1ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2i_TPC_1serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2i_TPC_1ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2i_TPC_1cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2i_TPC_1ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2i_TPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2i_TPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2i_TPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2i_TPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2i_TPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2i_TPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2i_TPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2i_TPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2i_TPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2i_TPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2i_TPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2i_TPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2i_TPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2i_TPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2i_TPC_1y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_TPC_1y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2i_TPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2i_TPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2i_TPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2i_TPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2i_TPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2i_TPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2i_TPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2i_TPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2i_TPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2i_TPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_TPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2i_TPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2i_TPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2i_TPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2i_TPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2i_TPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2i_TPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2i_TPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2i_TPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2i_TPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2i_TPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2i_TPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2i_TPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2i_TPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2i_TPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2i_TPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2i_TPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2i_TPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);       
% end    
% for ipeak = 1:numel(S3i_noneTPC_1)   
%     t1_1 = S3i_noneTPC_1(ipeak).t;
%     y38_1= S3i_noneTPC_1(ipeak).y(:,38).*1e6;
%     y31= S3i_noneTPC_1(ipeak).y(:,31).*1e6;
%     y88= S3i_noneTPC_1(ipeak).y(:,88).*1e6;
%     y36= S3i_noneTPC_1(ipeak).y(:,36).*1e6;
%     y37= S3i_noneTPC_1(ipeak).y(:,37).*1e6;
%     
%     tf = F3i_noneTPC_1(ipeak).tArray;
%     yserca = F3i_noneTPC_1(ipeak).Jserca.*1e6;    
%     yryr = F3i_noneTPC_1(ipeak).J_RyR.*1e6;    
%     ycal = F3i_noneTPC_1(ipeak).I_Ca_store;    
%     yncx = F3i_noneTPC_1(ipeak).Incx;    
%     yls2j = F3i_noneTPC_1(ipeak).JLS2J.*1e6;    
%     yls2i = F3i_noneTPC_1(ipeak).JLS2I.*1e6;  
%     
%    %  find amp, timepoint of beat 1    
%     ls2i_noneTPC_1y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2i_noneTPC_1y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2i_noneTPC_1y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2i_noneTPC_1y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2i_noneTPC_1y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2i_noneTPC_1ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2i_noneTPC_1ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2i_noneTPC_1serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2i_noneTPC_1ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2i_noneTPC_1cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2i_noneTPC_1ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2i_noneTPC_1y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2i_noneTPC_1y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2i_noneTPC_1y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2i_noneTPC_1y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2i_noneTPC_1y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2i_noneTPC_1ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2i_noneTPC_1ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2i_noneTPC_1serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2i_noneTPC_1ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2i_noneTPC_1cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2i_noneTPC_1ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2i_noneTPC_1y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2i_noneTPC_1y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2i_noneTPC_1y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2i_noneTPC_1y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_noneTPC_1y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2i_noneTPC_1ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2i_noneTPC_1ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2i_noneTPC_1serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2i_noneTPC_1ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2i_noneTPC_1cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2i_noneTPC_1ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2i_noneTPC_1y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2i_noneTPC_1y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2i_noneTPC_1y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2i_noneTPC_1y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_noneTPC_1y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2i_noneTPC_1ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2i_noneTPC_1ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2i_noneTPC_1serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2i_noneTPC_1ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2i_noneTPC_1cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2i_noneTPC_1ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2i_noneTPC_1y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2i_noneTPC_1y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2i_noneTPC_1y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2i_noneTPC_1y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2i_noneTPC_1y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2i_noneTPC_1ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2i_noneTPC_1ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2i_noneTPC_1serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2i_noneTPC_1ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2i_noneTPC_1cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2i_noneTPC_1ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);        
% end    
% for ipeak = 1:numel(S3i_none_0)   
%     t1_1 = S3i_none_0(ipeak).t;
%     y38_1= S3i_none_0(ipeak).y(:,38).*1e6;
%     y31= S3i_none_0(ipeak).y(:,31).*1e6;
%     y88= S3i_none_0(ipeak).y(:,88).*1e6;
%     y36= S3i_none_0(ipeak).y(:,36).*1e6;
%     y37= S3i_none_0(ipeak).y(:,37).*1e6;
%     
%     tf = F3i_none_0(ipeak).tArray;
%     yserca = F3i_none_0(ipeak).Jserca.*1e6;    
%     yryr = F3i_none_0(ipeak).J_RyR.*1e6;    
%     ycal = F3i_none_0(ipeak).I_Ca_store;    
%     yncx = F3i_none_0(ipeak).Incx;    
%     yls2j = F3i_none_0(ipeak).JLS2J.*1e6;    
%     yls2i = F3i_none_0(ipeak).JLS2I.*1e6;  
%     
%  %  find amp, timepoint of beat 1    
%     ls2i_none_0y38_b1(ipeak) = peak_marker(t1_1,T1,y38_1,ratio);
%     ls2i_none_0y31_b1(ipeak) = sr_marker(t1_1,T1,y31,srratio);
%     ls2i_none_0y88_b1(ipeak) = peak_marker(t1_1,T1,y88,lsratio);
%     ls2i_none_0y36_b1(ipeak) = peak_marker(t1_1,T1,y36,lsratio);
%     ls2i_none_0y37_b1(ipeak) = peak_marker(t1_1,T1,y37,lsratio);
%  
%     ls2i_none_0ls2j_b1(ipeak) = peak_marker(tf,T1,yls2j,ls2jratio);
%     ls2i_none_0ls2i_b1(ipeak) = peak_marker(tf,T1,yls2i,ls2iratio);
%     ls2i_none_0serca_b1(ipeak) = peak_marker(tf,T1,yserca,ratio);    
%     ls2i_none_0ryr_b1(ipeak) = peak_marker(tf,T1,yryr,ryrratio);
%     ls2i_none_0cal_b1(ipeak) = peak_marker(tf,T1,ycal,calratio);
%     ls2i_none_0ncx_b1(ipeak) = peak_marker(tf,T1,yncx,ncxratio); 
% %  - find amp, timepoint of beat 2   
%     ls2i_none_0y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2i_none_0y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
%     ls2i_none_0y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
%     ls2i_none_0y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
%     ls2i_none_0y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
%     
%     ls2i_none_0ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
%     ls2i_none_0ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
%     ls2i_none_0serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
%     ls2i_none_0ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
%     ls2i_none_0cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
%     ls2i_none_0ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
% %  - find amp, timepoint of beat 3   
%     ls2i_none_0y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2i_none_0y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
%     ls2i_none_0y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
%     ls2i_none_0y36_b3(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_none_0y37_b3(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%     
%     ls2i_none_0ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
%     ls2i_none_0ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
%     ls2i_none_0serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
%     ls2i_none_0ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
%     ls2i_none_0cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
%     ls2i_none_0ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);     
% %  - find amp, timepoint of beat 4   
%     ls2i_none_0y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2i_none_0y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
%     ls2i_none_0y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
%     ls2i_none_0y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
%     ls2i_none_0y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
%  
%     ls2i_none_0ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
%     ls2i_none_0ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
%     ls2i_none_0serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
%     ls2i_none_0ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
%     ls2i_none_0cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
%     ls2i_none_0ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
% %  - find amp, timepoint of beat 5   
%     ls2i_none_0y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2i_none_0y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
%     ls2i_none_0y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
%     ls2i_none_0y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
%     ls2i_none_0y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
%  
%     ls2i_none_0ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
%     ls2i_none_0ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
%     ls2i_none_0serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
%     ls2i_none_0ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
%     ls2i_none_0cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
%     ls2i_none_0ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);    
% end    
