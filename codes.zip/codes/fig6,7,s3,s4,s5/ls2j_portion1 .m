function Fpeak = ls2j_portion1(T,T1,Y,rate1,rate2)
[~,t0ind] = min(abs(T-T1(1)));
[~,t1ind] = min(abs(T-T1(2)));
T_1 = T(t0ind:t1ind);
Y_1 = Y(t0ind:t1ind);

[TFmax3w,~] = islocalmax(abs(Y_1),'MinProminence',max(abs(Y_1))/rate1);
[TFmin3w,~] = islocalmin(abs(Y_1),'MinProminence',max(abs(Y_1))/rate2);
peakidx = find(TFmax3w);
valleyidx = find(TFmin3w);
valleyidx = valleyidx(find(valleyidx> peakidx(1) & valleyidx< peakidx(2)));% in between two peakidx localmax
Fpeak.peakidx = peakidx + t0ind -1;
Fpeak.valleyidx = valleyidx +t0ind -1;

Fpeak.balanceidx = valleyidx + t0ind -1;
Fpeak.ls2jin = trapz(T_1(1:valleyidx), Y_1(1:valleyidx));
Fpeak.ls2jout = trapz(T_1(valleyidx:end), Y_1(valleyidx:end));
%
[~,iminY] = min(Y_1);
[~,imaxY] = max(Y_1);
Fpeak.diminY = iminY + t0ind -1;
Fpeak.dimaxY = imaxY + t0ind -1;

[~,ibalanceY]= min(abs(Y_1(iminY:imaxY)) -Y_1(1));
balanceidx = iminY+ibalanceY -1;
Fpeak.dbalanceidx = balanceidx + t0ind -1;
Fpeak.dls2jin = trapz(T_1(1:balanceidx), Y_1(1:balanceidx));
Fpeak.dls2jout = trapz(T_1(balanceidx:end), Y_1(balanceidx:end));


end