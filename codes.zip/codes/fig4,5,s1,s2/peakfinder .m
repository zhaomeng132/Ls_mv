function Fpeak = peakfinder(T,Y,rate1,rate2)

[TFmax3w,Pmax3w] = islocalmax(abs(Y),'MinProminence',max(abs(Y))/rate1);
if abs(Y(end)) > min(abs(Y))*1.3 % oct15, 1.1  %16oct 1.2
TFmax3w(end) = 1;
end 
peakidx = find(TFmax3w);
[TFmin3w,Pmin3w] = islocalmin(abs(Y),'MinProminence',max(abs(Y))/rate2);
valleyidx = find(TFmin3w);

% find the main before 200ms
[~, T300_id] = min(abs(T- 200));
Y300 = Y(T300_id);
T300_idx = find(Y == Y300);
peakidx_beforeT300 = peakidx(find(peakidx < T300_idx)); % 1 or >1
if isempty(peakidx_beforeT300)
peakidx_beforeT300 = 1;
% Fpeak.peakidx_beforeT300 = peakidx_beforeT300; % if no first peak, there must be a previous dad peak peaking at or before the beat start 
else   
peakidx_beforeT300 = peakidx_beforeT300(end); % for >1, use the last
% Fpeak.peakidx_beforeT300 = peakidx_beforeT300; 
end

Fpeak.peakI = peakidx_beforeT300;

% find extra peaks id after the main before 200ms
dadid = peakidx(find(peakidx > peakidx_beforeT300));

% find extra valleys id after main      
valleyidx = valleyidx(find(valleyidx > peakidx_beforeT300));  

% find the largest valley id
valleylist = Y(valleyidx);
[~, ivalley] = max(valleylist);
valleyid = valleyidx(ivalley);

Fpeak.endid = numel(T);

if isempty(valleyidx)
Y_decay = Y(peakidx_beforeT300:end);
[~, iminY_decay] = min(abs(Y_decay-Y(1)));

valleyid = peakidx_beforeT300 + iminY_decay -1; % modify 29 jun
if valleyid == numel(T)
   valleyid = valleyid -1; 
end                                          %
    
Fpeak.valleyI = valleyid;  
else
Fpeak.valleyI = valleyid;  
end
Fpeak.valleyIlist = valleyidx;
Fpeak.valleyTlist = T(valleyidx); 

Fpeak.dad_integral = trapz(T(valleyid:end),Y(valleyid:end));

Fpeak.peak_integral = trapz(T(1:valleyid),Y(1:valleyid));

Fpeak.integralY = trapz(T, Y);  %%


% if numel(peakidx) >1 & numel(dadidx) >0
% dadamp =  Y(dadidx) - min(Y);
% dadampT = T(dadidx);   
% [maxdadamp, imaxdadamp] = max(dadamp); % find max DAD amplitude
% 
% Fpeak.dad_ampI = dadidx;
% Fpeak.dad_ampT = dadampT(imaxdadamp);
% Fpeak.dad_ampYlist = dadamp;
% Fpeak.dad_ampY = maxdadamp;
% 
% %
% %
% Fpeak.dad_integralY = trapz(T(valleyidx:end),Y(valleyidx:end));
% 
% Fpeak.peak_integralY = trapz(T(1:valleyidx),Y(1:valleyidx));
% 
% Fpeak.valleyI = valley;
% Fpeak.valleyY = Y(valley);
% Fpeak.valleyYlist = valleylist;
% 
% else
%     
% Fpeak.dad_ampI = nan;
% Fpeak.dad_ampT = nan;
% Fpeak.dad_ampYlist = nan;
% Fpeak.dad_ampY = nan;
% 
% Fpeak.dad_integralY = 0;
% Fpeak.peak_integralY = trapz(T(1:end), Y(1:end)); 
% 
% Fpeak.valleyI = nan;
% Fpeak.valleyY = nan;
% Fpeak.valleyYlist = nan;
% 
% end  

end