clear all
close all
addpath('~/downloads/SS/h1_cao1dot8_p3_')
% id 1 -1000
cd ~/downloads/SS/h1_cao1_p123_
load h1_cao1_sf1000_sf343_0.mat

cd ~/downloads/SS/h1_cao1dot8_p3_/
% index 0 - 343
load cao1dot8_iTPC_1.mat
iTPC_1 = cao1dot8_iTPC_1;
load cao1dot8_inoneTPC_1.mat
inoneTPC_1 = cao1dot8_inoneTPC_1;
load cao1dot8_inone_0.mat
inone_0 = cao1dot8_inone_0;

% 5beat
% load cao1dot8_iTPC_1_5beat.mat
% iTPC_1 = cao1dot8_iTPC_1_5beat;
% load cao1dot8_inoneTPC_1_5beat.mat
% inoneTPC_1 = cao1dot8_inoneTPC_1_5beat;
% load cao1dot8_inone_0_5beat.mat
% inone_0 = cao1dot8_inone_0_5beat;


cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000
load sf1000_y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf343_0);
Swt_TPC_1 = S(iTPC_1);
Swt_noneTPC_1 = S(inoneTPC_1);
Swt_none_0 = S(inone_0);

cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf343_0);
Sjdot0_TPC_1 = S(iTPC_1);
Sjdot0_noneTPC_1 = S(inoneTPC_1);
Sjdot0_none_0 = S(inone_0);

cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000
load sf1000_y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf343_0);
Sidot0_TPC_1 = S(iTPC_1);
Sidot0_noneTPC_1 = S(inoneTPC_1);
Sidot0_none_0 = S(inone_0);

cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_herz1_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf343_0);
Fwt_TPC_1 = F(iTPC_1);
Fwt_noneTPC_1 = F(inoneTPC_1);
Fwt_none_0 = F(inone_0);

cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_j_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf343_0);
Fjdot0_TPC_1 = F(iTPC_1);
Fjdot0_noneTPC_1 = F(inoneTPC_1);
Fjdot0_none_0 = F(inone_0);

cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_i_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf343_0);
Fidot0_TPC_1 = F(iTPC_1);
Fidot0_noneTPC_1 = F(inoneTPC_1);
Fidot0_none_0 = F(inone_0);

% cd ~/downloads/SS/h1_cao1dot8_p3_/
% mkdir(['./','cao1dot8_nobump_option3'])
% cd(['./','cao1dot8_nobump_option3'])

% % cd ~/downloads/SS/h1_cao1dot8_p3_/
% % mkdir(['./','cao1dot8_nobump_option2'])
% % cd(['./','cao1dot8_nobump_option2'])

% cd ~/downloads/SS/h1_cao1dot8_p3_/
% mkdir(['./','cao1dot8_nobump_5beat_option2'])
% cd(['./','cao1dot8_nobump_5beat_option2'])

cd ~/downloads/SS/
mkdir(['./','figs1'])
cd(['./','figs1'])

%%
rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                     % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
sf = sf(h1_cao1_sf1000_sf343_0,:);

% index 0 - 343

sf_noneTPC_1 = sf(inoneTPC_1,:);
sf_TPC_1 = sf(iTPC_1,:);
sf_none_0 = sf(inone_0,:);

close all

bx = [
     sf_noneTPC_1(:,1);sf_TPC_1(:,1);sf_none_0(:,1);...
     sf_noneTPC_1(:,2);sf_TPC_1(:,2);sf_none_0(:,2);...
     sf_noneTPC_1(:,3);sf_TPC_1(:,3);sf_none_0(:,3);...
     sf_noneTPC_1(:,4);sf_TPC_1(:,4);sf_none_0(:,4);...
     sf_noneTPC_1(:,5);sf_TPC_1(:,5);sf_none_0(:,5);...
     sf_noneTPC_1(:,6);sf_TPC_1(:,6);sf_none_0(:,6);...
     sf_noneTPC_1(:,7);sf_TPC_1(:,7);sf_none_0(:,7);...
     sf_noneTPC_1(:,8);sf_TPC_1(:,8);sf_none_0(:,8);...
     sf_noneTPC_1(:,9);sf_TPC_1(:,9);sf_none_0(:,9);...
     ];
 
 
by = [ zeros(length(sf_noneTPC_1), 1);1*ones(length([sf_TPC_1]), 1);2*ones(length([sf_none_0]), 1);... 
       3*ones(length([sf_noneTPC_1]), 1);4*ones(length([sf_TPC_1]), 1);5*ones(length([sf_none_0]), 1);... 
       6*ones(length([sf_noneTPC_1]), 1);7*ones(length([sf_TPC_1]), 1);8*ones(length([sf_none_0]), 1);... 
       9*ones(length([sf_noneTPC_1]), 1);10*ones(length([sf_TPC_1]), 1);11*ones(length([sf_none_0]), 1);...
       12*ones(length([sf_noneTPC_1]), 1);13*ones(length([sf_TPC_1]), 1);14*ones(length([sf_none_0]), 1);... 
       15*ones(length([sf_noneTPC_1]), 1);16*ones(length([sf_TPC_1]), 1);17*ones(length([sf_none_0]), 1);...
       18*ones(length([sf_noneTPC_1]), 1);19*ones(length([sf_TPC_1]), 1);20*ones(length([sf_none_0]), 1);...
       21*ones(length([sf_noneTPC_1]), 1);22*ones(length([sf_TPC_1]), 1);23*ones(length([sf_none_0]), 1);...
       24*ones(length([sf_noneTPC_1]), 1);25*ones(length([sf_TPC_1]), 1);26*ones(length([sf_none_0]), 1);...
     ];

figure(1);
boxplot(bx,by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
ylabel({'Variations of Conductances'})
ylim([0.5 3])
set(gca,'TickLabelInterpreter','Tex')
ax = gca;
% ax. Position = [0.25 0.2 0.7 0.7];
lbl= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
set(gca,'xticklabel',lbl)
set(gca,'xtick',2:3:26)
set(gca,'ytick',0.5:0.5:2)
set(gca,'box','off');
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast');legend boxoff

set(gca, 'FontName','Times New Roman','FontSize',35)
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 1500 600])
print(gcf, fullfile(pwd, 'bp_cao1dot8'),'-dpng','-r300')
close

% % ncx - cal
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,7))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,7))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,7))

% ncx - ryr
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,5))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,5))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,5))

% ncx - serca
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,4))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,4))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,4))

% ls,up - ls,rel
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,1)) - median(sf_noneTPC_1(:,2))
% ncd_TPC_1 = median(sf_TPC_1(:,1)) - median(sf_TPC_1(:,2))
% ncd_none_0 = median(sf_none_0(:,1)) - median(sf_none_0(:,2))

% serca - ryr
ncd_noneTPC_1 = median(sf_noneTPC_1(:,4)) - median(sf_noneTPC_1(:,5))
ncd_TPC_1 = median(sf_TPC_1(:,4)) - median(sf_TPC_1(:,5))
ncd_none_0 = median(sf_none_0(:,4)) - median(sf_none_0(:,5))

%% biomarkers for Swt, Sjdot0, Sidot0
% Swt
for ipeak = 1: numel(Swt_TPC_1) 

t3 = Swt_TPC_1(ipeak).t;
y3 = Swt_TPC_1(ipeak).y;

% biomarkers for Swt
owt_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200); %mM/ms to nM/ms 
owt_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
owt_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_TPC_1(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_TPC_1(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200,200, y3(:,36).*1e6);

% figure(1)
% plot(t3, y3(:,31));hold on
% plot(t3(owt_y31_y36_TPC_1(ipeak).valleyI), y3(owt_y31_y36_TPC_1(ipeak).valleyI,31),'r.','MarkerSize',30)

% figure(4)
% plot(t3, y3(:,36));hold on
% plot(t3(owt_y31_TPC_1(ipeak).valleyI), y3(owt_y31_TPC_1(ipeak).valleyI,36),'r.','MarkerSize',30)

end

for ipeak = 1:numel(Swt_noneTPC_1) 

t3 = Swt_noneTPC_1(ipeak).t;
y3 = Swt_noneTPC_1(ipeak).y;

% biomarkers for Swt
owt_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200);
owt_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
owt_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_noneTPC_1(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_noneTPC_1(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200,200, y3(:,36).*1e6);

% figure(2)
% plot(t3, y3(:,31));hold on
% plot(t3(owt_y31_y36_noneTPC_1(ipeak).valleyI), y3(owt_y31_y36_noneTPC_1(ipeak).valleyI,31),'r.','MarkerSize',30)

end

for ipeak = 1: 10%numel(Swt_none_0) 

t3 = Swt_none_0(ipeak).t;
y3 = Swt_none_0(ipeak).y;

% biomarkers for Swt
owt_y38_none_0(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200);
owt_y88_none_0(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
owt_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_none_0(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_none_0(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_none_0(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200, 200, y3(:,36).*1e6);

% figure(3)
% plot(t3, y3(:,31));hold on
% plot(t3(owt_y31_y36_none_0(ipeak).valleyI), y3(owt_y31_y36_none_0(ipeak).valleyI,31),'r.','MarkerSize',30)

end
%%
w1i1 = [owt_y31_y36_noneTPC_1(:).integralY]';
w1i0 = [owt_y31_y36_TPC_1(:).integralY]';
w0i0 = [owt_y31_y36_none_0(:).integralY];
      
% %% y31 val_iniY
% close all
% figure(7)
% bx = [[owt_y31_y36_noneTPC_1(:).val_iniY],...
%       [owt_y31_y36_TPC_1(:).val_iniY],...
%       [owt_y31_y36_none_0(:).val_iniY],...
%       ]; 
% by = [ zeros(length([owt_y31_y36_noneTPC_1(:).val_iniY]), 1);...
%        1*ones(length([owt_y31_y36_TPC_1(:).val_iniY]), 1);...       
%        2*ones(length([owt_y31_y36_none_0(:).val_iniY]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-8e4 40*1e4])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] SR Difference of Before', 'Spontaneous Release and','Initial Loading (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y31_val_iniY'),'-dpng','-r300')
% 
% %% y31 initialY
% close all
% figure(7)
% bx = [[owt_y31_y36_noneTPC_1(:).initialY],...
%       [owt_y31_y36_TPC_1(:).initialY],...
%       [owt_y31_y36_none_0(:).initialY],...
%       ]; 
% by = [ zeros(length([owt_y31_y36_noneTPC_1(:).initialY]), 1);...
%        1*ones(length([owt_y31_y36_TPC_1(:).initialY]), 1);...       
%        2*ones(length([owt_y31_y36_none_0(:).initialY]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([2e5 10*1e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] SR of','Initial Loading (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y31_initialY'),'-dpng','-r300')
% 
% %% y31 valleyY
% close all
% figure(7)
% bx = [[owt_y31_y36_noneTPC_1(:).valleyY],...
%       [owt_y31_y36_TPC_1(:).valleyY],...
%       [owt_y31_y36_none_0(:).valleyY],...
%       ]; 
% by = [ zeros(length([owt_y31_y36_noneTPC_1(:).valleyY]), 1);...
%        1*ones(length([owt_y31_y36_TPC_1(:).valleyY]), 1);...       
%        2*ones(length([owt_y31_y36_none_0(:).valleyY]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([2e5 10*1e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] SR Before','Spontaneous Release (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y31_valleyY'),'-dpng','-r300')
%% y31 integral
close all
figure(7)
bx = [[owt_y31_y36_noneTPC_1(:).integralY],...
      [owt_y31_y36_TPC_1(:).integralY],...
      [owt_y31_y36_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owt_y31_y36_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owt_y31_y36_TPC_1(:).integralY]), 1);...       
       2*ones(length([owt_y31_y36_none_0(:).integralY]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([1e7 25*1e7])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] SR (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y31'),'-dpng','-r300')

%% y36-y31 integral
close all
figure(7)
bx = [[owt_y31_y36_noneTPC_1(:).y31_y36_integral],...
      [owt_y31_y36_TPC_1(:).y31_y36_integral],...
      [owt_y31_y36_none_0(:).y31_y36_integral],...
      ]; 
by = [ zeros(length([owt_y31_y36_noneTPC_1(:).y31_y36_integral]), 1);...
       1*ones(length([owt_y31_y36_TPC_1(:).y31_y36_integral]), 1);...       
       2*ones(length([owt_y31_y36_none_0(:).y31_y36_integral]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([1e7 25*1e7])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Difference of','Junction and SR (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y36-y31'),'-dpng','-r300')

noneTPC_none = median([owt_y31_y36_noneTPC_1(:).y31_y36_integral]) - median([owt_y31_y36_none_0(:).y31_y36_integral])
TPC_none = median([owt_y31_y36_TPC_1(:).y31_y36_integral]) - median([owt_y31_y36_none_0(:).y31_y36_integral])
% %% y36-y31 peak integral
% close all
% figure(7)
% bx = [[owt_y31_y36_noneTPC_1(:).y31_y36_peak_integral],...
%       [owt_y31_y36_TPC_1(:).y31_y36_peak_integral],...
%       [owt_y31_y36_none_0(:).y31_y36_peak_integral],...
%       ]; 
% by = [ zeros(length([owt_y31_y36_noneTPC_1(:).y31_y36_peak_integral]), 1);...
%        1*ones(length([owt_y31_y36_TPC_1(:).y31_y36_peak_integral]), 1);...       
%        2*ones(length([owt_y31_y36_none_0(:).y31_y36_peak_integral]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([0e7 13*1e7])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Systolic [Ca] Difference of','Junction and SR (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y36-y31_peak'),'-dpng','-r300')
% %% y36-y31 dad integral 
% figure(7)
% bx = [[owt_y31_y36_noneTPC_1(:).y31_y36_dad_integral],...
%       [owt_y31_y36_TPC_1(:).y31_y36_dad_integral],...
%       [owt_y31_y36_none_0(:).y31_y36_dad_integral],...
%       ]; 
% by = [ zeros(length([owt_y31_y36_noneTPC_1(:).y31_y36_dad_integral]), 1);...
%        1*ones(length([owt_y31_y36_TPC_1(:).y31_y36_dad_integral]), 1);...       
%        2*ones(length([owt_y31_y36_none_0(:).y31_y36_dad_integral]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-1*1e7 15*1e7])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Diastolic [Ca] Difference of','Junction and SR (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y36-y31_dad'),'-dpng','-r300')
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36]; 
%%           17        18     19       20       21             22            23               24       25       26

for ipeak = 1: 1%numel(Fwt_TPC_1)

figure(1);
% plot(Fwt_TPC_1(ipeak).tArray,Fwt_TPC_1(ipeak).currents(:,7),'k');hold on

% plot(Fwt_TPC_1(ipeak).tArray,Fwt_TPC_1(ipeak).currents(:,26),'r');hold on
% plot(Fwt_noneTPC_1(ipeak).tArray,Fwt_noneTPC_1(ipeak).currents(:,26),'k');
% plot(Fwt_none_0(ipeak).tArray,Fwt_none_0(ipeak).currents(:,26),'b');

plot(Swt_TPC_1(ipeak).t,Swt_TPC_1(ipeak).y(:,31),'r');hold on
plot(Swt_noneTPC_1(ipeak).t,Swt_noneTPC_1(ipeak).y(:,31),'k');
plot(Swt_none_0(ipeak).t,Swt_none_0(ipeak).y(:,31),'b');
end
%%
for ipeak = 1: numel(Fwt_TPC_1)
   
tflux = Fwt_TPC_1(ipeak).tArray;
yserca = Fwt_TPC_1(ipeak).Jserca.*1e6;    
yryr = Fwt_TPC_1(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_TPC_1(ipeak).currents(:,1));   % abs

owtF_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,13)*1e6,2,2); %mM /ms
% owtF_slcal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,16)*1e6,2,2);

% owtF_sr_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,25)*1e6,2,2);

owtF_ncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,2),2,2);
owtF_juncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,11),2,2);
owtF_slncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,12),2,2);

owtF_jucal_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,9),2,2);

% owtF_y31_36_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,26),2,2);
end

for ipeak = 1: numel(Fwt_noneTPC_1)
   
tflux = Fwt_noneTPC_1(ipeak).tArray;
yserca = Fwt_noneTPC_1(ipeak).Jserca.*1e6;    
yryr = Fwt_noneTPC_1(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_noneTPC_1(ipeak).currents(:,1));    

owtF_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,13)*1e6,2,2);
% owtF_slcal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,16)*1e6,2,2);
 
% owtF_sr_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,25)*1e6,2,2);

owtF_ncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,2),2,2);
owtF_juncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,11),2,2);
owtF_slncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,12),2,2);

owtF_jucal_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,9),2,2);

% owtF_y31_36_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,26),2,2);
end

for ipeak = 1: numel(Fwt_none_0)
  
tflux = Fwt_none_0(ipeak).tArray;
yserca = Fwt_none_0(ipeak).Jserca.*1e6;    
yryr = Fwt_none_0(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_none_0(ipeak).currents(:,1));    

owtF_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,13)*1e6,2,2);
% owtF_slcal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,16)*1e6,2,2);
 
% owtF_sr_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,25)*1e6,2,2);

owtF_ncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,2),2,2);
owtF_juncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,11),2,2);
owtF_slncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,12),2,2);

owtF_jucal_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,9),2,2);
% owtF_y31_36_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,26),2,2);
end

% %% y31_36
% close
% figure(7)
% bx = [
%       [owtF_y31_36_noneTPC_1(:).integralY],...
%       [owtF_y31_36_TPC_1(:).integralY],...
%       [owtF_y31_36_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_y31_36_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_y31_36_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_y31_36_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 0;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y31_36'),'-dpng','-r300')
% 

% %% jusl_cal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_jusl_cal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_jusl_cal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_jusl_cal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jusl_cal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jusl_cal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jusl_cal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Balance (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jusl_cal_2ncx_ca'),'-dpng','-r300')
% 
% 
% %% jutot_ca
% close
% figure(7)
% bx = [
%       [owtF_jutot_ca_noneTPC_1(:).integralY],...
%       [owtF_jutot_ca_TPC_1(:).integralY],...
%       [owtF_jutot_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jutot_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jutot_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jutot_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Balance (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jutot_ca'),'-dpng','-r300')
% 
% %% juncx_ca
% close
% figure(7)
% bx = [
%       abs([owtF_juncx_ca_noneTPC_1(:).integralY]),...
%       abs([owtF_juncx_ca_TPC_1(:).integralY]),...
%       abs([owtF_juncx_ca_none_0(:).integralY]),...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([6e6 25e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] NCX Efflux (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca'),'-dpng','-r300')
% 
% %% sr_in_out
% close
% figure(7)
% bx = [
%       [owtF_sr_in_out_noneTPC_1(:).integralY],...
%       [owtF_sr_in_out_TPC_1(:).integralY],...
%       [owtF_sr_in_out_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_sr_in_out_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_sr_in_out_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_sr_in_out_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-5e5 10e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'SR [Ca] Balance of SERCA Influx',' and RyR Efflux (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'sr_in_out'),'-dpng','-r300')
% 
% 
% %% juncx_ca_srin
% close
% figure(7)
% bx = [
%       [owtF_juncx_ca_srin_in_noneTPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_TPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_srin_in_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_srin_in_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_srin_in_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% % ylabel({'Junctional [Ca] Difference of','Influxes and Effluxes (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca_srin'),'-dpng','-r300')
% 
% %% juncx_ca_srin
% close
% figure(7)
% bx = [
%       [owtF_juncx_ca_srin_in_noneTPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_TPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_srin_in_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_srin_in_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_srin_in_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% % ylabel({'Junctional [Ca] Difference of','Influxes and Effluxes (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca_srin'),'-dpng','-r300')
% 
% %% ju_in_out
% close
% figure(7)
% bx = [
%       [owtF_ju_in_out_noneTPC_1(:).integralY],...
%       [owtF_ju_in_out_TPC_1(:).integralY],...
%       [owtF_ju_in_out_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_ju_in_out_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_ju_in_out_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_ju_in_out_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-10e6 -2e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Difference of','Influxes (+) and Effluxes (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'ju_in_out'),'-dpng','-r300')
% 
% %% jucal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_jucal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_jucal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_jucal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jucal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jucal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jucal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Difference of CaL',' Influx (+) and NCX Efflux (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jucal_2ncx_ca'),'-dpng','-r300')
% 
% %% slcal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_slcal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_slcal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_slcal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_slcal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_slcal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_slcal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-6e5 0e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Sarcolemmal [Ca] Difference of CaL',' Influx (+) and NCX Efflux (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'slcal_2ncx_ca'),'-dpng','-r300')

%% bp y36 integral
figure(7)
bx = [[owt_y36_noneTPC_1(:).integralY],...
      [owt_y36_TPC_1(:).integralY],...
      [owt_y36_none_0(:).integralY],...
%       [jdot0_y36_TPC_1(:).integralY],...
%       [jdot0_y36_noneTPC_1(:).integralY],...
%       [jdot0_y36_none_0(:).integralY],...
%       [idot0_y36_TPC_1(:).integralY],...
%       [idot0_y36_noneTPC_1(:).integralY],...
%       [idot0_y36_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owt_y36_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owt_y36_TPC_1(:).integralY]), 1);...       
       2*ones(length([owt_y36_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0_y36_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0_y36_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0_y36_none_0(:).integralY]), 1);...
%        6*ones(length([idot0_y36_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0_y36_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0_y36_none_0(:).integralY]), 1);...              
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([2e6 20*1e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'bp_y36_integralbeat'),'-dpng','-r300')
% close
% %% bp y37 integral
% figure(7)
% bx = [[owt_y37_noneTPC_1(:).integralY],...
%       [owt_y37_TPC_1(:).integralY],...
%       [owt_y37_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owt_y37_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owt_y37_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owt_y37_none_0(:).integralY]), 1);...            
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([2e5 20*1e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Sarcolemma (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_y37_integralbeat'),'-dpng','-r300')
% close

% %% bp y36-y31 integral
% figure(7)
% bx = [abs([owt_y36_noneTPC_1(:).integralY] - [owt_y31_noneTPC_1(:).integralY]),...
%       abs([owt_y36_TPC_1(:).integralY] - [owt_y31_TPC_1(:).integralY]),...
%       abs([owt_y36_none_0(:).integralY] - [owt_y31_none_0(:).integralY]),...
% %       abs([jdot0_y36_TPC_1(:).integralY] - [jdot0_y31_TPC_1(:).integralY]),...
% %       abs([jdot0_y36_noneTPC_1(:).integralY] - [jdot0_y31_noneTPC_1(:).integralY]),...
% %       abs([jdot0_y36_none_0(:).integralY] - [jdot0_y31_none_0(:).integralY]),...
% %       abs([idot0_y36_TPC_1(:).integralY] - [idot0_y31_TPC_1(:).integralY]),...
% %       abs([idot0_y36_noneTPC_1(:).integralY] - [idot0_y31_noneTPC_1(:).integralY]),...
% %       abs([idot0_y36_none_0(:).integralY] - [idot0_y31_none_0(:).integralY]),...
%       ]; 
% by = [ zeros(length([owt_y36_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owt_y36_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owt_y36_none_0(:).integralY]), 1);...
% %        3*ones(length([jdot0_y36_TPC_1(:).integralY]), 1);...       
% %        4*ones(length([jdot0_y36_noneTPC_1(:).integralY]), 1);...
% %        5*ones(length([jdot0_y36_none_0(:).integralY]), 1);...
% %        6*ones(length([idot0_y36_TPC_1(:).integralY]), 1);...       
% %        7*ones(length([idot0_y36_noneTPC_1(:).integralY]), 1);...
% %        8*ones(length([idot0_y36_none_0(:).integralY]), 1);...              
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([0 23*1e7])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_y36-y31_integralbeat'),'-dpng','-r300')
% close

%% bp y31 integral
figure(7)
bx = [      [owt_y31_noneTPC_1(:).integralY],...
      [owt_y31_TPC_1(:).integralY],...
      [owt_y31_none_0(:).integralY],...
%       [jdot0_y31_TPC_1(:).integralY],...
%       [jdot0_y31_noneTPC_1(:).integralY],...
%       [jdot0_y31_none_0(:).integralY],...
%       [idot0_y31_TPC_1(:).integralY],...
%       [idot0_y31_noneTPC_1(:).integralY],...
%       [idot0_y31_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owt_y31_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owt_y31_TPC_1(:).integralY]), 1);...       
       2*ones(length([owt_y31_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0_y31_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0_y31_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0_y31_none_0(:).integralY]), 1);...
%        6*ones(length([idot0_y31_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0_y31_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0_y31_none_0(:).integralY]), 1);...              
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax.YAxis.Exponent = 7;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([-0.5e7 24*1e7])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] SR (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'bp_y31_integralbeat'),'-dpng','-r300')
close

%% bp y88 integral
close all
figure(7)
bx = [      [owt_y88_noneTPC_1(:).integralY],...
      [owt_y88_TPC_1(:).integralY],...
      [owt_y88_none_0(:).integralY],...
%       [jdot0_y88_TPC_1(:).integralY],...
%       [jdot0_y88_noneTPC_1(:).integralY],...
%       [jdot0_y88_none_0(:).integralY],...
%       [idot0_y88_TPC_1(:).integralY],...
%       [idot0_y88_noneTPC_1(:).integralY],...
%       [idot0_y88_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owt_y88_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owt_y88_TPC_1(:).integralY]), 1);...       
       2*ones(length([owt_y88_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0_y88_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0_y88_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0_y88_none_0(:).integralY]), 1);...
%        6*ones(length([idot0_y88_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0_y88_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0_y88_none_0(:).integralY]), 1);...              
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([0.5e6 13*1e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Lysosome (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'bp_y88_integralbeat'),'-dpng','-r300')
close

%% bp y38 integral
% figure(7)
% bx = [      [owt_y38_noneTPC_1(:).integralY],...
%       [owt_y38_TPC_1(:).integralY],...
%       [owt_y38_none_0(:).integralY],...
% %       [jdot0_y38_TPC_1(:).integralY],...
% %       [jdot0_y38_noneTPC_1(:).integralY],...
% %       [jdot0_y38_none_0(:).integralY],...
% %       [idot0_y38_TPC_1(:).integralY],...
% %       [idot0_y38_noneTPC_1(:).integralY],...
% %       [idot0_y38_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owt_y38_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owt_y38_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owt_y38_none_0(:).integralY]), 1);...
% %        3*ones(length([jdot0_y38_TPC_1(:).integralY]), 1);...       
% %        4*ones(length([jdot0_y38_noneTPC_1(:).integralY]), 1);...
% %        5*ones(length([jdot0_y38_none_0(:).integralY]), 1);...
% %        6*ones(length([idot0_y38_TPC_1(:).integralY]), 1);...       
% %        7*ones(length([idot0_y38_noneTPC_1(:).integralY]), 1);...
% %        8*ones(length([idot0_y38_none_0(:).integralY]), 1);...              
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','brm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([0e5 8*1e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Cytosol (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_y38_integralbeat'),'-dpng','-r300')
% close

%% bp serca integral
figure(7)
bx = [      [owtF_serca_noneTPC_1(:).integralY],...
      [owtF_serca_TPC_1(:).integralY],...
      [owtF_serca_none_0(:).integralY],...
%       [jdot0F_serca_TPC_1(:).integralY],...
%       [jdot0F_serca_noneTPC_1(:).integralY],...
%       [jdot0F_serca_none_0(:).integralY],...
%       [idot0F_serca_TPC_1(:).integralY],...
%       [idot0F_serca_noneTPC_1(:).integralY],...
%       [idot0F_serca_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_serca_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_serca_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_serca_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0F_serca_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0F_serca_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0F_serca_none_0(:).integralY]), 1);...
%        6*ones(length([idot0F_serca_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0F_serca_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0F_serca_none_0(:).integralY]), 1);...              
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([6e4 32e4])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'bp_serca_integralbeat'),'-dpng','-r300')
% close

%% bp RyR integral
close all
figure(7)
bx = [      [owtF_ryr_noneTPC_1(:).integralY],...
      [owtF_ryr_TPC_1(:).integralY],...
      [owtF_ryr_none_0(:).integralY],...
%       [jdot0F_ryr_TPC_1(:).integralY],...
%       [jdot0F_ryr_noneTPC_1(:).integralY],...
%       [jdot0F_ryr_none_0(:).integralY],...
%       [idot0F_ryr_TPC_1(:).integralY],...
%       [idot0F_ryr_noneTPC_1(:).integralY],...
%       [idot0F_ryr_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_ryr_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_ryr_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_ryr_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0F_ryr_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0F_ryr_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0F_ryr_none_0(:).integralY]), 1);...
%        6*ones(length([idot0F_ryr_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0F_ryr_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0F_ryr_none_0(:).integralY]), 1);...              
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([0.5e6 7e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'bp_ryr_integralbeat'),'-dpng','-r300')
% close


% %% bp cal integral
% figure(7)
% bx = [      [owtF_cal_noneTPC_1(:).integralY],...
%       [owtF_cal_TPC_1(:).integralY],...
%       [owtF_cal_none_0(:).integralY],...
% %       [jdot0F_cal_TPC_1(:).integralY],...
% %       [jdot0F_cal_noneTPC_1(:).integralY],...
% %       [jdot0F_cal_none_0(:).integralY],...
% %       [idot0F_cal_TPC_1(:).integralY],...
% %       [idot0F_cal_noneTPC_1(:).integralY],...
% %       [idot0F_cal_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_cal_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_cal_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_cal_none_0(:).integralY]), 1);...
% %        3*ones(length([jdot0F_cal_TPC_1(:).integralY]), 1);...       
% %        4*ones(length([jdot0F_cal_noneTPC_1(:).integralY]), 1);...
% %        5*ones(length([jdot0F_cal_none_0(:).integralY]), 1);...
% %        6*ones(length([idot0F_cal_TPC_1(:).integralY]), 1);...       
% %        7*ones(length([idot0F_cal_noneTPC_1(:).integralY]), 1);...
% %        8*ones(length([idot0F_cal_none_0(:).integralY]), 1);...              
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1.5e2 8e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'L-type Current (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_cal_integralbeat'),'-dpng','-r300')
% % close

%% bp jucal integral
close all
figure(7)
bx = [      [owtF_jucal_noneTPC_1(:).integralY],...
      [owtF_jucal_TPC_1(:).integralY],...
      [owtF_jucal_none_0(:).integralY],...
%       [jdot0F_cal_TPC_1(:).integralY],...
%       [jdot0F_cal_noneTPC_1(:).integralY],...
%       [jdot0F_cal_none_0(:).integralY],...
%       [idot0F_cal_TPC_1(:).integralY],...
%       [idot0F_cal_noneTPC_1(:).integralY],...
%       [idot0F_cal_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_jucal_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_jucal_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_jucal_none_0(:).integralY]), 1);...
%        3*ones(length([jdot0F_cal_TPC_1(:).integralY]), 1);...       
%        4*ones(length([jdot0F_cal_noneTPC_1(:).integralY]), 1);...
%        5*ones(length([jdot0F_cal_none_0(:).integralY]), 1);...
%        6*ones(length([idot0F_cal_TPC_1(:).integralY]), 1);...       
%        7*ones(length([idot0F_cal_noneTPC_1(:).integralY]), 1);...
%        8*ones(length([idot0F_cal_none_0(:).integralY]), 1);...              
       ];
   
boxplot(abs(bx), by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([1e2 8e2])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'Junctional L-type Current (pA/pF)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'jucal'),'-dpng','-r300')
% close
% %% I_ncx
% figure(7)
% bx = [abs([owtF_ncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_ncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_ncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_ncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_ncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_ncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 20e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'NCX [Ca] Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx'),'-dpng','-r300')
% % close
% 
% 
% %% bp I_ncx_junc
% figure(7)
% bx = [abs([owtF_juncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_juncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_juncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_juncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 4.6e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional NCX Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx_junc'),'-dpng','-r300')
% % close
% 
% %% bp I_ncx_sl
% figure(7)
% bx = [abs([owtF_slncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_slncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_slncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_slncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_slncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_slncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 6e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Sarcolemmal NCX [Ca]','Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx_sl'),'-dpng','-r300')
% % close
%%

% % Sjdot0
% for ipeak = 1: numel(Sjdot0_TPC_1) 
% 
% t3 = Sjdot0_TPC_1(ipeak).t;
% y3 = Sjdot0_TPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% for ipeak = 1: numel(Sjdot0_noneTPC_1) 
% 
% t3 = Sjdot0_noneTPC_1(ipeak).t;
% y3 = Sjdot0_noneTPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% for ipeak = 1: numel(Sjdot0_none_0) 
% 
% t3 = Sjdot0_none_0(ipeak).t;
% y3 = Sjdot0_none_0(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_none_0(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_none_0(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_none_0(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% % Sidot0
% for ipeak = 1: numel(Sidot0_TPC_1) 
% 
% t3 = Sidot0_TPC_1(ipeak).t;
% y3 = Sidot0_TPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end
% 
% for ipeak = 1: numel(Sidot0_noneTPC_1) 
% 
% t3 = Sidot0_noneTPC_1(ipeak).t;
% y3 = Sidot0_noneTPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end
% 
% for ipeak = 1: numel(Sidot0_none_0) 
% 
% t3 = Sidot0_none_0(ipeak).t;
% y3 = Sidot0_none_0(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_none_0(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_none_0(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_none_0(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end

% 
% % jdot0
% for ipeak = 1: numel(Fjdot0_TPC_1)
%    
% tflux = Fjdot0_TPC_1(ipeak).tArray;
% yserca = Fjdot0_TPC_1(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_TPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_TPC_1(ipeak).I_Ca_store);   
%  
% jdot0F_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2); 
% end
%  
% for ipeak = 1: numel(Fjdot0_noneTPC_1)
%    
% tflux = Fjdot0_noneTPC_1(ipeak).tArray;
% yserca = Fjdot0_noneTPC_1(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_noneTPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_noneTPC_1(ipeak).I_Ca_store);    
%  
% jdot0F_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);  
% end
%  
% for ipeak = 1: numel(Fjdot0_none_0)
%   
% tflux = Fjdot0_none_0(ipeak).tArray;
% yserca = Fjdot0_none_0(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_none_0(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_none_0(ipeak).I_Ca_store);    
%  
% jdot0F_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);   
% end
% 
% %idot0
% for ipeak = 1: numel(Fidot0_TPC_1)
%    
% tflux = Fidot0_TPC_1(ipeak).tArray;
% yserca = Fidot0_TPC_1(ipeak).Jserca.*1e6;    
% yryr = Fidot0_TPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_TPC_1(ipeak).I_Ca_store);  
%  
% idot0F_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
%  
% for ipeak = 1: numel(Fidot0_noneTPC_1)
%    
% tflux = Fidot0_noneTPC_1(ipeak).tArray;
% yserca = Fidot0_noneTPC_1(ipeak).Jserca.*1e6;    
% yryr = Fidot0_noneTPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_noneTPC_1(ipeak).I_Ca_store);   
%  
% idot0F_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
%  
% for ipeak = 1: numel(Fidot0_none_0)
%   
% tflux = Fidot0_none_0(ipeak).tArray;
% yserca = Fidot0_none_0(ipeak).Jserca.*1e6;    
% yryr = Fidot0_none_0(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_none_0(ipeak).I_Ca_store);   
%  
% idot0F_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
