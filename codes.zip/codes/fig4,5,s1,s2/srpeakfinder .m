function Fpeak = srpeakfinder(T,Y,rate1, rate2)

[TFmin3w,~] = islocalmin(abs(Y),'MinProminence',max(abs(Y))/rate1);
if abs(Y(end)) > max(abs(Y))*1.3
TFmin3w(end) = 1;
end 
peakidx = find(TFmin3w);
[TFmax3w,~] = islocalmax(abs(Y),'MinProminence',max(abs(Y))/rate2);
valleyidx = find(TFmax3w);

% find the main before 200ms
[~, T300_id] = min(abs(T- 200));
Y300 = Y(T300_id);
T300_idx = find(Y == Y300);
peakidx_beforeT300 = peakidx(find(peakidx < T300_idx)); % 1 or >1
if isempty(peakidx_beforeT300)
peakidx_beforeT300 = 1;
Fpeak.peakidx_beforeT300 = peakidx_beforeT300; % if no first peak, there must be a previous dad peak peaking at or before the beat start 
else   
peakidx_beforeT300 = peakidx_beforeT300(end); % for >1, use the last
Fpeak.peakidx_beforeT300 = peakidx_beforeT300; 
end

Fpeak.peakI = peakidx_beforeT300;

% find extra peaks id after the main before 200ms
dadid = peakidx(find(peakidx > peakidx_beforeT300));

% find extra valleys id after main      
valleyidx = valleyidx(find(valleyidx > peakidx_beforeT300));  

% find the largest valley id
valleylist = Y(valleyidx);
[~, ivalley] = max(valleylist);
valleyid = valleyidx(ivalley);

Fpeak.endid = numel(T);

if isempty(valleyidx)
Y_decay = Y(peakidx_beforeT300:end);
[~, iminY_decay] = min(abs(Y_decay-Y(1)));

valleyid = peakidx_beforeT300 + iminY_decay -1; % modify 29 jun
if valleyid == numel(T)
   valleyid = valleyid -1; 
end                                          %
    
Fpeak.valleyI = valleyid;  
else
Fpeak.valleyI = valleyid;  
end
Fpeak.valleyIlist = valleyidx;
Fpeak.valleyTlist = T(valleyidx); 
%% integral below max line 
% maxY = max(Y);
% yline = linspace(maxY,maxY,numel(Y(1:end)));
% xline = linspace(T(1),T(end),numel(T(1:end)));
% Fpeak.peak_integral = nan;
% Fpeak.dad_integral = nan;
% Fpeak.integralY = trapz(xline,yline) - trapz(T,Y);              % 10hz not for jdot0_vs_1 mean and median

%% integral peak + dad
% if numel(dadid) >= 1
% % peak integral
% [peakmaxY,~] = max([Y(1),Y(valleyid)]);                    
% yline  = linspace(peakmaxY,peakmaxY,numel(Y(1:valleyid)));
% xline = linspace(T(1),T(valleyid),numel(T(1:valleyid)));
% Fpeak.peak_integral = trapz(xline, yline) - trapz(T(1:valleyid),Y(1:valleyid));
% % dad integral
% [dadmaxY,~] = max([Y(valleyid),Y(end)]);
% yline  = linspace(dadmaxY,dadmaxY,numel(Y(valleyid:end)));
% xline = linspace(T(valleyid),T(end),numel(T(valleyid:end)));
% Fpeak.dad_integral = trapz(xline, yline) - trapz(T(valleyid:end),Y(valleyid:end));
% 
% Fpeak.integralY = Fpeak.peak_integral + Fpeak.dad_integral;      % 10hz not for jdot0_vs_1 mean and median 
% else
% % peak integral
% % yline  = linspace(Y(valleyid),Y(valleyid),numel(Y(1:valleyid)));   % not for 10hz
% yline  = linspace(Y(1),Y(valleyid),numel(Y(1:valleyid)));        % jdot0_vs_1  not for 10hz
% xline = linspace(T(1),T(valleyid),numel(T(1:valleyid)));
% Fpeak.peak_integral = trapz(xline, yline) - trapz(T(1:valleyid),Y(1:valleyid));
% % dad integral
% yline  = linspace(Y(valleyid),Y(end),numel(Y(valleyid:end)));
% xline = linspace(T(valleyid),T(end),numel(T(valleyid:end)));
% Fpeak.dad_integral = trapz(xline, yline) - trapz(T(valleyid:end),Y(valleyid:end));
% 
% Fpeak.integralY = Fpeak.peak_integral + Fpeak.dad_integral;
% end

%%
% if numel(dadid) >= 1
% peak integral
% [peakmaxY,~] = max([Y(1),Y(valleyid)]);    


% [dadmaxY0,~] = max([Y(valleyid),Y(1)]);
% yline  = linspace(dadmaxY0,dadmaxY0,numel(Y(1:valleyid))); %jdot0_vs_1, 10hz

yline  = linspace(Y(valleyid),Y(valleyid),numel(Y(1:valleyid))); %jdot0_vs_1, 10hz
xline = linspace(T(1),T(valleyid),numel(T(1:valleyid)));
Fpeak.peak_integral = trapz(xline, yline) - trapz(T(1:valleyid),Y(1:valleyid));
% dad integral
[dadmaxY,~] = max([Y(valleyid),Y(end)]);
yline  = linspace(dadmaxY,dadmaxY,numel(Y(valleyid:end)));
xline = linspace(T(valleyid),T(end),numel(T(valleyid:end)));
Fpeak.dad_integral = trapz(xline, yline) - trapz(T(valleyid:end),Y(valleyid:end));

Fpeak.integralY = Fpeak.peak_integral + Fpeak.dad_integral;      




% else
% % peak integral
% yline  = linspace(Y(valleyid),Y(valleyid),numel(Y(1:valleyid)));   
% yline  = linspace(Y(1),Y(valleyid),numel(Y(1:valleyid)));        
% xline = linspace(T(1),T(valleyid),numel(T(1:valleyid)));
% Fpeak.peak_integral = trapz(xline, yline) - trapz(T(1:valleyid),Y(1:valleyid));
% % dad integral
% yline  = linspace(Y(valleyid),Y(end),numel(Y(valleyid:end)));
% xline = linspace(T(valleyid),T(end),numel(T(valleyid:end)));
% Fpeak.dad_integral = trapz(xline, yline) - trapz(T(valleyid:end),Y(valleyid:end));
% 
% Fpeak.integralY = Fpeak.peak_integral + Fpeak.dad_integral;
% end    
end