clear all
close all

cd ~/downloads/SS/h1_cao1_p123_
load h1_cao1_sf1000_sf343_0.mat

cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
load y175_WT_herz25_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Sw = S(h1_cao1_sf1000_sf343_0);

load y175_i_dot0_herz25_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Si = S(h1_cao1_sf1000_sf343_0);

load y175_j_dot0_herz25_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Sj = S(h1_cao1_sf1000_sf343_0);

% rate1 = 1.3;

    peakrate = 1000
    bumprate = 0.16
%% beat1
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-1e3));
    Yw = Sw(ipeak).y(1:b1ind,38).*1e6;
    Tw = Sw(ipeak).t(1:b1ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-1e3));
    Yi = Si(ipeak).y(1:b1ind,38).*1e6;
    Ti = Si(ipeak).t(1:b1ind);    

    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h25_beat1_w_bump = find([Peak_wT1(:).bump]==1);
h25_beat1_i_bump = find([Peak_iT1(:).bump]==1);

%id 1-343
lin343 = linspace(1,343,343);
h25_beat1_w_nobump = lin343(find(ismember(lin343,h25_beat1_w_bump)~=1));
h25_beat1_i_nobump = lin343(find(ismember(lin343,h25_beat1_i_bump)~=1));

h25_beat1_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h25_beat1_w_0 = find([Peak_wT1(:).peaknumel]<2);
h25_beat1_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h25_beat1_i_0 = find([Peak_iT1(:).peaknumel]<2);
%nobump
h25_beat1_w_1 = intersect(h25_beat1_w_1,h25_beat1_w_nobump);
h25_beat1_w_0 = intersect(h25_beat1_w_0,h25_beat1_w_nobump);
h25_beat1_i_1 = intersect(h25_beat1_i_1,h25_beat1_i_nobump);
h25_beat1_i_0 = intersect(h25_beat1_i_0,h25_beat1_i_nobump);

h25_beat1_w1i0 = intersect(h25_beat1_w_1,h25_beat1_i_0);
h25_beat1_w1i1 = intersect(h25_beat1_w_1,h25_beat1_i_1);

cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat1_w_1.mat','h25_beat1_w_1');

beat1_1 = h25_beat1_w1i0;

for ip = 1:numel(beat1_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat1_1(ip)).t,Sw(beat1_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat1_1(ip)).t,Si(beat1_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat1_ca'),'-dpng','-r300');
% close 
%% beat 2-5
    peakrate = 200
    bumprate = 0.16
% beat2
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-1e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-2e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-1e3));
    [~,b2ind] = min(abs(Si(ipeak).t-2e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h25_beat2_w_bump = find([Peak_wT1(:).bump]==1);
h25_beat2_i_bump = find([Peak_iT1(:).bump]==1);
 
%id 1-343
lin343 = linspace(1,343,343);
h25_beat2_w_nobump = lin343(find(ismember(lin343,h25_beat2_w_bump)~=1));
h25_beat2_i_nobump = lin343(find(ismember(lin343,h25_beat2_i_bump)~=1));
 
h25_beat2_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h25_beat2_w_0 = find([Peak_wT1(:).peaknumel]<2);
h25_beat2_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h25_beat2_i_0 = find([Peak_iT1(:).peaknumel]<2);
%nobump
h25_beat2_w_1 = intersect(h25_beat2_w_1,h25_beat2_w_nobump);
h25_beat2_w_0 = intersect(h25_beat2_w_0,h25_beat2_w_nobump);
h25_beat2_i_1 = intersect(h25_beat2_i_1,h25_beat2_i_nobump);
h25_beat2_i_0 = intersect(h25_beat2_i_0,h25_beat2_i_nobump);
 
h25_beat2_w1i0 = intersect(h25_beat2_w_1,h25_beat2_i_0);
h25_beat2_w1i1 = intersect(h25_beat2_w_1,h25_beat2_i_1);
 
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat2_w_1.mat','h25_beat2_w_1');
 
beat2_1 = h25_beat2_w1i0;
 
for ip = 1:numel(beat2_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat2_1(ip)).t,Sw(beat2_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat2_1(ip)).t,Si(beat2_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat2_ca'),'-dpng','-r300');
% close 
%% beat3
close all  
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-2e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-3e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-2e3));
    [~,b2ind] = min(abs(Si(ipeak).t-3e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h25_beat3_w_bump = find([Peak_wT1(:).bump]==1);
h25_beat3_i_bump = find([Peak_iT1(:).bump]==1);
 
%id 1-343
lin343 = linspace(1,343,343);
h25_beat3_w_nobump = lin343(find(ismember(lin343,h25_beat3_w_bump)~=1));
h25_beat3_i_nobump = lin343(find(ismember(lin343,h25_beat3_i_bump)~=1));
 
h25_beat3_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h25_beat3_w_0 = find([Peak_wT1(:).peaknumel]<2);
h25_beat3_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h25_beat3_i_0 = find([Peak_iT1(:).peaknumel]<2);
%nobump
h25_beat3_w_1 = intersect(h25_beat3_w_1,h25_beat3_w_nobump);
h25_beat3_w_0 = intersect(h25_beat3_w_0,h25_beat3_w_nobump);
h25_beat3_i_1 = intersect(h25_beat3_i_1,h25_beat3_i_nobump);
h25_beat3_i_0 = intersect(h25_beat3_i_0,h25_beat3_i_nobump);
 
h25_beat3_w1i0 = intersect(h25_beat3_w_1,h25_beat3_i_0);
h25_beat3_w1i1 = intersect(h25_beat3_w_1,h25_beat3_i_1);
 
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat3_w_1.mat','h25_beat3_w_1');
  
 
beat3_1 = h25_beat3_w1i0;
 
for ip = 1:numel(beat3_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat3_1(ip)).t,Sw(beat3_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat3_1(ip)).t,Si(beat3_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat3_ca'),'-dpng','-r300');
% close 
%% beat4
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-3e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-4e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-3e3));
    [~,b2ind] = min(abs(Si(ipeak).t-4e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h25_beat4_w_bump = find([Peak_wT1(:).bump]==1);
h25_beat4_i_bump = find([Peak_iT1(:).bump]==1);
 
%id 1-343
lin343 = linspace(1,343,343);
h25_beat4_w_nobump = lin343(find(ismember(lin343,h25_beat4_w_bump)~=1));
h25_beat4_i_nobump = lin343(find(ismember(lin343,h25_beat4_i_bump)~=1));
 
h25_beat4_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h25_beat4_w_0 = find([Peak_wT1(:).peaknumel]<2);
h25_beat4_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h25_beat4_i_0 = find([Peak_iT1(:).peaknumel]<2);
%nobump
h25_beat4_w_1 = intersect(h25_beat4_w_1,h25_beat4_w_nobump);
h25_beat4_w_0 = intersect(h25_beat4_w_0,h25_beat4_w_nobump);
h25_beat4_i_1 = intersect(h25_beat4_i_1,h25_beat4_i_nobump);
h25_beat4_i_0 = intersect(h25_beat4_i_0,h25_beat4_i_nobump);
 
h25_beat4_w1i0 = intersect(h25_beat4_w_1,h25_beat4_i_0);
h25_beat4_w1i1 = intersect(h25_beat4_w_1,h25_beat4_i_1);
 
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat4_w_1.mat','h25_beat4_w_1');
   
 
beat4_1 = h25_beat4_w1i0;
 
for ip = 1:numel(beat4_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat4_1(ip)).t,Sw(beat4_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat4_1(ip)).t,Si(beat4_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat4_ca'),'-dpng','-r300');
% close 
%% beat5
close all    
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-4e3));
    Yw = Sw(ipeak).y(b1ind:end,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:end);
    
    [~,b1ind] = min(abs(Si(ipeak).t-4e3));
    Yi = Si(ipeak).y(b1ind:end,38).*1e6;
    Ti = Si(ipeak).t(b1ind:end);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h25_beat5_w_bump = find([Peak_wT1(:).bump]==1);
h25_beat5_i_bump = find([Peak_iT1(:).bump]==1);
 
%nobump
%id 1-343
lin343 = linspace(1,343,343);
h25_beat5_w_nobump = lin343(find(ismember(lin343,h25_beat5_w_bump)~=1));
h25_beat5_i_nobump = lin343(find(ismember(lin343,h25_beat5_i_bump)~=1));
 
h25_beat5_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h25_beat5_w_0 = find([Peak_wT1(:).peaknumel]<2);
h25_beat5_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h25_beat5_i_0 = find([Peak_iT1(:).peaknumel]<2);

h25_beat5_w_1 = intersect(h25_beat5_w_1,h25_beat5_w_nobump);
h25_beat5_w_0 = intersect(h25_beat5_w_0,h25_beat5_w_nobump);
h25_beat5_i_1 = intersect(h25_beat5_i_1,h25_beat5_i_nobump);
h25_beat5_i_0 = intersect(h25_beat5_i_0,h25_beat5_i_nobump);
 
h25_beat5_w1i0 = intersect(h25_beat5_w_1,h25_beat5_i_0);
h25_beat5_w1i1 = intersect(h25_beat5_w_1,h25_beat5_i_1);
 
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat5_w_1.mat','h25_beat5_w_1'); 
 
beat5_1 = h25_beat5_w1i0;
 
for ip = 1:numel(beat5_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat5_1(ip)).t,Sw(beat5_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat5_1(ip)).t,Si(beat5_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% close 
%%
h25_w_1 = unique([h25_beat1_w_1, h25_beat2_w_1, h25_beat3_w_1,h25_beat4_w_1, h25_beat5_w_1]);  
h25_w_0 = intersect(intersect(intersect(intersect(h25_beat1_w_0, h25_beat2_w_0), h25_beat3_w_0),h25_beat4_w_0), h25_beat5_w_0);  
  
h25_i_1 = unique([h25_beat1_i_1, h25_beat2_i_1, h25_beat3_i_1,h25_beat4_i_1, h25_beat5_i_1]);  
h25_i_0 = intersect(intersect(intersect(intersect(h25_beat1_i_0, h25_beat2_i_0), h25_beat3_i_0),h25_beat4_i_0), h25_beat5_i_0);  
  
h25_w1_not_i1 = h25_w_1(find(ismember(h25_w_1,h25_i_1)~=1));
h25_w1i0 = intersect(h25_w_1,h25_i_0);
% 
find(ismember(h25_w1_not_i1,h25_w1i0)==0)
find(ismember(h25_w1i0,h25_w1_not_i1)==0)

h25_iTPC1 = h25_w1_not_i1;
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_iTPC1.mat','h25_iTPC1');

h25_inoneTPC1_w1_not_w1i0 = h25_w_1(find(ismember(h25_w_1,h25_iTPC1)~=1));
h25_inoneTPC1_w1i1 = intersect(h25_w_1,h25_i_1);

find(ismember(h25_inoneTPC1_w1_not_w1i0,h25_inoneTPC1_w1i1)==0)
find(ismember(h25_inoneTPC1_w1i1,h25_inoneTPC1_w1_not_w1i0)==0)

h25_inoneTPC1 = h25_inoneTPC1_w1i1;
save('h25_inoneTPC1.mat','h25_inoneTPC1');

h25_inone_0= intersect(h25_w_0,h25_i_0);
save('h25_inone_0.mat','h25_inone_0');
%
beat5_1 = h25_inone_0;
 
for ip = 1:numel(beat5_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat5_1(ip)).t,Sw(beat5_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat5_1(ip)).t,Si(beat5_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% close 
%% jdot0 id 1 343
for ipeak = 1: numel(h25_iTPC1)
    [~,b1ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-1e3));
    Yj = Sj(h25_iTPC1(ipeak)).y(1:b1ind,38).*1e6;
    Tj = Sj(h25_iTPC1(ipeak)).t(1:b1ind);  
    Peak_jT1(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h25_beat1_j_bump = find([Peak_jT1(:).bump]==1);

%id 1-h25_iTPC1
lin_h25_iTPC1 = linspace(1,numel(h25_iTPC1),numel(h25_iTPC1));
h25_beat1_j_nobump = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_beat1_j_bump)~=1));

h25_beat1_j_1 = find([Peak_jT1(:).peaknumel]>=2);
h25_beat1_j_0 = find([Peak_jT1(:).peaknumel]<2);

h25_beat1_j_1 = intersect(h25_beat1_j_1,h25_beat1_j_nobump);
h25_beat1_j_0 = intersect(h25_beat1_j_0,h25_beat1_j_nobump);

h25_beat1_343_j_1 = h25_iTPC1(h25_beat1_j_1);
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat1_343_j_1.mat','h25_beat1_343_j_1'); 

for ipeak = 1: numel(h25_iTPC1)
    [~,b1ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-1e3));
    [~,b2ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-2e3));
    Yj = Sj(h25_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h25_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT2(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h25_beat2_j_bump = find([Peak_jT2(:).bump]==1);
 
%id 1-h25_iTPC1
lin_h25_iTPC1 = linspace(1,numel(h25_iTPC1),numel(h25_iTPC1));
h25_beat2_j_nobump = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_beat2_j_bump)~=1));
 
h25_beat2_j_1 = find([Peak_jT2(:).peaknumel]>=2);
h25_beat2_j_0 = find([Peak_jT2(:).peaknumel]<2);
 
h25_beat2_j_1 = intersect(h25_beat2_j_1,h25_beat2_j_nobump);
h25_beat2_j_0 = intersect(h25_beat2_j_0,h25_beat2_j_nobump);

h25_beat2_343_j_1 = h25_iTPC1(h25_beat2_j_1);
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat2_343_j_1.mat','h25_beat2_343_j_1'); 

for ipeak = 1: numel(h25_iTPC1)
    [~,b1ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-2e3));
    [~,b2ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-3e3));
    Yj = Sj(h25_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h25_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT3(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h25_beat3_j_bump = find([Peak_jT3(:).bump]==1);
 
%id 1-h25_iTPC1
lin_h25_iTPC1 = linspace(1,numel(h25_iTPC1),numel(h25_iTPC1));
h25_beat3_j_nobump = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_beat3_j_bump)~=1));
 
h25_beat3_j_1 = find([Peak_jT3(:).peaknumel]>=2);
h25_beat3_j_0 = find([Peak_jT3(:).peaknumel]<2);
 
h25_beat3_j_1 = intersect(h25_beat3_j_1,h25_beat3_j_nobump);
h25_beat3_j_0 = intersect(h25_beat3_j_0,h25_beat3_j_nobump);

h25_beat3_343_j_1 = h25_iTPC1(h25_beat3_j_1);
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat3_343_j_1.mat','h25_beat3_343_j_1'); 

for ipeak = 1: numel(h25_iTPC1)
    [~,b1ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-3e3));
    [~,b2ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-4e3));
    Yj = Sj(h25_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h25_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT4(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h25_beat4_j_bump = find([Peak_jT4(:).bump]==1);
 
%id 1-h25_iTPC1
lin_h25_iTPC1 = linspace(1,numel(h25_iTPC1),numel(h25_iTPC1));
h25_beat4_j_nobump = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_beat4_j_bump)~=1));
 
h25_beat4_j_1 = find([Peak_jT4(:).peaknumel]>=2);
h25_beat4_j_0 = find([Peak_jT4(:).peaknumel]<2);
 
h25_beat4_j_1 = intersect(h25_beat4_j_1,h25_beat4_j_nobump);
h25_beat4_j_0 = intersect(h25_beat4_j_0,h25_beat4_j_nobump);

h25_beat4_343_j_1 = h25_iTPC1(h25_beat4_j_1);
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat4_343_j_1.mat','h25_beat4_343_j_1'); 

for ipeak = 1: numel(h25_iTPC1)
    [~,b1ind] = min(abs(Sj(h25_iTPC1(ipeak)).t-4e3));
    Yj = Sj(h25_iTPC1(ipeak)).y(b1ind:end,38).*1e6;
    Tj = Sj(h25_iTPC1(ipeak)).t(b1ind:end);  
    Peak_jT5(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h25_beat5_j_bump = find([Peak_jT5(:).bump]==1);
 
%id 1-h25_iTPC1
lin_h25_iTPC1 = linspace(1,numel(h25_iTPC1),numel(h25_iTPC1));
h25_beat5_j_nobump = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_beat5_j_bump)~=1));
 
h25_beat5_j_1 = find([Peak_jT5(:).peaknumel]>=2);
h25_beat5_j_0 = find([Peak_jT5(:).peaknumel]<2);
 
h25_beat5_j_1 = intersect(h25_beat5_j_1,h25_beat5_j_nobump);
h25_beat5_j_0 = intersect(h25_beat5_j_0,h25_beat5_j_nobump);

h25_beat5_343_j_1 = h25_iTPC1(h25_beat5_j_1);
cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_beat5_343_j_1.mat','h25_beat5_343_j_1'); 

h25_j_0 = intersect(intersect(intersect(intersect(h25_beat1_j_0, h25_beat2_j_0), h25_beat3_j_0),h25_beat4_j_0), h25_beat5_j_0);  
h25_j_1 = lin_h25_iTPC1(find(ismember(lin_h25_iTPC1,h25_j_0)~=1)); 

h25_iTPC1_jdot_0 = h25_j_0;
h25_iTPC1_jdot_1 = h25_j_1;


cd ~/downloads/SS/h50_cao1_p3_/h25_cao1_p3__sf1000
save('h25_iTPC1_jdot_0.mat','h25_iTPC1_jdot_0');
save('h25_iTPC1_jdot_1.mat','h25_iTPC1_jdot_1');
%%
close all
beat5_1 = h25_j_1;
for ip = 1:numel(beat5_1)
    
    figure(1);
    plot(Sj(h25_iTPC1(beat5_1(ip))).t,Sj(h25_iTPC1(beat5_1(ip))).y(:,38).*1e6,'Color','#0000FF'); hold on

end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% close 
%%
function Peak = ca_peak_nobump(T,Y,peakrate,bumprate)
    rate1 = 1.25;
    [TF,~] = islocalmax(Y,'MinProminence',max(Y)/peakrate);
    id = find(TF); 
    if abs(Y(end)) > min(abs(Y))*rate1
    TF(end) = 1;
    end 
    Peak.peaknumel =numel(find(TF));
    
    if numel(id) == 2 && (Y(id(2)) - min(Y))/(max(Y) - min(Y)) < bumprate && T(id(2)) < 500 +T(1)
%     Peak.bump_w_ratio = (Y(id(2)) - min(Y))/(max(Y) - min(Y));
    Peak.bump = 1; 
    else
%     Peak.bump_w_amplist = 0;
    Peak.bump = 0;     
    end

end