%% Main file: morotti_et_al_mouse_masterCompute
% 
% Please cite the following paper when using this model:
% Morotti S, Edwards AG, McCulloch AD, Bers DM & Grandi E. (2014). A novel
% computational model of mouse myocyte electrophysiology to assess the 
% synergy between Na(+) loading and CaMKII. Journal of Physiology, doi:
% 10.1113/jphysiol.2013.266676.
% 
% This model was built upon the code of the Soltis and Saucerman model
% of rabbit ventricular EC coupling.
% Reference: Soltis AR & Saucerman JJ. (2010). Synergy between CaMKII 
% substrates and beta-adrenergic signaling in regulation of cardiac
% myocyte Ca(2+) handling. Biophysical Journal 99, 2038-2047.
% 
% This file loads initial conditions, calls the ode solver and plots
% simulation results.

close all;
clear all; 
clc;

% cd /home/phar0790/Ls_mv
% addpath(pwd)



cd ~/downloads/SS/h1_cao1dot8_p3_/h1_cao1dot8_p3_sf1000
load sf1000_y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S3w = S;
load sf1000_y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S3i = S;
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat 
S3j = S;
%% WT >> idot0 >> jdot0
Ss =  [S3w; S3i; S3j]';

mkdir ./h1_cao1dot8_sf1000_FLUX_
savepath = [pwd, '/h1_cao1dot8_sf1000_FLUX_'];
%% ODE solver
% opts = odeset('RelTol',1e-5,'MaxStep',2);
opts = odeset('RelTol',1e-5);

% delete(gcp('nocreate'));
% pl = parpool('local',2);
% addAttachedFiles(pl,{'lhs_masterODE3wo.m','lhs_eccODEfile3wo.m'})

%% 1     2     3     4        5      6     7      8     9
%  ls_j, ls_i, kls2, J_serca, J_RyR, I_ncx,I_CaL, I_to, I_kr
rng('default');                 % for reproducibility of results
lhs_p = 9;                     % number of parameters
lhs_n = 1000;                     % number of models (combinations)  

X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);  
sf_tot = sf;
size(sf_tot,1)
%%     1)WT 2)naadp 3)iso,naadp=15
ligtot = [0, 0, 0.1];             %0.1 [uM] - SET LIGAND CONCENTRATION (0 or 0.1)
naadp = [1, 15, 15];              % 1:ctrl 15:naadp_am
protocol = {'wt','naadp','iso15'};
% load y175_0             %  CTRL, naadp
% load y175_0_ori_iso     %  ISO, var= y175_0_ori_iso
iprotocol = 3                         
Ligtot = ligtot(iprotocol);
Naadp = naadp(iprotocol);

freq = 1;
iteration = 150;
CaO = 1.8 % 1.8 Extracellular Ca  [mM] MOUSE % 1.8 mM in RABBIT

%% WT >> idot0 >> jdot0
ls_flag = {'WT','idot0', 'jdot0'}; % WT, jdot0, idot0

i = 1;
for j = 1: numel(ls_flag)
lsexp = ls_flag{j}  
S = [Ss(:,i)];
i

sf = sf_tot;

if strcmp(lsexp,'WT') 
    jdot = 1;      
    idot = 1;     
    
    ssname = 'y175_WT_herz1_cao1dot8';
    fluxname = 'y175_FLUX_WT_herz1_cao1dot8';
    
elseif strcmp(lsexp,'jdot0')
    jdot = 0;     
    idot = 1;     
    
    lsj_0 = sf(:,1).*0;
    sf(:,1) = lsj_0;
    ssname = 'y175_WT_j_dot0_cao1dot8';
    fluxname = 'y175_FLUX_WT_j_dot0_cao1dot8';
    
elseif strcmp(lsexp,'idot0')
    jdot = 1;      
    idot = 0;      
    
    lsi_0 = sf(:,2).*0;
    sf(:,2) = lsi_0;
    ssname = 'y175_WT_i_dot0_cao1dot8';
    fluxname = 'y175_FLUX_WT_i_dot0_cao1dot8';
   
end
%% Parameters for external modules

% ECC and CaM modules
% freq = 1;                   % [Hz] - CHANGE DEPENDING ON FREQUENCY
% cycleLength = 1e3/freq;     % [ms]
CaMtotDyad = 418;           % [uM]
BtotDyad = 1.54/8.293e-4;   % [uM]
CaMKIItotDyad = 120;        % [uM]
CaNtotDyad = 3e-3/8.293e-4; % [uM]
PP1totDyad = 96.5;          % [uM]
CaMtotSL = 5.65;            % [uM]
BtotSL = 24.2;              % [uM]
CaMKIItotSL = 120*8.293e-4; % [uM]
CaNtotSL = 3e-3;            % [uM]
PP1totSL = 0.57;            % [uM]
CaMtotCyt = 5.65;           % [uM]
BtotCyt = 24.2;             % [uM]
CaMKIItotCyt = 120*8.293e-4;% [uM]
CaNtotCyt = 3e-3;           % [uM] 
PP1totCyt = 0.57;           % [uM]

% ADJUST CaMKII ACTIVITY LEVELS (expression = 'WT', 'OE', or 'KO')
expression = 'WT';

CKIIOE = 0; % Should be zero during 'WT' and 'KO' runs
if strcmp(expression,'OE') % OE
    CKIIOE = 1; % Flag for CaMKKII-OE (0=WT, 1=OE)
    n_OE=6;
    CaMKIItotDyad = 120*n_OE;         % [uM] 
    CaMKIItotSL = 120*8.293e-4*n_OE;  % [uM]
    CaMKIItotCyt = 120*8.293e-4*n_OE; % [uM]
elseif strcmp(expression,'KO')
    CaMKIItotDyad = 0;          % [uM] 
    CaMKIItotSL = 0;            % [uM]
    CaMKIItotCyt = 0;           % [uM]
end

%plb_val=38; % RABBIT
plb_val=106; % MOUSE

% Parameters for CaMKII module
LCCtotDyad = 31.4*.9;       % [uM] - Total Dyadic [LCC] - (umol/l dyad)
LCCtotSL = 0.0846;          % [uM] - Total Subsarcolemmal [LCC] (umol/l sl)
RyRtot = 382.6;             % [uM] - Total RyR (in Dyad)
PP1_dyad = 95.7;            % [uM] - Total dyadic [PP1]
PP1_SL = 0.57;              % [uM] - Total Subsarcolemmal [PP1]
PP2A_dyad = 95.76;          % [uM] - Total dyadic PP2A
OA = 0;                     % [uM] - PP1/PP2A inhibitor Okadaic Acid
PLBtot = plb_val;           % [uM] - Total [PLB] in cytosolic units

% Parameters for BAR module
% Ligtot = 0;%0.1             % [uM] - SET LIGAND CONCENTRATION (0 or 0.1)
LCCtotBA = 0.025;           % [uM] - [umol/L cytosol]
RyRtotBA = 0.135;           % [uM] - [umol/L cytosol]
PLBtotBA = plb_val;         % [uM] - [umol/L cytosol]
TnItotBA = 70;              % [uM] - [umol/L cytosol]
IKstotBA = 0.025;           % [uM] - [umol/L cytosol]
ICFTRtotBA = 0.025;         % [uM] - [umol/L cytosol]
PP1_PLBtot = 0.89;          % [uM] - [umol/L cytosol]
IKurtotBA = 0.025;          % [uM] - [umol/L cytosol] MOUSE
PLMtotBA = 48;              % [uM] - [umol/L cytosol] MOUSE

% For Recovery from inactivation of LTCC
recoveryTime = 10; % initialize to smallest value

% Parameter varied in protocol simulation
variablePar = 20; % initilization
%% Collect all parameters and define mass matrix for BAR module

% p = [cycleLength,recoveryTime,variablePar,CaMtotDyad,BtotDyad,CaMKIItotDyad,...
%     CaNtotDyad,PP1totDyad,CaMtotSL,BtotSL,CaMKIItotSL,CaNtotSL,PP1totSL,...
%     CaMtotCyt,BtotCyt,CaMKIItotCyt,CaNtotCyt,PP1totCyt,...
%     LCCtotDyad,RyRtot,PP1_dyad,PP2A_dyad,OA,PLBtot,LCCtotSL,PP1_SL,...
%     Ligtot,LCCtotBA,RyRtotBA,PLBtotBA,TnItotBA,IKstotBA,ICFTRtotBA,...
%     PP1_PLBtot,IKurtotBA,PLMtotBA,CKIIOE];
% %% Establish and define global variables

% global tStep tArray I_Ca_store I_to_store I_Na_store I_K1_store ibar_store 
% global gates Jserca IKs_store Jleak ICFTR Incx
% global I_ss_store dVm_store Ipca_store I_NaK_store I_Nabk_store I_kr_store
% global I_kur1_store I_kur2_store

% I_Ca_store=zeros(1,1e6);
% I_to_store=zeros(3,1e6);
% I_Na_store = zeros(1,1e6);
% I_K1_store = zeros(1,1e6);
% ibar_store=zeros(1,1e6);
% gates = zeros(2,1e6);
% Jserca = zeros(1,1e6);
% IKs_store = zeros(1,1e6);
% Jleak = zeros(1e6,2);
% ICFTR = zeros(1,1e6);
% Incx = zeros(1,1e6);
% I_kur1_store = zeros(1,1e6);
% I_kur2_store = zeros(1,1e6);
% I_ss_store = zeros(1,1e6);
% dVm_store = zeros(1,1e6);
% Ipca_store = zeros(1,1e6);
% I_NaK_store = zeros(1,1e6);
% I_Nabk_store = zeros(1,1e6);
% I_kr_store = zeros(1,1e6);
%% Assign initial conditions

% WT %%%%%%%%%%%%%%%%%%%%%%%
% load yfin_WT_1Hz
%load yfin_WT_1Hz_120sISO
%load yfin_WT_NaGain_1Hz
% CaMKII-OE %%%%%%%%%%%%%%%%
%load yfin_OE_1Hz
%load yfin_OE_loop_1Hz
%load yfin_OE_NoNaGain_1Hz
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% y0n=yfinal;

% 0. Options and variables that always remain unaltered
% Constant parameters
p0 = [recoveryTime,variablePar,CaMtotDyad,BtotDyad,...
 CaMKIItotDyad,CaNtotDyad,PP1totDyad,CaMtotSL,BtotSL,CaMKIItotSL,...
 CaNtotSL,PP1totSL,CaMtotCyt,BtotCyt,CaMKIItotCyt,CaNtotCyt,...
 PP1totCyt,LCCtotDyad,RyRtot,PP1_dyad,PP2A_dyad,OA,PLBtot,LCCtotSL,...
 PP1_SL,Ligtot,LCCtotBA,RyRtotBA,PLBtotBA,TnItotBA,IKstotBA,...
 ICFTRtotBA,PP1_PLBtot,IKurtotBA,PLMtotBA,CKIIOE,Naadp,jdot,idot,CaO];
tic
%% 
parfor imodel = 1: size(sf,1) 

%     fprintf('Model %d of %d\n',imodel,size(sf106,1));
       cycleLength = 1e3/freq; % [ms]
       tspan = [0 cycleLength];
       p = [cycleLength,p0];
%% run from ori states
%        YFINAL = [yfinal,yfinal,y175_0_ori_iso];
%        y0n = YFINAL(:,iprotocol);
%%
%        for iter = 1:iteration
%        [t,y] = ode15s(@lhs_masterODE3cao,tspan,y0n,opts,p,sf(imodel,:));
%        y0n = y(end,:)';
%        end
%% fluxes           
%     global tStep tArray Jserca J_RyR I_Ca_store Incx JLS2J JLS2I
%     tStep = 1;
%     tArray = zeros(1,1e6);
%     Jserca = zeros(1,1e6);
%     J_RyR = zeros(1,1e6);
%     I_Ca_store = zeros(1,1e6);
%     Incx = zeros(1,1e6);
%     JLS2J = zeros(1,1e6);
%     JLS2I = zeros(1,1e6);
%     y0n = S(imodel).y0n;
%     [t,y] = ode15s(@lhs_masterODE3cao,tspan,y0n,opts,p,sf(imodel,:));
    t = S(imodel).t;
    y = S(imodel).y;
    currents = [];
    for u=1:size(t,1)
      currents = [currents;lhs_masterODE3cao_FLUX(t(u),y(u,:),p,sf(imodel,:))];

%     global tStep tArray Jserca J_RyR I_Ca_store Incx JLS2J JLS2I
%     tArray = tArray(1:tStep); 
%     Jserca = Jserca(1:tStep);clc
%     J_RyR = J_RyR(1:tStep);
%     I_Ca_store = I_Ca_store(1:tStep);
%     Incx = Incx(1:tStep);
%     JLS2J = JLS2J(1:tStep);
%     JLS2I = JLS2I(1:tStep);
    end
    
%     F(imodel).tArray = t;
%     F(imodel).Jserca = Jserca;
%     F(imodel).J_RyR = J_RyR;
%     F(imodel).I_Ca_store = I_Ca_store;
%     F(imodel).Incx = Incx;
%     F(imodel).JLS2J = JLS2J;
%     F(imodel).JLS2I = JLS2I;
%%            1        2     3       4         5     6     7Total leak                   8 Passive leak only  9             10
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i J_SRCarel*Vsr/Vmyo + J_SRleak J_SRleak             I_Ca_tot_junc I_Ca_tot_sl]; 
    F(imodel).tArray = t;
    F(imodel).currents = currents;
    F(imodel).Jserca = currents(:,3);
    F(imodel).J_RyR = currents(:,4);
    F(imodel).I_Ca_store = currents(:,1);
    F(imodel).Incx = currents(:,2);
    F(imodel).JLS2J = currents(:,5);
    F(imodel).JLS2I = currents(:,6);

%% steady states    
%         S(imodel).y = y;
%         S(imodel).t = t;
%         S(imodel).y0n = y0n;
    end    
%     save(fullfile(savepath,sprintf([ssname,'_',protocol{iprotocol},...
%         '_naadp=',num2str(Naadp,'%02d'),'_','Ligtot=',num2str(Ligtot,'%.1f'),...
%         '_',num2str(freq),'hz_', num2str(iteration), 'beat','.mat'])),'S','-v7.3');
    
    save(fullfile(savepath,sprintf([fluxname,'_',protocol{iprotocol},...
        '_naadp=',num2str(Naadp,'%02d'),'_','Ligtot=',num2str(Ligtot,'%.1f'),...
        '_',num2str(freq),'hz_', num2str(iteration), 'beat','.mat'])),'F','-v7.3');
i = i+1;
toc
end
% delete(pl)

% exit 


% Ica = I_Ca_store(1:tStep);
% Ito = I_to_store(1,1:tStep);
% Itof = I_to_store(2,1:tStep);
% Itos = I_to_store(3,1:tStep);
% INa = I_Na_store(1:tStep);
% IK1 = I_K1_store(1:tStep);
% s1 = gates(1,1:tStep);
% k1 = gates(2,1:tStep);
% Jserca = Jserca(1:tStep);
% Iks = IKs_store(1:tStep);
% Jleak = Jleak(1:tStep,:);
% ICFTR = ICFTR(1:tStep);
% Incx = Incx(1:tStep);
% Ikur1 = I_kur1_store(1:tStep);
% Ikur2 = I_kur2_store(1:tStep);
% Iss = I_ss_store(1:tStep);
% dVm = dVm_store(1:tStep);
% Ipca = Ipca_store(1:tStep);
% INaK = I_NaK_store(1:tStep);
% INabk = I_Nabk_store(1:tStep);
% Ikr = I_kr_store(1:tStep);
%% Plot results

% figure
% subplot(4,2,1),plot(t/1e3,y(:,39),'k'); ylabel('Em (mV)');
% subplot(4,2,3),plot(t/1e3,y(:,34),'k'); ylabel('[Na]i (mM)');
% subplot(4,2,5),plot(t/1e3,y(:,38),'b'); ylabel('[Ca]i (mM)');
% subplot(4,2,7),plot(t/1e3,y(:,30)+y(:,31),'k'); ylabel('tot [Ca]SR (mM)');
% xlabel('Time (s)');
% subplot(4,2,2),plot(t/1e3,CaMKIItotDyad*100.*(y(:,87+8)+y(:,87+9)+...
%     y(:,87+10)+y(:,87+11))/100,'k'); ylabel('dCaMKIIact (uM)');
% subplot(4,2,4),plot(t/1e3,100*y(:,87+45+2)./LCCtotDyad,'g'); ylabel('LTCCp (%)');
% subplot(4,2,6),plot(t/1e3,100*y(:,87+45+4)./RyRtot,'r'); ylabel('RyRp (%)');
% subplot(4,2,8),plot(t/1e3,100*y(:,87+45+5)./PLBtot,'c'); ylabel('PLBp (%)');
% xlabel('Time (s)'); set(gcf,'color','w')
