function Fpeak = peak_marker(T,T1,Y,ratio)
[~,t0ind] = min(abs(T-T1(1)));
[~,t1ind] = min(abs(T-T1(2)));
T = T(t0ind:t1ind);
Y = Y(t0ind:t1ind); 



%% method 5
% Fpeak.sumY = sum((Y.*T))/numel(T); 
% Fpeak.integralY = trapz(T, Y); 
%% method 4
% Y1 = (Y(2:end) - Y(2-1:end-1))./(T(2:end) - T(2-1:end-1));
% Y1 = [0; Y1];
% 
% Fpeak.sumY = trapz(T, Y1);
% Fpeak.integralY = trapz(T, Y);
%% method 3
% Fpeak.sumY = trapz(T, Y);
% Fpeak.integralY = trapz(T, Y);
%% method 2
% Fpeak.sumY = trapz(T, Y);
% Fpeak.integralY = trapz(T, Y);
%% method 1
Fpeak.sumY = trapz(T, Y);
Fpeak.integralY = trapz(T, Y);

% %     [~,t300ind] = min(abs(T - T1(1) - 300));
% [TF1,~] = islocalmax(Y,'MinProminence',max(Y)/ratio); % 200
% if abs(Y(end)) > min(abs(Y))*1.3 % 2
% TF1(end) = 1;
% end 
% peakidx = find(TF1);
% 
% [TFmin,~] = islocalmin(Y,'MinProminence',max(Y)/ratio);
% valleyidx = find(TFmin);
% 
% [maxy,maxidx] = max(Y);
% %     y_Cathreshold80 = min(Y) + (max(Y) - min(Y))*(1-0.8);
% %     x_Cathreshold80 = interp1(Y(maxidx:end), T(maxidx:end), y_Cathreshold80);
% % [~,maxidx] = min(abs(Y-maxy));
% valleymaxidxidx = find(valleyidx > maxidx);
% 
% valley = valleyidx(valleymaxidxidx);
% valleylist = Y(valley);
% [~, ivalley] = max(valleylist);
% valley = valley(ivalley);
% 
% [~,t2ind] = min(abs(T - T(1) - 500));
% %% sort peak over timepoint
% maxidxidx = find(peakidx > t2ind);
% dadidx = peakidx(maxidxidx);
% 
% marker.ampTlist = T(peakidx);
% if numel(peakidx) == 0
% marker.ampY = max(Y) - min(Y); 
% marker.ampT = T(maxidx);
% else
% marker.ampY = Y(peakidx(1)) - min(Y);    
% marker.ampT = T(peakidx(1));
% end
% 
%     if numel(peakidx) >1 & numel(dadidx) > 0 & numel(valley) > 0   
%     dadamp =  Y(dadidx) - min(Y);
%     dadampT = T(dadidx);          
%     [maxdadamp, imaxdadamp] = max(dadamp);        
%     
%     marker.dad_ampI = dadidx;
%     marker.dad_ampT = dadampT(imaxdadamp);
%     marker.dad_ampYlist = dadamp;
%     marker.dad_ampY = maxdadamp; 
%     
%     marker.dad_integralY = trapz(T(valleyidx:end),Y(valleyidx:end));
%     marker.peak_integralY = trapz(T(1:valleyidx), Y(1:valleyidx));
%     else    
%     marker.dad_ampI = nan;
%     marker.dad_ampT = nan;
%     marker.dad_ampYlist = nan;
%     marker.dad_ampY = nan;   
%     
%     marker.dad_integralY = nan;
%     marker.peak_integralY = trapz(T(1:end),Y(1:end)); 
%     end
end
