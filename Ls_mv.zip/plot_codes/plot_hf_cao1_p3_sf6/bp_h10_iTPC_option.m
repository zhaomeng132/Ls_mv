clear all
close all

cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat
addpath('~/downloads/SS/Ls_mv_sf6/plot_hf_cao1_p3_sf6')

cd ~/downloads/SS/Ls_mv_sf6

load h10_iTPC1.mat % duration 0-4000ms
iTPC1 = h10_iTPC1;

cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_arc_home
load y175_WT_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3w
S = S(h1_cao1_sf1000_sf6_0);
S3w = S(iTPC1); clear S

cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_local
load y175_j_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wj
S = S(h1_cao1_sf1000_sf6_0);
S3wj = S(iTPC1); clear S

cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_arc_home
load y175_i_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wi
S = S(h1_cao1_sf1000_sf6_0);
S3wi = S(iTPC1); clear S

cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_local/h10_cao1_p3_sf1000_FLUX

load y175_FLUX_WT_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3w
F = F(h1_cao1_sf1000_sf6_0);
F3w = F(iTPC1); clear F
load y175_FLUX_j_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wj
F = F(h1_cao1_sf1000_sf6_0);
F3wj = F(iTPC1); clear F
load y175_FLUX_i_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat %S3wi
F = F(h1_cao1_sf1000_sf6_0);
F3wi = F(iTPC1); clear F

% duration 0-5000ms
% cd ~/downloads/SS/h50_cao1_p3_/
% mkdir(['./','h10_iTPC1_option2'])
% cd(['./','h10_iTPC1_option2'])

cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','fig89'])
cd(['./','fig89'])

num = numel(iTPC1);

%% CTRL TPC2KO
Y = [38,31,36,88,37,15];
Yspace = {'Cytosol','SR','Junction','Lysosome','Sarcolemma','Open Probability'};
Yscale = [1e6,1e6,1e6,1e6,1e6,1];
yaxis_lim = [2,5,5,4,3,0];

% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 5;

for SP = 1 : numel(Y)
for idad = id_median: id_median%numel(Sw_w1i0)
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(S3w(idad).t,S3w(idad).y(:,Y(SP)).*Yscale(SP),'b'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(S3wi(idad).t,S3wi(idad).y(:,Y(SP)).*Yscale(SP),'m'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
end    
    fontsize = 40;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    xlim([0 5000])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 2
    legend('WT','J_{ls,rel} = 0','Location', 'northwest');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    elseif SP == 6
    legend('WT','J_{ls,rel} = 0','Non-pro-arrhythmic','Location', 'northwest');legend boxoff
%     ylim([0 1.1])
    ylabel(sprintf('%s',Yspace{SP}));xlabel('Time (ms)');
    else
    legend('WT','J_{ls,rel} = 0','Location', 'northwest');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    end
 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[0 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i0_wt_ko',Y(SP))),'-dtiff','-r300');

close all
end

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
Y = [1 2 3 4 5 6 9 27];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{CaL}','J_RyR Leak'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1 1e6]; 
Yaxis = [1 -1 2 4 4 3 1 0];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{CaL} (pA/pF)','J_{RyR Leak} (nM/ms)'};

% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 5;
for SP = 3:4%numel(Y)
for idad = id_median: id_median%numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(F3w(idad).tArray,F3w(idad).currents(:,Y(SP)).*Yscale(SP),'b');
    hold on
    p2 =plot(F3wi(idad).tArray,F3wi(idad).currents(:,Y(SP)).*Yscale(SP),'m');    

end

fontsize = 40;

f1 = figure(1);subplot(1,1,1); 
xlim([0 5000])
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');       
if SP ==7
title({'Hypercalcemia and ISO, WT_{ }',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               if SP == 1 | SP == 2 | SP ==3 | SP==5 | SP==7 | SP==8
               legend('WT','J_{ls,rel} = 0','Location', 'northeast');legend boxoff
               ylim([0 7.5e2])
               elseif SP == 4
               legend('WT','J_{ls,rel} = 0','Location', 'northwest');legend boxoff
               ylim([0 10e4])    
               else
               legend('WT','J_{ls,rel} = 0','Location', 'northwest');legend boxoff
               end
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('w1i0_wt_ko %s',Yspace{SP})),'-dtiff','-r300');

close all
end
%%
% for ipeak = 1:1%numel(S3wj) 
% 
% wt3 = S3w(ipeak).t;
% wy3 = S3w(ipeak).y.*1e6;
% jt3 = S3wj(ipeak).t;
% jy3 = S3wj(ipeak).y.*1e6;
% it3 = S3wi(ipeak).t;
% iy3 = S3wi(ipeak).y.*1e6;
% 
% figure(1);
% subplot(2,2,1);plot(wt3,wy3(:,31));hold on 
% subplot(2,2,2);plot(jt3,jy3(:,31));hold on 
% subplot(2,2,3);plot(it3,iy3(:,31));hold on 
% 
% end
% 
% close all

%% plot trace
Y = [88,38,31,36,37];
Yspace = {'Lysosome','Cytosol','SR','Junction','SL'};
yaxis_lim = [4,2,5,5,3];
for SP = 1: 1%numel(Y)
for ipeak = 1 : num    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(S3w(ipeak).t,S3w(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(S3wj(ipeak).t,S3wj(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(S3wi(ipeak).t,S3wi(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on 
end    
    linkaxes([ax2,ax4,ax6],'y');
    yaxis = yaxis_lim(SP);
    f60 = figure(60);
    ax2 = subplot(1,1,1);
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP == 1
%     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
%     else 
    title({' ',' '});
%     end   
    xlim([0 5000])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

    f61 = figure(61);
    ax4 = subplot(1,1,1);
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP ==1
%     title({'10Hz Fast Pacing and ISO, J_{ls,up} = 0',''});
%     else        
    title({' ',' '})
%     end
    xlim([0 5000])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

    f62 = figure(62);
    ax6= subplot(1,1,1);
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP ==1    
%     title({'10Hz Fast Pacing and ISO, J_{ls,rel} = 0',''});
%     else
    title({' ',' '});
%     end
    xlim([0 5000])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
    
print(f60, fullfile(pwd, sprintf('swt_10hz %s',Yspace{SP})),'-dtiff','-r300');      
print(f61, fullfile(pwd, sprintf('sjdot0_10hz %s',Yspace{SP})),'-dtiff','-r300');      
print(f62, fullfile(pwd, sprintf('sidot0_10hz %s',Yspace{SP})),'-dtiff','-r300');      

close all    
    
end
    
%%            1        2     3       4         5     6       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i]; 
Y = [1 2 3 4 5 6];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}'};
Yscale = [1 1 1e6 1e6 1e6 1e6]; 
Yaxis = [1 -1 2 4 4 3];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};


for SP = 3: numel(Y)
for idad = 1: numel(F3w)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(F3w(idad).tArray,F3w(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(2);ax2 = subplot(1,1,1);
    p2 =plot(F3wj(idad).tArray,F3wj(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(3);ax3 = subplot(1,1,1);
    p3 =plot(F3wi(idad).tArray,F3wi(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    

end
linkaxes([ax1,ax2,ax3],'y');
fontsize = 40;

f1 = figure(1);subplot(1,1,1); 
xlim([0 5000])
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
if SP == 7
title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('swt_10hz %s wt',Yspace{SP})),'-dtiff','-r300');

f2 = figure(2);subplot(1,1,1); 
xlim([0 5000])
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');  
if SP == 7
title({'10Hz Fast Pacing and ISO, J_{ls,up} = 0',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f2,'Units','pixels','Position',[0 0 700 500])
print(f2, fullfile(pwd, sprintf('sjdot0_10hz %s jdot0',Yspace{SP})),'-dtiff','-r300');

f3 = figure(3);subplot(1,1,1); 
xlim([0 5000])
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
if SP == 7
title({'10Hz Fast Pacing and ISO, J_{ls,rel} = 0',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f3,'Units','pixels','Position',[0 0 700 500])
print(f3, fullfile(pwd, sprintf('sidot0_10hz %s idot0',Yspace{SP})),'-dtiff','-r300');

close all
end

%% lhs
rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                   % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);

sf = sf(h1_cao1_sf1000_sf6_0,:);
gpdad = sf(iTPC1,:);
% gpnonedad = sf605(ls_nondadtot605,:);

%% reducing 0 ls_j, less CICR 
gpdadjdot0 = gpdad;
lsj_0 = gpdadjdot0(:,1).*0;
gpdadjdot0(:,1) = lsj_0;
%% reducing 0 ls_i, less CICR 
gpdadidot0 = gpdad;
lsi_0 = gpdadidot0(:,2).*0;
gpdadidot0(:,2) = lsi_0;
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36]; 
%%           17        18     19       20       21             22            23               24       25       26
    T1 = [0 1e3];
    T2 = [1e3 2e3];
    T3 = [2e3 3e3];
    T4 = [3e3 4e3];
    T5 = [4e3 5e3];
 
    ratio = 200;
    calratio = 100;
    ncxratio = 40;
    ryrratio = 500;  %250
    srratio = 10000; %10000
    ls2jratio = 40;
    ls2iratio = 44;
    lsratio = 100;
    
for ipeak = 1:numel(S3w)   
    t1_1 = S3w(ipeak).t;
    y38_1= S3w(ipeak).y(:,38).*1e6;
    y31= S3w(ipeak).y(:,31).*1e6;
    y88= S3w(ipeak).y(:,88).*1e6;
    y36= S3w(ipeak).y(:,36).*1e6;
    y37= S3w(ipeak).y(:,37).*1e6;
    
    tf = F3w(ipeak).tArray;
    yserca = F3w(ipeak).Jserca.*1e6;    
    yryr = F3w(ipeak).J_RyR.*1e6;    
    ycal = F3w(ipeak).I_Ca_store;    
    yncx = F3w(ipeak).Incx;    
    yls2j = F3w(ipeak).JLS2J.*1e6;    
    yls2i = F3w(ipeak).JLS2I.*1e6;  
    
%  - find amp, timepoint of beat 2   
    WT_y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     WT_y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    WT_y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    WT_y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    WT_y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    WT_y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
    
    WT_ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    WT_ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    WT_serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    WT_ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    WT_cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    WT_ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
    
    WT_juncx_b2(ipeak) = peak_marker(tf,T2,F3w(ipeak).currents(:,11),ncxratio); 
    WT_jucal_b2(ipeak) = peak_marker(tf,T2,F3w(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 3   
    WT_y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     WT_y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    WT_y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio); 
    WT_y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    WT_y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
    
    WT_y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);
        
    WT_ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    WT_ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    WT_serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    WT_ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    WT_cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    WT_ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);    
    
    WT_juncx_b3(ipeak) = peak_marker(tf,T3,F3w(ipeak).currents(:,11),ncxratio); 
    WT_jucal_b3(ipeak) = peak_marker(tf,T3,F3w(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 4   
    WT_y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     WT_y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    WT_y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    WT_y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    WT_y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
    
    WT_y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);

    WT_ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    WT_ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    WT_serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    WT_ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    WT_cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    WT_ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio); 
    
    WT_juncx_b4(ipeak) = peak_marker(tf,T4,F3w(ipeak).currents(:,11),ncxratio); 
    WT_jucal_b4(ipeak) = peak_marker(tf,T4,F3w(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 5   
    WT_y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     WT_y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    WT_y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    WT_y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    WT_y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
    
    WT_y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);

    WT_ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    WT_ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    WT_serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    WT_ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    WT_cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    WT_ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);     
    
    WT_juncx_b5(ipeak) = peak_marker(tf,T5,F3w(ipeak).currents(:,11),ncxratio); 
    WT_jucal_b5(ipeak) = peak_marker(tf,T5,F3w(ipeak).currents(:,9),ncxratio); 
    
end    

% ls2j = 0
for ipeak = 1:numel(S3wj)   
    t1_1 = S3wj(ipeak).t;
    y38_1= S3wj(ipeak).y(:,38).*1e6;
    y31= S3wj(ipeak).y(:,31).*1e6;
    y88= S3wj(ipeak).y(:,88).*1e6;
    y36= S3wj(ipeak).y(:,36).*1e6;
    y37= S3wj(ipeak).y(:,37).*1e6;
    
    tf = F3wj(ipeak).tArray;
    yserca = F3wj(ipeak).Jserca.*1e6;    
    yryr = F3wj(ipeak).J_RyR.*1e6;    
    ycal = F3wj(ipeak).I_Ca_store;    
    yncx = F3wj(ipeak).Incx;    
    yls2j = F3wj(ipeak).JLS2J.*1e6;    
    yls2i = F3wj(ipeak).JLS2I.*1e6;  

% - find amp, timepoint of beat 2   
    ls2j_y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2j_y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    ls2j_y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    ls2j_y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    ls2j_y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    ls2j_y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
    
    ls2j_ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    ls2j_ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    ls2j_serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    ls2j_ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    ls2j_cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    ls2j_ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
    
    ls2j_juncx_b2(ipeak) = peak_marker(tf,T2,F3wj(ipeak).currents(:,11),ncxratio); 
    ls2j_jucal_b2(ipeak) = peak_marker(tf,T2,F3wj(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 3   
    ls2j_y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2j_y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    ls2j_y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio);
    ls2j_y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    ls2j_y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
        
    ls2j_y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);

    ls2j_ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    ls2j_ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    ls2j_serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    ls2j_ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    ls2j_cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    ls2j_ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio);   
    
    ls2j_juncx_b3(ipeak) = peak_marker(tf,T3,F3wj(ipeak).currents(:,11),ncxratio); 
    ls2j_jucal_b3(ipeak) = peak_marker(tf,T3,F3wj(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 4   
    ls2j_y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2j_y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    ls2j_y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    ls2j_y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    ls2j_y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
    
    ls2j_y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);

    ls2j_ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    ls2j_ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    ls2j_serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    ls2j_ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    ls2j_cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    ls2j_ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);   
    
    ls2j_juncx_b4(ipeak) = peak_marker(tf,T4,F3wj(ipeak).currents(:,11),ncxratio); 
    ls2j_jucal_b4(ipeak) = peak_marker(tf,T4,F3wj(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 5   
    ls2j_y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2j_y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    ls2j_y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    ls2j_y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    ls2j_y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);
    
    ls2j_y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);
    
    ls2j_ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    ls2j_ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    ls2j_serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    ls2j_ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    ls2j_cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    ls2j_ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);     
    
    ls2j_juncx_b5(ipeak) = peak_marker(tf,T5,F3wj(ipeak).currents(:,11),ncxratio); 
    ls2j_jucal_b5(ipeak) = peak_marker(tf,T5,F3wj(ipeak).currents(:,9),ncxratio); 
    
end    


% y38_b1 = find(~isnan([ls2j_y38_b1(:).dad_ampY]));
% y38_b2 = find(~isnan([ls2j_y38_b2(:).dad_ampY]));
% y38_b3 = find(~isnan([ls2j_y38_b3(:).dad_ampY]));
% y38_b4 = find(~isnan([ls2j_y38_b4(:).dad_ampY]));
% y38_b5 = find(~isnan([ls2j_y38_b5(:).dad_ampY]));
% ls2j_y38_dad_h10_p3_wyno = unique([y38_b1, y38_b2, y38_b3, y38_b4, y38_b5]);
% 
% ls2j_y38_dad_h10_p3_0 = h10_p3_wyno(ls2j_y38_dad_h10_p3_wyno);
% save('ls2j_y38_dad_h10_p3_0.mat','ls2j_y38_dad_h10_p3_0');
% ls2i = 0
for ipeak = 1:numel(S3wi)   
    t1_1 = S3wi(ipeak).t;
    y38_1= S3wi(ipeak).y(:,38).*1e6;
    y31= S3wi(ipeak).y(:,31).*1e6;
    y88= S3wi(ipeak).y(:,88).*1e6;
    y36= S3wi(ipeak).y(:,36).*1e6;
    y37= S3wi(ipeak).y(:,37).*1e6;
    
    tf = F3wi(ipeak).tArray;
    yserca = F3wi(ipeak).Jserca.*1e6;    
    yryr = F3wi(ipeak).J_RyR.*1e6;    
    ycal = F3wi(ipeak).I_Ca_store;    
    yncx = F3wi(ipeak).Incx;    
    yls2j = F3wi(ipeak).JLS2J.*1e6;    
    yls2i = F3wi(ipeak).JLS2I.*1e6;  

%  - find amp, timepoint of beat 2   
    ls2i_y38_b2(ipeak) = peak_marker(t1_1,T2,y38_1,ratio);
%     ls2i_y31_b2(ipeak) = sr_marker(t1_1,T2,y31,srratio);
    ls2i_y88_b2(ipeak) = peak_marker(t1_1,T2,y88,lsratio);
    ls2i_y36_b2(ipeak) = peak_marker(t1_1,T2,y36,lsratio);
    ls2i_y37_b2(ipeak) = peak_marker(t1_1,T2,y37,lsratio);
    
    ls2i_y31_y36_b2(ipeak) = y31_y36_marker(t1_1,T2,y31,200,200,y36);
    
    ls2i_ls2j_b2(ipeak) = peak_marker(tf,T2,yls2j,ls2jratio);
    ls2i_ls2i_b2(ipeak) = peak_marker(tf,T2,yls2i,ls2iratio);
    ls2i_serca_b2(ipeak) = peak_marker(tf,T2,yserca,ratio);    
    ls2i_ryr_b2(ipeak) = peak_marker(tf,T2,yryr,ryrratio);
    ls2i_cal_b2(ipeak) = peak_marker(tf,T2,ycal,calratio);
    ls2i_ncx_b2(ipeak) = peak_marker(tf,T2,yncx,ncxratio); 
    idot0F_ls2j_portion_b2(ipeak) = ls2j_portion1(tf,T2,yls2j,ratio,ratio);
    
    ls2i_juncx_b2(ipeak) = peak_marker(tf,T2,F3wi(ipeak).currents(:,11),ncxratio); 
    ls2i_jucal_b2(ipeak) = peak_marker(tf,T2,F3wi(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 3   
    ls2i_y38_b3(ipeak) = peak_marker(t1_1,T3,y38_1,ratio);
%     ls2i_y31_b3(ipeak) = sr_marker(t1_1,T3,y31,srratio);
    ls2i_y88_b3(ipeak) = peak_marker(t1_1,T3,y88,lsratio);
    ls2i_y36_b3(ipeak) = peak_marker(t1_1,T3,y36,lsratio);
    ls2i_y37_b3(ipeak) = peak_marker(t1_1,T3,y37,lsratio);
    
    ls2i_y31_y36_b3(ipeak) = y31_y36_marker(t1_1,T3,y31,200,200,y36);

    ls2i_ls2j_b3(ipeak) = peak_marker(tf,T3,yls2j,ls2jratio);
    ls2i_ls2i_b3(ipeak) = peak_marker(tf,T3,yls2i,ls2iratio);
    ls2i_serca_b3(ipeak) = peak_marker(tf,T3,yserca,ratio);    
    ls2i_ryr_b3(ipeak) = peak_marker(tf,T3,yryr,ryrratio);
    ls2i_cal_b3(ipeak) = peak_marker(tf,T3,ycal,calratio);
    ls2i_ncx_b3(ipeak) = peak_marker(tf,T3,yncx,ncxratio); 
    idot0F_ls2j_portion_b3(ipeak) = ls2j_portion1(tf,T3,yls2j,ratio,ratio);
    
    ls2i_juncx_b3(ipeak) = peak_marker(tf,T3,F3wi(ipeak).currents(:,11),ncxratio); 
    ls2i_jucal_b3(ipeak) = peak_marker(tf,T3,F3wi(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 4   
    ls2i_y38_b4(ipeak) = peak_marker(t1_1,T4,y38_1,ratio);
%     ls2i_y31_b4(ipeak) = sr_marker(t1_1,T4,y31,srratio);
    ls2i_y88_b4(ipeak) = peak_marker(t1_1,T4,y88,lsratio);
    ls2i_y36_b4(ipeak) = peak_marker(t1_1,T4,y36,lsratio);
    ls2i_y37_b4(ipeak) = peak_marker(t1_1,T4,y37,lsratio);
    
    ls2i_y31_y36_b4(ipeak) = y31_y36_marker(t1_1,T4,y31,200,200,y36);

    ls2i_ls2j_b4(ipeak) = peak_marker(tf,T4,yls2j,ls2jratio);
    ls2i_ls2i_b4(ipeak) = peak_marker(tf,T4,yls2i,ls2iratio);
    ls2i_serca_b4(ipeak) = peak_marker(tf,T4,yserca,ratio);    
    ls2i_ryr_b4(ipeak) = peak_marker(tf,T4,yryr,ryrratio);
    ls2i_cal_b4(ipeak) = peak_marker(tf,T4,ycal,calratio);
    ls2i_ncx_b4(ipeak) = peak_marker(tf,T4,yncx,ncxratio);     
    idot0F_ls2j_portion_b4(ipeak) = ls2j_portion1(tf,T4,yls2j,ratio,ratio);
    
    ls2i_juncx_b4(ipeak) = peak_marker(tf,T4,F3wi(ipeak).currents(:,11),ncxratio); 
    ls2i_jucal_b4(ipeak) = peak_marker(tf,T4,F3wi(ipeak).currents(:,9),ncxratio); 
    
%  - find amp, timepoint of beat 5   
    ls2i_y38_b5(ipeak) = peak_marker(t1_1,T5,y38_1,ratio);
%     ls2i_y31_b5(ipeak) = sr_marker(t1_1,T5,y31,srratio);
    ls2i_y88_b5(ipeak) = peak_marker(t1_1,T5,y88,lsratio);
    ls2i_y36_b5(ipeak) = peak_marker(t1_1,T5,y36,lsratio);
    ls2i_y37_b5(ipeak) = peak_marker(t1_1,T5,y37,lsratio);    
    
    ls2i_y31_y36_b5(ipeak) = y31_y36_marker(t1_1,T5,y31,200,200,y36);

    ls2i_ls2j_b5(ipeak) = peak_marker(tf,T5,yls2j,ls2jratio);
    ls2i_ls2i_b5(ipeak) = peak_marker(tf,T5,yls2i,ls2iratio);
    ls2i_serca_b5(ipeak) = peak_marker(tf,T5,yserca,ratio);    
    ls2i_ryr_b5(ipeak) = peak_marker(tf,T5,yryr,ryrratio);
    ls2i_cal_b5(ipeak) = peak_marker(tf,T5,ycal,calratio);
    ls2i_ncx_b5(ipeak) = peak_marker(tf,T5,yncx,ncxratio);     
    idot0F_ls2j_portion_b5(ipeak) = ls2j_portion1(tf,T5,yls2j,ratio,ratio);
    
    ls2i_juncx_b5(ipeak) = peak_marker(tf,T5,F3wi(ipeak).currents(:,11),ncxratio); 
    ls2i_jucal_b5(ipeak) = peak_marker(tf,T5,F3wi(ipeak).currents(:,9),ncxratio); 
end 

%% S3w y31
% for ipeak = 1:numel(S3w)   
%     
% t1_1 = S3w(ipeak).t;
% y31= S3w(ipeak).y(:,31).*1e6;
% 
% [~,t2ind] = min(abs(t1_1-T2(1)));
% [~,t3ind] = min(abs(t1_1-T3(1)));
% [~,t4ind] = min(abs(t1_1-T4(1)));
% [~,t5ind] = min(abs(t1_1-T5(1)));
% 
% figure(1)    
% plot(t1_1,y31,'k');hold on
% plot(t1_1(t2ind+WT_y31_y36_b2(ipeak).valleyI),y31(t2ind+WT_y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+WT_y31_y36_b3(ipeak).valleyI),y31(t3ind+WT_y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+WT_y31_y36_b4(ipeak).valleyI),y31(t4ind+WT_y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+WT_y31_y36_b5(ipeak).valleyI),y31(t5ind+WT_y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
% end
% 
% % % yaxis = yaxis_lim(SP);
% %     f1 = figure(1);
% %     ax2 = subplot(1,1,1);
% %     ylabel(sprintf('[Ca] SR (nM)'));xlabel('Time (ms)'); 
% % %     if SP == 1
% % %     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
% % %     else 
% % %     title({' ',' '});
% % %     end   
% %     xlim([0 5000])
% %     ax = gca;
% %     ax. Position = [0.2 0.2 0.7 0.7];
% %     ax.YAxis.Exponent = 5;
% %     set(findobj(f1,'type','axes'),'FontName','Times New Roman','FontSize',35)
% %     set(findobj(f1, 'Type', 'Line'),'LineWidth',2);
% %     set(findobj(f1,'type','axes'),'box','off')
% %     set(f1,'Units','pixels','Position',[0 0 700 500])
% % print(f1, fullfile(pwd, sprintf('iTPC_wt_10hz_id1')),'-dtiff','-r300');
%% S3wj y31
% for ipeak = 1:numel(S3wj)   
%     
% t1_1 = S3wj(ipeak).t;
% y31= S3wj(ipeak).y(:,31).*1e6;
% 
% [~,t2ind] = min(abs(t1_1-T2(1)));
% [~,t3ind] = min(abs(t1_1-T3(1)));
% [~,t4ind] = min(abs(t1_1-T4(1)));
% [~,t5ind] = min(abs(t1_1-T5(1)));
% 
% figure(1)    
% plot(t1_1,y31,'k');hold on
% plot(t1_1(t2ind+ls2j_y31_y36_b2(ipeak).valleyI),y31(t2ind+ls2j_y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+ls2j_y31_y36_b3(ipeak).valleyI),y31(t3ind+ls2j_y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+ls2j_y31_y36_b4(ipeak).valleyI),y31(t4ind+ls2j_y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+ls2j_y31_y36_b5(ipeak).valleyI),y31(t5ind+ls2j_y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
% end
%% S3wi y31
% for ipeak = 1:numel(S3wi)   
%     
% t1_1 = S3wi(ipeak).t;
% y31= S3wi(ipeak).y(:,31).*1e6;
% 
% [~,t2ind] = min(abs(t1_1-T2(1)));
% [~,t3ind] = min(abs(t1_1-T3(1)));
% [~,t4ind] = min(abs(t1_1-T4(1)));
% [~,t5ind] = min(abs(t1_1-T5(1)));
% 
% figure(1)    
% plot(t1_1,y31,'k');hold on
% plot(t1_1(t2ind+ls2i_y31_y36_b2(ipeak).valleyI),y31(t2ind+ls2i_y31_y36_b2(ipeak).valleyI),'r.','markersize',30); 
% plot(t1_1(t3ind+ls2i_y31_y36_b3(ipeak).valleyI),y31(t3ind+ls2i_y31_y36_b3(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t4ind+ls2i_y31_y36_b4(ipeak).valleyI),y31(t4ind+ls2i_y31_y36_b4(ipeak).valleyI),'r.','markersize',30);
% plot(t1_1(t5ind+ls2i_y31_y36_b5(ipeak).valleyI),y31(t5ind+ls2i_y31_y36_b5(ipeak).valleyI),'r.','markersize',30);
% end
%%            1        2     3       4         5     6       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i]; 
Y = [1 2 3 4 5 6];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}'};
Yscale = [1 1 1e6 1e6 1e6 1e6]; 
Yaxis = [1 -1 2 4 4 4];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};

for SP = 5:5% numel(Y)
for idad = 1: 1%numel(F3w)
    
    figure(3);ax3 = subplot(1,1,1);
    p3 =plot(F3wi(idad).tArray,F3wi(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');hold on
    b2_id_1 = idot0F_ls2j_portion_b2(idad).valleyidx;
    plot(F3wi(idad).tArray(b2_id_1),F3wi(idad).currents(b2_id_1,Y(SP)).*Yscale(SP),'r.','markersize',30);
    b2_id2 = idot0F_ls2j_portion_b2(idad).peakidx;
    plot(F3wi(idad).tArray(b2_id2),F3wi(idad).currents(b2_id2,Y(SP)).*Yscale(SP),'b.','markersize',30);
    
    b3_id_1 = idot0F_ls2j_portion_b3(idad).valleyidx;
    plot(F3wi(idad).tArray(b3_id_1),F3wi(idad).currents(b3_id_1,Y(SP)).*Yscale(SP),'r.','markersize',30);
    b3_id2 = idot0F_ls2j_portion_b3(idad).peakidx;
    plot(F3wi(idad).tArray(b3_id2),F3wi(idad).currents(b3_id2,Y(SP)).*Yscale(SP),'b.','markersize',30);
    
    b4_id_1 = idot0F_ls2j_portion_b4(idad).valleyidx;
    plot(F3wi(idad).tArray(b4_id_1),F3wi(idad).currents(b4_id_1,Y(SP)).*Yscale(SP),'r.','markersize',30);
    b4_id2 = idot0F_ls2j_portion_b4(idad).peakidx;
    plot(F3wi(idad).tArray(b4_id2),F3wi(idad).currents(b4_id2,Y(SP)).*Yscale(SP),'b.','markersize',30);
    
    b5_id_1 = idot0F_ls2j_portion_b5(idad).valleyidx;
    plot(F3wi(idad).tArray(b5_id_1),F3wi(idad).currents(b5_id_1,Y(SP)).*Yscale(SP),'r.','markersize',30);
    b5_id2 = idot0F_ls2j_portion_b5(idad).peakidx;
    plot(F3wi(idad).tArray(b5_id2),F3wi(idad).currents(b5_id2,Y(SP)).*Yscale(SP),'b.','markersize',30);
    
end
end

b2_median_outperin= median(abs([idot0F_ls2j_portion_b2(:).ls2jout]))/median(abs([idot0F_ls2j_portion_b2(:).ls2jin]))
b3_median_outperin= median(abs([idot0F_ls2j_portion_b3(:).ls2jout]))/median(abs([idot0F_ls2j_portion_b3(:).ls2jin]))
b4_median_outperin= median(abs([idot0F_ls2j_portion_b4(:).ls2jout]))/median(abs([idot0F_ls2j_portion_b4(:).ls2jin]))
b5_median_outperin= median(abs([idot0F_ls2j_portion_b5(:).ls2jout]))/median(abs([idot0F_ls2j_portion_b5(:).ls2jin]))
%% sum_y31_y36
close all
figure(7)
num = numel([WT_y38_b2(:).sumY]);
ex = 1:4;
ey_WT = [mean([WT_y31_y36_b2(:).sum_y31_y36]),...
         mean([WT_y31_y36_b3(:).sum_y31_y36]),...
         mean([WT_y31_y36_b4(:).sum_y31_y36]),...
         mean([WT_y31_y36_b5(:).sum_y31_y36])];
err_WT = [std([WT_y31_y36_b2(:).sum_y31_y36])/sqrt(num),...
          std([WT_y31_y36_b3(:).sum_y31_y36])/sqrt(num),...
          std([WT_y31_y36_b4(:).sum_y31_y36])/sqrt(num),...
          std([WT_y31_y36_b5(:).sum_y31_y36])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_y31_y36_b2(:).sum_y31_y36]),...
           mean([ls2j_y31_y36_b3(:).sum_y31_y36]),...
           mean([ls2j_y31_y36_b4(:).sum_y31_y36]),...
           mean([ls2j_y31_y36_b5(:).sum_y31_y36])];
err_ls2j = [std([ls2j_y31_y36_b2(:).sum_y31_y36])/sqrt(num),...
            std([ls2j_y31_y36_b3(:).sum_y31_y36])/sqrt(num),...
            std([ls2j_y31_y36_b4(:).sum_y31_y36])/sqrt(num),...
            std([ls2j_y31_y36_b5(:).sum_y31_y36])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_y31_y36_b2(:).sum_y31_y36]),...
           mean([ls2i_y31_y36_b3(:).sum_y31_y36]),...
           mean([ls2i_y31_y36_b4(:).sum_y31_y36]),...
           mean([ls2i_y31_y36_b5(:).sum_y31_y36])];
err_ls2i = [std([ls2i_y31_y36_b2(:).sum_y31_y36])/sqrt(num),...
            std([ls2i_y31_y36_b3(:).sum_y31_y36])/sqrt(num),...
            std([ls2i_y31_y36_b4(:).sum_y31_y36])/sqrt(num),...
            std([ls2i_y31_y36_b5(:).sum_y31_y36])/sqrt(num)];   

errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 


ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
ylim([10e7 15e7])

legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Difference','of Junction and SR (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_y31_y36_5'),'-dtiff','-r300')

%% y31_sumY
close all
figure(7)
num = numel([WT_y38_b2(:).sumY]);
ex = 1:4;
ey_WT = [mean([WT_y31_y36_b2(:).sumY]),...
         mean([WT_y31_y36_b3(:).sumY]),...
         mean([WT_y31_y36_b4(:).sumY]),...
         mean([WT_y31_y36_b5(:).sumY])];
err_WT = [std([WT_y31_y36_b2(:).sumY])/sqrt(num),...
          std([WT_y31_y36_b3(:).sumY])/sqrt(num),...
          std([WT_y31_y36_b4(:).sumY])/sqrt(num),...
          std([WT_y31_y36_b5(:).sumY])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_y31_y36_b2(:).sumY]),...
           mean([ls2j_y31_y36_b3(:).sumY]),...
           mean([ls2j_y31_y36_b4(:).sumY]),...
           mean([ls2j_y31_y36_b5(:).sumY])];
err_ls2j = [std([ls2j_y31_y36_b2(:).sumY])/sqrt(num),...
            std([ls2j_y31_y36_b3(:).sumY])/sqrt(num),...
            std([ls2j_y31_y36_b4(:).sumY])/sqrt(num),...
            std([ls2j_y31_y36_b5(:).sumY])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_y31_y36_b2(:).sumY]),...
           mean([ls2i_y31_y36_b3(:).sumY]),...
           mean([ls2i_y31_y36_b4(:).sumY]),...
           mean([ls2i_y31_y36_b5(:).sumY])];
err_ls2i = [std([ls2i_y31_y36_b2(:).sumY])/sqrt(num),...
            std([ls2i_y31_y36_b3(:).sumY])/sqrt(num),...
            std([ls2i_y31_y36_b4(:).sumY])/sqrt(num),...
            std([ls2i_y31_y36_b5(:).sumY])/sqrt(num)];   

errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 


ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 7;
ylim([10e7 15e7])

legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] SR (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_y31_5'),'-dtiff','-r300')
%% errorbar y38
close all
figure(7)
num = numel([WT_y38_b2(:).sumY]);
ex = 1:4;
ey_WT = [mean([WT_y38_b2(:).sumY]),...
         mean([WT_y38_b3(:).sumY]),...
         mean([WT_y38_b4(:).sumY]),...
         mean([WT_y38_b5(:).sumY])];
err_WT = [std([WT_y38_b2(:).sumY])/sqrt(num),...
          std([WT_y38_b3(:).sumY])/sqrt(num),...
          std([WT_y38_b4(:).sumY])/sqrt(num),...
          std([WT_y38_b5(:).sumY])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_y38_b2(:).sumY]),...
           mean([ls2j_y38_b3(:).sumY]),...
           mean([ls2j_y38_b4(:).sumY]),...
           mean([ls2j_y38_b5(:).sumY])];
err_ls2j = [std([ls2j_y38_b2(:).sumY])/sqrt(num),...
            std([ls2j_y38_b3(:).sumY])/sqrt(num),...
            std([ls2j_y38_b4(:).sumY])/sqrt(num),...
            std([ls2j_y38_b5(:).sumY])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_y38_b2(:).sumY]),...
           mean([ls2i_y38_b3(:).sumY]),...
           mean([ls2i_y38_b4(:).sumY]),...
           mean([ls2i_y38_b5(:).sumY])];
err_ls2i = [std([ls2i_y38_b2(:).sumY])/sqrt(num),...
            std([ls2i_y38_b3(:).sumY])/sqrt(num),...
            std([ls2i_y38_b4(:).sumY])/sqrt(num),...
            std([ls2i_y38_b5(:).sumY])/sqrt(num)];   

errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 


ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
ylim([1e5 10e5])

legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Cytosol (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_y38_5'),'-dtiff','-r300')

%% errorbar y36
close all
figure(7)
num = numel([WT_y36_b2(:).sumY]);
ex = 1:4;
ey_WT = [mean([WT_y36_b2(:).sumY]),...
         mean([WT_y36_b3(:).sumY]),...
         mean([WT_y36_b4(:).sumY]),...
         mean([WT_y36_b5(:).sumY])];
err_WT = [std([WT_y36_b2(:).sumY])/sqrt(num),...
          std([WT_y36_b3(:).sumY])/sqrt(num),...
          std([WT_y36_b4(:).sumY])/sqrt(num),...
          std([WT_y36_b5(:).sumY])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_y36_b2(:).sumY]),...
           mean([ls2j_y36_b3(:).sumY]),...
           mean([ls2j_y36_b4(:).sumY]),...
           mean([ls2j_y36_b5(:).sumY])];
err_ls2j = [std([ls2j_y36_b2(:).sumY])/sqrt(num),...
            std([ls2j_y36_b3(:).sumY])/sqrt(num),...
            std([ls2j_y36_b4(:).sumY])/sqrt(num),...
            std([ls2j_y36_b5(:).sumY])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_y36_b2(:).sumY]),...
           mean([ls2i_y36_b3(:).sumY]),...
           mean([ls2i_y36_b4(:).sumY]),...
           mean([ls2i_y36_b5(:).sumY])];
err_ls2i = [std([ls2i_y36_b2(:).sumY])/sqrt(num),...
            std([ls2i_y36_b3(:).sumY])/sqrt(num),...
            std([ls2i_y36_b4(:).sumY])/sqrt(num),...
            std([ls2i_y36_b5(:).sumY])/sqrt(num)]; 

errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 


ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 8;
ylim([1e7 40e7])

legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'25Hz Fast Pacing and ISO',''})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_y36_5'),'-dtiff','-r300')

%% total calcium
% cellLength = 100; % cell length [um]
% cellRadius = 10.25; % cell radius [um]
% junctionLength = 15e-3; % junc length [um]
% junctionRadius = 160e-3; % junc radius [um]
% distSLcyto = 0.45; % dist. SL to cytosol [um]
% %distJuncSL = 0.5; % dist. junc to SL [um] RABBIT
% distJuncSL = 0.3; % dist. junc to SL [um] MOUSE
% DcaJuncSL = 1.64e-6; % Dca junc to SL [cm^2/sec]
% DcaSLcyto = 1.22e-6; % Dca SL to cyto [cm^2/sec]
% DnaJuncSL = 1.09e-5; % Dna junc to SL [cm^2/sec]
% DnaSLcyto = 1.79e-5; % Dna SL to cyto [cm^2/sec] 
% Vcell = pi*cellRadius^2*cellLength*1e-15; % [L]
% Vmyo = 0.65*Vcell; Vsr = 0.035*Vcell; Vsl = 0.02*Vcell; Vjunc = 0.0539*.01*Vcell; 
% Vls = 0.020*Vcell;
% 
% % WT
% tot_WT_b2 = [WT_y36_b2(:).integral].*Vjunc + [WT_y31_b2(:).integral].*Vsr + [WT_y37_b2(:).integral].*Vsl + ...
%             [WT_y38_b2(:).integral].*Vmyo + [WT_y88_b2(:).integral].*Vls;
% tot_WT_b3 = [WT_y36_b3(:).integral].*Vjunc + [WT_y31_b3(:).integral].*Vsr + [WT_y37_b3(:).integral].*Vsl + ...
%             [WT_y38_b3(:).integral].*Vmyo + [WT_y88_b3(:).integral].*Vls;
% tot_WT_b4 = [WT_y36_b4(:).integral].*Vjunc + [WT_y31_b4(:).integral].*Vsr + [WT_y37_b4(:).integral].*Vsl + ...
%             [WT_y38_b4(:).integral].*Vmyo + [WT_y88_b4(:).integral].*Vls;        
% tot_WT_b5 = [WT_y36_b5(:).integral].*Vjunc + [WT_y31_b5(:).integral].*Vsr + [WT_y37_b5(:).integral].*Vsl + ...
%             [WT_y38_b5(:).integral].*Vmyo + [WT_y88_b5(:).integral].*Vls;        
% % ls2j
% tot_ls2j_b2 = [ls2j_y36_b2(:).integral].*Vjunc + [ls2j_y31_b2(:).integral].*Vsr + [ls2j_y37_b2(:).integral].*Vsl + ...
%             [ls2j_y38_b2(:).integral].*Vmyo + [ls2j_y88_b2(:).integral].*Vls;
% tot_ls2j_b3 = [ls2j_y36_b3(:).integral].*Vjunc + [ls2j_y31_b3(:).integral].*Vsr + [ls2j_y37_b3(:).integral].*Vsl + ...
%             [ls2j_y38_b3(:).integral].*Vmyo + [ls2j_y88_b3(:).integral].*Vls;
% tot_ls2j_b4 = [ls2j_y36_b4(:).integral].*Vjunc + [ls2j_y31_b4(:).integral].*Vsr + [ls2j_y37_b4(:).integral].*Vsl + ...
%             [ls2j_y38_b4(:).integral].*Vmyo + [ls2j_y88_b4(:).integral].*Vls;        
% tot_ls2j_b5 = [ls2j_y36_b5(:).integral].*Vjunc + [ls2j_y31_b5(:).integral].*Vsr + [ls2j_y37_b5(:).integral].*Vsl + ...
%             [ls2j_y38_b5(:).integral].*Vmyo + [ls2j_y88_b5(:).integral].*Vls;     
% % ls2i
% tot_ls2i_b2 = [ls2i_y36_b2(:).integral].*Vjunc + [ls2i_y31_b2(:).integral].*Vsr + [ls2i_y37_b2(:).integral].*Vsl + ...
%             [ls2i_y38_b2(:).integral].*Vmyo + [ls2i_y88_b2(:).integral].*Vls;
% tot_ls2i_b3 = [ls2i_y36_b3(:).integral].*Vjunc + [ls2i_y31_b3(:).integral].*Vsr + [ls2i_y37_b3(:).integral].*Vsl + ...
%             [ls2i_y38_b3(:).integral].*Vmyo + [ls2i_y88_b3(:).integral].*Vls;
% tot_ls2i_b4 = [ls2i_y36_b4(:).integral].*Vjunc + [ls2i_y31_b4(:).integral].*Vsr + [ls2i_y37_b4(:).integral].*Vsl + ...
%             [ls2i_y38_b4(:).integral].*Vmyo + [ls2i_y88_b4(:).integral].*Vls;        
% tot_ls2i_b5 = [ls2i_y36_b5(:).integral].*Vjunc + [ls2i_y31_b5(:).integral].*Vsr + [ls2i_y37_b5(:).integral].*Vsl + ...
%             [ls2i_y38_b5(:).integral].*Vmyo + [ls2i_y88_b5(:).integral].*Vls;     
% 
% close all
% figure(7)
% num = numel(tot_WT_b2);
% ex = 1:4;
% ey_WT = [mean(tot_WT_b2),mean(tot_WT_b3),mean(tot_WT_b4),mean(tot_WT_b5)];
% err_WT = [std(tot_WT_b2)/sqrt(num),std(tot_WT_b3)/sqrt(num),std(tot_WT_b4)/sqrt(num),std(tot_WT_b5)/sqrt(num)];   
%     
% ey_ls2j = [mean(tot_ls2j_b2),mean(tot_ls2j_b3),mean(tot_ls2j_b4),mean(tot_ls2j_b5)];
% err_ls2j = [std(tot_ls2j_b2)/sqrt(num),std(tot_ls2j_b3)/sqrt(num),std(tot_ls2j_b4)/sqrt(num),std(tot_ls2j_b5)/sqrt(num)];   
%  
% ey_ls2i = [mean(tot_ls2i_b2),mean(tot_ls2i_b3),mean(tot_ls2i_b4),mean(tot_ls2i_b5)];
% err_ls2i = [std(tot_ls2i_b2)/sqrt(num),std(tot_ls2i_b3)/sqrt(num),std(tot_ls2i_b4)/sqrt(num),std(tot_ls2i_b5)/sqrt(num)];   
% 
% errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
% errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 
% 
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% 
% ylim([5.5e-5 8.5e-5])
% ax = gca;
% ax.YAxis.Exponent = -5;
% legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Intracellular (nmol)'})
% title({'10Hz Fast Pacing and ISO',''})
% % title({' ',' '})
% 
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_tot_integral_vol_withls'),'-dtiff','-r300')
% close
% 
% tot_WT_b2 = tot_WT_b2 - [WT_y88_b2(:).integral].*Vls;
% tot_WT_b3 = tot_WT_b3 - [WT_y88_b3(:).integral].*Vls;
% tot_WT_b4 = tot_WT_b4 - [WT_y88_b4(:).integral].*Vls;        
% tot_WT_b5 = tot_WT_b5 - [WT_y88_b5(:).integral].*Vls;        
% % ls2j
% tot_ls2j_b2 = tot_ls2j_b2 - [ls2j_y88_b2(:).integral].*Vls;
% tot_ls2j_b3 = tot_ls2j_b3 - [ls2j_y88_b3(:).integral].*Vls;
% tot_ls2j_b4 = tot_ls2j_b4 - [ls2j_y88_b4(:).integral].*Vls;        
% tot_ls2j_b5 = tot_ls2j_b5 - [ls2j_y88_b5(:).integral].*Vls;     
% % ls2i
% tot_ls2i_b2 = tot_ls2i_b2 - [ls2i_y88_b2(:).integral].*Vls;
% tot_ls2i_b3 = tot_ls2i_b3 - [ls2i_y88_b3(:).integral].*Vls;
% tot_ls2i_b4 = tot_ls2i_b4 - [ls2i_y88_b4(:).integral].*Vls;        
% tot_ls2i_b5 = tot_ls2i_b5 - [ls2i_y88_b5(:).integral].*Vls;     
% 
% errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
% errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 
% 
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
% 
% ylim([5.5e-5 8.5e-5])
% ax = gca;
% ax.YAxis.Exponent = -5;
% legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'[Ca] Intracellular minus', 'Lysosome (nmol)'})
% % title({'25Hz Fast Pacing and ISO',''})
% title({' ',' '})
% 
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_tot_integral_vol_wols'),'-dtiff','-r300')
% close

%% errorbar serca
close 
figure(7)
num = numel([WT_serca_b2(:).integralY]);
ex = 1:4;
ey_WT = [mean([WT_serca_b2(:).integralY]),...
         mean([WT_serca_b3(:).integralY]),...
         mean([WT_serca_b4(:).integralY]),...
         mean([WT_serca_b5(:).integralY])];
err_WT = [std([WT_serca_b2(:).integralY])/sqrt(num),...
          std([WT_serca_b3(:).integralY])/sqrt(num),...
          std([WT_serca_b4(:).integralY])/sqrt(num),...
          std([WT_serca_b5(:).integralY])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_serca_b2(:).integralY]),...
           mean([ls2j_serca_b3(:).integralY]),...
           mean([ls2j_serca_b4(:).integralY]),...
           mean([ls2j_serca_b5(:).integralY])];
err_ls2j = [std([ls2j_serca_b2(:).integralY])/sqrt(num),...
            std([ls2j_serca_b3(:).integralY])/sqrt(num),...
            std([ls2j_serca_b4(:).integralY])/sqrt(num),...
            std([ls2j_serca_b5(:).integralY])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_serca_b2(:).integralY]),...
           mean([ls2i_serca_b3(:).integralY]),...
           mean([ls2i_serca_b4(:).integralY]),...
           mean([ls2i_serca_b5(:).integralY])];
err_ls2i = [std([ls2i_serca_b2(:).integralY])/sqrt(num),...
            std([ls2i_serca_b3(:).integralY])/sqrt(num),...
            std([ls2i_serca_b4(:).integralY])/sqrt(num),...
            std([ls2i_serca_b5(:).integralY])/sqrt(num)]; 

errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 

ylim([6e4 14e4])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'10Hz Fast Pacing and ISO',' '})
title({' ',' '})
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_serca'),'-dtiff','-r300')
%% errorbar ryr
close 
figure(7)
num = numel([WT_ryr_b2(:).integralY]);
ex = 1:4;
ey_WT = [mean([WT_ryr_b2(:).integralY]),...
         mean([WT_ryr_b3(:).integralY]),...
         mean([WT_ryr_b4(:).integralY]),...
         mean([WT_ryr_b5(:).integralY])];
err_WT = [std([WT_ryr_b2(:).integralY])/sqrt(num),...
          std([WT_ryr_b3(:).integralY])/sqrt(num),...
          std([WT_ryr_b4(:).integralY])/sqrt(num),...
          std([WT_ryr_b5(:).integralY])/sqrt(num)];   
    
ey_ls2j = [mean([ls2j_ryr_b2(:).integralY]),...
           mean([ls2j_ryr_b3(:).integralY]),...
           mean([ls2j_ryr_b4(:).integralY]),...
           mean([ls2j_ryr_b5(:).integralY])];
err_ls2j = [std([ls2j_ryr_b2(:).integralY])/sqrt(num),...
            std([ls2j_ryr_b3(:).integralY])/sqrt(num),...
            std([ls2j_ryr_b4(:).integralY])/sqrt(num),...
            std([ls2j_ryr_b5(:).integralY])/sqrt(num)];   
 
ey_ls2i = [mean([ls2i_ryr_b2(:).integralY]),...
           mean([ls2i_ryr_b3(:).integralY]),...
           mean([ls2i_ryr_b4(:).integralY]),...
           mean([ls2i_ryr_b5(:).integralY])];
err_ls2i = [std([ls2i_ryr_b2(:).integralY])/sqrt(num),...
            std([ls2i_ryr_b3(:).integralY])/sqrt(num),...
            std([ls2i_ryr_b4(:).integralY])/sqrt(num),...
            std([ls2i_ryr_b5(:).integralY])/sqrt(num)]; 


errorbar(ex, ey_WT, err_WT,'LineWidth', 2,'Color','b'); hold on
errorbar(ex, ey_ls2j, err_ls2j,'LineWidth', 2,'Color','k'); hold on
errorbar(ex, ey_ls2i, err_ls2i,'LineWidth', 2,'Color','r'); 

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:4)
set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 

ylim([1e6 2.5e6])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'10Hz Fast Pacing and ISO',''})
title({' ',' '})

set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'fig9_ryr'),'-dtiff','-r300')

% %% errorbar cal
% close 
% figure(7)
% num = numel([WT_cal_b2(:).integral]);
% ex = 1:4;
% ey_WT = [mean([WT_cal_b2(:).integral]),...
%          mean([WT_cal_b3(:).integral]),...
%          mean([WT_cal_b4(:).integral]),...
%          mean([WT_cal_b5(:).integral])];
% err_WT = [std([WT_cal_b2(:).integral])/sqrt(num),...
%           std([WT_cal_b3(:).integral])/sqrt(num),...
%           std([WT_cal_b4(:).integral])/sqrt(num),...
%           std([WT_cal_b5(:).integral])/sqrt(num)];   
%     
% ey_ls2j = [mean([ls2j_cal_b2(:).integral]),...
%            mean([ls2j_cal_b3(:).integral]),...
%            mean([ls2j_cal_b4(:).integral]),...
%            mean([ls2j_cal_b5(:).integral])];
% err_ls2j = [std([ls2j_cal_b2(:).integral])/sqrt(num),...
%             std([ls2j_cal_b3(:).integral])/sqrt(num),...
%             std([ls2j_cal_b4(:).integral])/sqrt(num),...
%             std([ls2j_cal_b5(:).integral])/sqrt(num)];   
%  
% ey_ls2i = [mean([ls2i_cal_b2(:).integral]),...
%            mean([ls2i_cal_b3(:).integral]),...
%            mean([ls2i_cal_b4(:).integral]),...
%            mean([ls2i_cal_b5(:).integral])];
% err_ls2i = [std([ls2i_cal_b2(:).integral])/sqrt(num),...
%             std([ls2i_cal_b3(:).integral])/sqrt(num),...
%             std([ls2i_cal_b4(:).integral])/sqrt(num),...
%             std([ls2i_cal_b5(:).integral])/sqrt(num)]; 
% 
% errorbar(ex, abs(ey_WT), err_WT,'LineWidth', 2,'Color','b'); hold on
% errorbar(ex, abs(ey_ls2j), err_ls2j,'LineWidth', 2,'Color','k'); hold on
% errorbar(ex, abs(ey_ls2i), err_ls2i,'LineWidth', 2,'Color','r'); 
%  
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:4)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4'}) 
%  
% ylim([19e1 24e1])
% ax = gca;
% ax.YAxis.Exponent = 1;
% legend('WT','J_{ls,up} = 0','J_{ls,rel} = 0','Location','northeast','Orientation','vertical');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'CaL [Ca] Current (pA/pF)'})
% % title({'10Hz Fast Pacing and ISO',''})
% title({' ',' '})
%  
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'er_beat1_4_cal_beat_integral'),'-dtiff','-r300')
%% boxplot integral y36-y31 over peak
% figure(7)
% bx = [[WT_serca_b1(:).peak_integralY]-[WT_ryr_b1(:).peak_integralY],[ls2j_serca_b1(:).peak_integralY]-[ls2j_ryr_b1(:).peak_integralY],[ls2i_serca_b1(:).peak_integralY]-[ls2i_ryr_b1(:).peak_integralY],...
%       [WT_serca_b2(:).peak_integralY]-[WT_ryr_b2(:).peak_integralY],[ls2j_serca_b2(:).peak_integralY]-[ls2j_ryr_b2(:).peak_integralY],[ls2i_serca_b2(:).peak_integralY]-[ls2i_ryr_b2(:).peak_integralY],...
%       [WT_serca_b3(:).peak_integralY]-[WT_ryr_b3(:).peak_integralY],[ls2j_serca_b3(:).peak_integralY]-[ls2j_ryr_b3(:).peak_integralY],[ls2i_serca_b3(:).peak_integralY]-[ls2i_ryr_b3(:).peak_integralY],...
%       [WT_serca_b4(:).peak_integralY]-[WT_ryr_b4(:).peak_integralY],[ls2j_serca_b4(:).peak_integralY]-[ls2j_ryr_b4(:).peak_integralY],[ls2i_serca_b4(:).peak_integralY]-[ls2i_ryr_b4(:).peak_integralY],...
%       [WT_serca_b5(:).peak_integralY]-[WT_ryr_b5(:).peak_integralY],[ls2j_serca_b5(:).peak_integralY]-[ls2j_ryr_b5(:).peak_integralY],[ls2i_serca_b5(:).peak_integralY]-[ls2i_ryr_b5(:).peak_integralY],...
%       ]; 
% by = [zeros(length([WT_y38_b1(:).peak_integralY]), 1);1*ones(length([ls2j_y38_b1(:).peak_integralY]), 1);2*ones(length([ls2i_y38_b1(:).peak_integralY]), 1);...
%       3*ones(length([WT_y38_b2(:).peak_integralY]), 1);4*ones(length([ls2j_y38_b2(:).peak_integralY]), 1);5*ones(length([ls2i_y38_b2(:).peak_integralY]), 1);...
%       6*ones(length([WT_y38_b3(:).peak_integralY]), 1);7*ones(length([ls2j_y38_b3(:).peak_integralY]), 1);8*ones(length([ls2i_y38_b3(:).peak_integralY]), 1);...
%       9*ones(length([WT_y38_b4(:).peak_integralY]), 1);10*ones(length([ls2j_y38_b4(:).peak_integralY]), 1);11*ones(length([ls2i_y38_b4(:).peak_integralY]), 1);...
%       12*ones(length([WT_y38_b5(:).peak_integralY]), 1);13*ones(length([ls2j_y38_b5(:).peak_integralY]), 1);14*ones(length([ls2i_y38_b5(:).peak_integralY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','southwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Integral [Ca] Difference of','SERCA and RyR over Peak (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_serca-ryr_peak_integral'),'-dtiff','-r300')
% close
%% pcc serca
% figure(20)
% bnum = 1; %y38, y31, y36, y88
% B = {'b1','b2','b3','b4','b5'};
% 
% %% WT
% x = [[WT_serca_b1(:).peak_integralY]';...
% %      [WT_serca_b4(:).peak_integralY]';...
% %      [WT_serca_b3(:).peak_integralY]';...
% %      [WT_serca_b2(:).peak_integralY]';...
% %      [WT_serca_b1(:).peak_integralY]';...
%      ];
% % y = repmat(gpdad,5,1);
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[WT_serca_b1(:).integral]';...
% %      [WT_serca_b4(:).integral]';...
% %      [WT_serca_b3(:).integral]';...
% %      [WT_serca_b2(:).integral]';...
% %      [WT_serca_b1(:).integral]';...
%      ];
% % y = repmat(gpdad,5,1);
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_serca_b1(:).peak_integralY]';...
% %      [ls2j_serca_b4(:).peak_integralY]';...
% %      [ls2j_serca_b3(:).peak_integralY]';...
% %      [ls2j_serca_b2(:).peak_integralY]';...
% %      [ls2j_serca_b1(:).peak_integralY]';...
%      ];
% % y = repmat(gpdadjdot0,5,1);
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2j_serca_b1(:).integral]';...
% %      [ls2j_serca_b4(:).integral]';...
% %      [ls2j_serca_b3(:).integral]';...
% %      [ls2j_serca_b2(:).integral]';...
% %      [ls2j_serca_b1(:).integral]';...
%       ];  
% % y = repmat(gpdadjdot0,5,1);
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_serca_b1(:).peak_integralY]';...
% %      [ls2i_serca_b4(:).peak_integralY]';...
% %      [ls2i_serca_b3(:).peak_integralY]';...
% %      [ls2i_serca_b2(:).peak_integralY]';...
% %      [ls2i_serca_b1(:).peak_integralY]';...
%      ];
% % y = repmat(gpdadidot0,5,1);
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2i_serca_b1(:).integral]';...
% %      [ls2i_serca_b4(:).integral]';...
% %      [ls2i_serca_b3(:).integral]';...
% %      [ls2i_serca_b2(:).integral]';...
% %      [ls2i_serca_b1(:).integral]';...
%      ];
% % y = repmat(gpdadidot0,5,1);
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] of SERCA over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA over Peak}',...
%      '{WT} {Integral [Ca] SERCA over a Beat}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA over a Beat}',...
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat %d',bnum);
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, sprintf('pcc_WT_j_i_serca_b%d',bnum)),'-dtiff','-r300')
% close 
% 
%% pcc serca-ryr
% figure(20)
% bnum = 5; %y38, y31, y36, y88
% B = {'b1','b2','b3','b4','b5'};
% %% WT
% x = [[WT_serca_b5(:).peak_integralY]'-[WT_ryr_b5(:).peak_integralY]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[WT_serca_b5(:).integral]'-[WT_ryr_b5(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_serca_b5(:).peak_integralY]'-[ls2j_ryr_b5(:).peak_integralY]',...
%      ];
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2j_serca_b5(:).integral]'-[ls2j_ryr_b5(:).integral]',...
%       ];  
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_serca_b5(:).peak_integralY]'-[ls2i_ryr_b5(:).peak_integralY]',...
%      ]
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2i_serca_b5(:).integral]'-[ls2i_ryr_b5(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{WT} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat %d',bnum);
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, sprintf('pcc_WT_j_i_serca-ryr_b%d',bnum)),'-dtiff','-r300')
% close 

%% pcc integral calcium difference of y36 - y31 beat 5
% figure(20)
% bnum = 5; %y38, y31, y36, y88
% B = {'b1','b2','b3','b4','b5'};
% %% WT
% x = [[WT_y36_b5(:).peak_integralY]'-[WT_y31_b5(:).peak_integralY]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[WT_y36_b5(:).integral]'-[WT_y31_b5(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_y36_b5(:).peak_integralY]'-[ls2j_y31_b5(:).peak_integralY]',...
%      ];
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2j_y36_b5(:).integral]'-[ls2j_y31_b5(:).integral]',...
%       ];  
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_y36_b5(:).peak_integralY]'-[ls2i_y31_b5(:).peak_integralY]',...
%      ];
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2i_y36_b5(:).integral]'-[ls2i_y31_b5(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT}, {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{J_{ls2j} = 0}, {Integral [Ca] Difference of Junction and SR over Peak}',...    
%      '{J_{ls2i} = 0}, {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{WT}, {Integral [Ca] Difference of Junction and SR over a Beat}',...
%      '{J_{ls2j} = 0}, {Integral [Ca] Difference of Junction and SR over a Beat}',...
%      '{J_{ls2i} = 0}, {Integral [Ca] Difference of Junction and SR over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat %d',bnum);
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, sprintf('pcc_WT_j_i_y36-y31_b%d',bnum)),'-dtiff','-r300')
% close 


%% PCC gpdad beat 1-5
% figure(20)
% %% WT beat 1-5
% x = [[WT_y31_b1(:).integral]',...
%      [WT_y31_b2(:).integral]',...
%      [WT_y31_b3(:).integral]',...
%      [WT_y31_b4(:).integral]',...
%      [WT_y31_b5(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% j beat 1-5
% x = [[ls2j_y31_b1(:).integral]',...
%      [ls2j_y31_b2(:).integral]',...
%      [ls2j_y31_b3(:).integral]',...
%      [ls2j_y31_b4(:).integral]',...
%      [ls2j_y31_b5(:).integral]',...
%      ];
% y = gpdadjdot0;
% [rho_sls2jy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i beat 1-5
% x = [[ls2i_y31_b1(:).integral]',...
%      [ls2i_y31_b2(:).integral]',...
%      [ls2i_y31_b3(:).integral]',...
%      [ls2i_y31_b4(:).integral]',...
%      [ls2i_y31_b5(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_sls2iy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      
%      '{WT} {Integral DAD [Ca] CS}',...
%      '{J_{ls2j} = 0} {Integral DAD [Ca] CS}',...
%      '{J_{ls2i} = 0} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% 
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_WT_j_i_'),'-dtiff','-r300')
% close

%% pcc beat 5 y31_integral y38_dad
% figure(20)
% %% c
% x = [[WT_y31_b1(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% 
% x = [[WT_y38_b1(:).dad_ampY]',...
%      ];
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_y31_b1(:).integral]',...
%      ];
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2j_y38_b1(:).dad_ampY]',...
%       ];  
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_y31_b1(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2i_y38_b1(:).dad_ampY]',...
%      ];
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...    
%      '{WT} {DAD Amplitude [Ca] CS}',...
%      '{J_{ls2j} = 0} {DAD Amplitude [Ca] CS}',...
%      '{J_{ls2i} = 0} {DAD Amplitude [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat 1');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_WT_j_i_beat1'),'-dtiff','-r300')
% close

%% pcc beat 1-5 y31_integral y38_dad_integral reduction in loss of each of fluxes
% figure(20)
% %% c
% x = [[WT_y31_b5(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% 
% x = [[WT_y38_b5(:).dad_integralY]',...
%      ];
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_y31_b5(:).integral]',...
%      ];
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[WT_y38_b5(:).dad_integralY]'-[ls2j_y38_b5(:).dad_integralY]',...
%       ];  
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_y31_b5(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[WT_y38_b5(:).dad_integralY]'-[ls2i_y38_b5(:).dad_integralY]',...
%      ];
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...    
%      '{WT} {DAD Integral [Ca] CS}',...
%      '{J_{ls2j} = 0} {DAD Integral minus WT}',...
%      '{J_{ls2i} = 0} {DAD Integral minus WT}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat 5');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_WT_j_i_intminus_beat5'),'-dtiff','-r300')
% close
%%
% figure(7)
% bx = [[markery31(:).dad_ampY],...
%       [markery31_jdot0(:).dad_ampY],...
%       [markery31_idot0(:).dad_ampY],... 
%       ]; 
% by = [ zeros(length([markery31(:).dad_ampY]), 1);...
%        1*ones(length([markery31_jdot0(:).dad_ampY]), 1);...       
%        2*ones(length([markery31_idot0(:).dad_ampY]), 1);...
%        ];
% lbl ={'WT','J_{ls,up}=0','J_{ls,rel} = 0'}; 
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 5;
% % legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR of','DAD Amplitude (nM)'})
% title({'Group 1','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_ampdad'),'-dtiff','-r300')
% close
%% boxplot y38_dad_intergral Group DAD123 over beat 1-5
% figure(7)
% bx = [[WT_y38_b1(:).dad_integralY],[ls2j_y38_b1(:).dad_integralY],[ls2i_y38_b1(:).dad_integralY],...
%       [WT_y38_b2(:).dad_integralY],[ls2j_y38_b2(:).dad_integralY],[ls2i_y38_b2(:).dad_integralY],...
%       [WT_y38_b3(:).dad_integralY],[ls2j_y38_b3(:).dad_integralY],[ls2i_y38_b3(:).dad_integralY],...
%       [WT_y38_b4(:).dad_integralY],[ls2j_y38_b4(:).dad_integralY],[ls2i_y38_b4(:).dad_integralY],...
%       [WT_y38_b5(:).dad_integralY],[ls2j_y38_b5(:).dad_integralY],[ls2i_y38_b5(:).dad_integralY],...
%       ]; 
% by = [zeros(length([WT_y38_b1(:).dad_integralY]), 1);1*ones(length([ls2j_y38_b1(:).dad_integralY]), 1);2*ones(length([ls2i_y38_b1(:).dad_integralY]), 1);...
%       3*ones(length([WT_y38_b2(:).dad_integralY]), 1);4*ones(length([ls2j_y38_b2(:).dad_integralY]), 1);5*ones(length([ls2i_y38_b2(:).dad_integralY]), 1);...
%       6*ones(length([WT_y38_b3(:).dad_integralY]), 1);7*ones(length([ls2j_y38_b3(:).dad_integralY]), 1);8*ones(length([ls2i_y38_b3(:).dad_integralY]), 1);...
%       9*ones(length([WT_y38_b4(:).dad_integralY]), 1);10*ones(length([ls2j_y38_b4(:).dad_integralY]), 1);11*ones(length([ls2i_y38_b4(:).dad_integralY]), 1);...
%       12*ones(length([WT_y38_b5(:).dad_integralY]), 1);13*ones(length([ls2j_y38_b5(:).dad_integralY]), 1);14*ones(length([ls2i_y38_b5(:).dad_integralY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Integral of','Spontaneous [Ca] Cytosol (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y38_dad_integral'),'-dtiff','-r300')
% close

%% boxplot y38_dad_amplitude Group DAD123 over beat 1-5
% figure(7)
% bx = [[WT_y38_b1(:).dad_ampY],[ls2j_y38_b1(:).dad_ampY],[ls2i_y38_b1(:).dad_ampY],...
%       [WT_y38_b2(:).dad_ampY],[ls2j_y38_b2(:).dad_ampY],[ls2i_y38_b2(:).dad_ampY],...
%       [WT_y38_b3(:).dad_ampY],[ls2j_y38_b3(:).dad_ampY],[ls2i_y38_b3(:).dad_ampY],...
%       [WT_y38_b4(:).dad_ampY],[ls2j_y38_b4(:).dad_ampY],[ls2i_y38_b4(:).dad_ampY],...
%       [WT_y38_b5(:).dad_ampY],[ls2j_y38_b5(:).dad_ampY],[ls2i_y38_b5(:).dad_ampY],...
%       ]; 
% by = [zeros(length([WT_y38_b1(:).dad_ampY]), 1);1*ones(length([ls2j_y38_b1(:).dad_ampY]), 1);2*ones(length([ls2i_y38_b1(:).dad_ampY]), 1);...
%       3*ones(length([WT_y38_b2(:).dad_ampY]), 1);4*ones(length([ls2j_y38_b2(:).dad_ampY]), 1);5*ones(length([ls2i_y38_b2(:).dad_ampY]), 1);...
%       6*ones(length([WT_y38_b3(:).dad_ampY]), 1);7*ones(length([ls2j_y38_b3(:).dad_ampY]), 1);8*ones(length([ls2i_y38_b3(:).dad_ampY]), 1);...
%       9*ones(length([WT_y38_b4(:).dad_ampY]), 1);10*ones(length([ls2j_y38_b4(:).dad_ampY]), 1);11*ones(length([ls2i_y38_b4(:).dad_ampY]), 1);...
%       12*ones(length([WT_y38_b5(:).dad_ampY]), 1);13*ones(length([ls2j_y38_b5(:).dad_ampY]), 1);14*ones(length([ls2i_y38_b5(:).dad_ampY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Amplitude of','Spontaneous [Ca] Cytosol (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y38dadamp_0'),'-dtiff','-r300')
% close

%% boxplot y38_amplitude Group DAD123 over beat 1-5
% figure(7)
% bx = [[WT_y38_b1(:).ampY],[ls2j_y38_b1(:).ampY],[ls2i_y38_b1(:).ampY],...
%       [WT_y38_b2(:).ampY],[ls2j_y38_b2(:).ampY],[ls2i_y38_b2(:).ampY],...
%       [WT_y38_b3(:).ampY],[ls2j_y38_b3(:).ampY],[ls2i_y38_b3(:).ampY],...
%       [WT_y38_b4(:).ampY],[ls2j_y38_b4(:).ampY],[ls2i_y38_b4(:).ampY],...
%       [WT_y38_b5(:).ampY],[ls2j_y38_b5(:).ampY],[ls2i_y38_b5(:).ampY],...
%       ]; 
% by = [zeros(length([WT_y38_b1(:).ampY]), 1);1*ones(length([ls2j_y38_b1(:).ampY]), 1);2*ones(length([ls2i_y38_b1(:).ampY]), 1);...
%       3*ones(length([WT_y38_b2(:).ampY]), 1);4*ones(length([ls2j_y38_b2(:).ampY]), 1);5*ones(length([ls2i_y38_b2(:).ampY]), 1);...
%       6*ones(length([WT_y38_b3(:).ampY]), 1);7*ones(length([ls2j_y38_b3(:).ampY]), 1);8*ones(length([ls2i_y38_b3(:).ampY]), 1);...
%       9*ones(length([WT_y38_b4(:).ampY]), 1);10*ones(length([ls2j_y38_b4(:).ampY]), 1);11*ones(length([ls2i_y38_b4(:).ampY]), 1);...
%       12*ones(length([WT_y38_b5(:).ampY]), 1);13*ones(length([ls2j_y38_b5(:).ampY]), 1);14*ones(length([ls2i_y38_b5(:).ampY]), 1);...
%       ];
% 
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','southeast','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] Cytosol Amplitude (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y38amp_0'),'-dtiff','-r300')
% close

%% boxplot y38_integral
% figure(7)
% bx = [[WT_y38_b1(:).integral],[ls2j_y38_b1(:).integral],[ls2i_y38_b1(:).integral],...
%       [WT_y38_b2(:).integral],[ls2j_y38_b2(:).integral],[ls2i_y38_b2(:).integral],...
%       [WT_y38_b3(:).integral],[ls2j_y38_b3(:).integral],[ls2i_y38_b3(:).integral],...
%       [WT_y38_b4(:).integral],[ls2j_y38_b4(:).integral],[ls2i_y38_b4(:).integral],...
%       [WT_y38_b5(:).integral],[ls2j_y38_b5(:).integral],[ls2i_y38_b5(:).integral],...
%       ]; 
% by = [zeros(length([WT_y38_b1(:).integral]), 1);1*ones(length([ls2j_y38_b1(:).integral]), 1);2*ones(length([ls2i_y38_b1(:).integral]), 1);...
%       3*ones(length([WT_y38_b2(:).integral]), 1);4*ones(length([ls2j_y38_b2(:).integral]), 1);5*ones(length([ls2i_y38_b2(:).integral]), 1);...
%       6*ones(length([WT_y38_b3(:).integral]), 1);7*ones(length([ls2j_y38_b3(:).integral]), 1);8*ones(length([ls2i_y38_b3(:).integral]), 1);...
%       9*ones(length([WT_y38_b4(:).integral]), 1);10*ones(length([ls2j_y38_b4(:).integral]), 1);11*ones(length([ls2i_y38_b4(:).integral]), 1);...
%       12*ones(length([WT_y38_b5(:).integral]), 1);13*ones(length([ls2j_y38_b5(:).integral]), 1);14*ones(length([ls2i_y38_b5(:).integral]), 1);...
%       ];
% 
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','southeast','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Integral [Ca] Cytosol (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y38int_0'),'-dtiff','-r300')
% close

%% boxplot y31_integral peak
% figure(7)
% bx = [[WT_y31_b1(:).peak_integralY],[ls2j_y31_b1(:).peak_integralY],[ls2i_y31_b1(:).peak_integralY],...
%       [WT_y31_b2(:).peak_integralY],[ls2j_y31_b2(:).peak_integralY],[ls2i_y31_b2(:).peak_integralY],...
%       [WT_y31_b3(:).peak_integralY],[ls2j_y31_b3(:).peak_integralY],[ls2i_y31_b3(:).peak_integralY],...
%       [WT_y31_b4(:).peak_integralY],[ls2j_y31_b4(:).peak_integralY],[ls2i_y31_b4(:).peak_integralY],...
%       [WT_y31_b5(:).peak_integralY],[ls2j_y31_b5(:).peak_integralY],[ls2i_y31_b5(:).peak_integralY],...
%       ]; 
% by = [zeros(length([WT_y31_b1(:).peak_integralY]), 1);1*ones(length([ls2j_y31_b1(:).peak_integralY]), 1);2*ones(length([ls2i_y31_b1(:).peak_integralY]), 1);...
%       3*ones(length([WT_y31_b2(:).peak_integralY]), 1);4*ones(length([ls2j_y31_b2(:).peak_integralY]), 1);5*ones(length([ls2i_y31_b2(:).peak_integralY]), 1);...
%       6*ones(length([WT_y31_b3(:).peak_integralY]), 1);7*ones(length([ls2j_y31_b3(:).peak_integralY]), 1);8*ones(length([ls2i_y31_b3(:).peak_integralY]), 1);...
%       9*ones(length([WT_y31_b4(:).peak_integralY]), 1);10*ones(length([ls2j_y31_b4(:).peak_integralY]), 1);11*ones(length([ls2i_y31_b4(:).peak_integralY]), 1);...
%       12*ones(length([WT_y31_b5(:).peak_integralY]), 1);13*ones(length([ls2j_y31_b5(:).peak_integralY]), 1);14*ones(length([ls2i_y31_b5(:).peak_integralY]), 1);...
%       ];
% 
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR Integral Peak(nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y31_peak_integral'),'-dtiff','-r300')
% close

% %% boxplot y31_integral
% figure(7)
% bx = [[WT_y31_b1(:).integral],[ls2j_y31_b1(:).integral],[ls2i_y31_b1(:).integral],...
%       [WT_y31_b2(:).integral],[ls2j_y31_b2(:).integral],[ls2i_y31_b2(:).integral],...
%       [WT_y31_b3(:).integral],[ls2j_y31_b3(:).integral],[ls2i_y31_b3(:).integral],...
%       [WT_y31_b4(:).integral],[ls2j_y31_b4(:).integral],[ls2i_y31_b4(:).integral],...
%       [WT_y31_b5(:).integral],[ls2j_y31_b5(:).integral],[ls2i_y31_b5(:).integral],...
%       ]; 
% by = [zeros(length([WT_y31_b1(:).integral]), 1);1*ones(length([ls2j_y31_b1(:).integral]), 1);2*ones(length([ls2i_y31_b1(:).integral]), 1);...
%       3*ones(length([WT_y31_b2(:).integral]), 1);4*ones(length([ls2j_y31_b2(:).integral]), 1);5*ones(length([ls2i_y31_b2(:).integral]), 1);...
%       6*ones(length([WT_y31_b3(:).integral]), 1);7*ones(length([ls2j_y31_b3(:).integral]), 1);8*ones(length([ls2i_y31_b3(:).integral]), 1);...
%       9*ones(length([WT_y31_b4(:).integral]), 1);10*ones(length([ls2j_y31_b4(:).integral]), 1);11*ones(length([ls2i_y31_b4(:).integral]), 1);...
%       12*ones(length([WT_y31_b5(:).integral]), 1);13*ones(length([ls2j_y31_b5(:).integral]), 1);14*ones(length([ls2i_y31_b5(:).integral]), 1);...
%       ];
% 
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 8;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Integral [Ca] SR (nM) over','a Beat'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_y31int_0'),'-dtiff','-r300')
% close
% 
% %% boxplot serca amplitude 
% figure(7)
% bx = [[WT_serca_b1(:).ampY],[ls2j_serca_b1(:).ampY],[ls2i_serca_b1(:).ampY],...
%       [WT_serca_b2(:).ampY],[ls2j_serca_b2(:).ampY],[ls2i_serca_b2(:).ampY],...
%       [WT_serca_b3(:).ampY],[ls2j_serca_b3(:).ampY],[ls2i_serca_b3(:).ampY],...
%       [WT_serca_b4(:).ampY],[ls2j_serca_b4(:).ampY],[ls2i_serca_b4(:).ampY],...
%       [WT_serca_b5(:).ampY],[ls2j_serca_b5(:).ampY],[ls2i_serca_b5(:).ampY],...
%       ]; 
% by = [zeros(length([WT_serca_b1(:).ampY]), 1);1*ones(length([ls2j_serca_b1(:).ampY]), 1);2*ones(length([ls2i_serca_b1(:).ampY]), 1);...
%       3*ones(length([WT_serca_b2(:).ampY]), 1);4*ones(length([ls2j_serca_b2(:).ampY]), 1);5*ones(length([ls2i_serca_b2(:).ampY]), 1);...
%       6*ones(length([WT_serca_b3(:).ampY]), 1);7*ones(length([ls2j_serca_b3(:).ampY]), 1);8*ones(length([ls2i_serca_b3(:).ampY]), 1);...
%       9*ones(length([WT_serca_b4(:).ampY]), 1);10*ones(length([ls2j_serca_b4(:).ampY]), 1);11*ones(length([ls2i_serca_b4(:).ampY]), 1);...
%       12*ones(length([WT_serca_b5(:).ampY]), 1);13*ones(length([ls2j_serca_b5(:).ampY]), 1);14*ones(length([ls2i_serca_b5(:).ampY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','southeast','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Amplitude of','[Ca] J_{SERCA} (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_amp_serca'),'-dtiff','-r300')
% close
% 
% %% boxplot ryr amplitude
% figure(7)
% bx = [[WT_ryr_b1(:).ampY],[ls2j_ryr_b1(:).ampY],[ls2i_ryr_b1(:).ampY],...
%       [WT_ryr_b2(:).ampY],[ls2j_ryr_b2(:).ampY],[ls2i_ryr_b2(:).ampY],...
%       [WT_ryr_b3(:).ampY],[ls2j_ryr_b3(:).ampY],[ls2i_ryr_b3(:).ampY],...
%       [WT_ryr_b4(:).ampY],[ls2j_ryr_b4(:).ampY],[ls2i_ryr_b4(:).ampY],...
%       [WT_ryr_b5(:).ampY],[ls2j_ryr_b5(:).ampY],[ls2i_ryr_b5(:).ampY],...
%       ]; 
% by = [zeros(length([WT_ryr_b1(:).ampY]), 1);1*ones(length([ls2j_ryr_b1(:).ampY]), 1);2*ones(length([ls2i_ryr_b1(:).ampY]), 1);...
%       3*ones(length([WT_ryr_b2(:).ampY]), 1);4*ones(length([ls2j_ryr_b2(:).ampY]), 1);5*ones(length([ls2i_ryr_b2(:).ampY]), 1);...
%       6*ones(length([WT_ryr_b3(:).ampY]), 1);7*ones(length([ls2j_ryr_b3(:).ampY]), 1);8*ones(length([ls2i_ryr_b3(:).ampY]), 1);...
%       9*ones(length([WT_ryr_b4(:).ampY]), 1);10*ones(length([ls2j_ryr_b4(:).ampY]), 1);11*ones(length([ls2i_ryr_b4(:).ampY]), 1);...
%       12*ones(length([WT_ryr_b5(:).ampY]), 1);13*ones(length([ls2j_ryr_b5(:).ampY]), 1);14*ones(length([ls2i_ryr_b5(:).ampY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Amplitude of','[Ca] J_{RyR} (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_amp_ryr'),'-dtiff','-r300')
% close

%% boxplot ryr-serca integral  
% figure(7)
% bx = [[WT_ryr_b1(:).peak_integralY]-[WT_serca_b1(:).peak_integralY],[ls2j_ryr_b1(:).peak_integralY]-[ls2j_serca_b1(:).peak_integralY],[ls2i_ryr_b1(:).peak_integralY] - [ls2i_serca_b1(:).peak_integralY],...
%       [WT_ryr_b2(:).peak_integralY]-[WT_serca_b2(:).peak_integralY],[ls2j_ryr_b2(:).peak_integralY]-[ls2j_serca_b2(:).peak_integralY],[ls2i_ryr_b2(:).peak_integralY] - [ls2i_serca_b2(:).peak_integralY],...
%       [WT_ryr_b3(:).peak_integralY]-[WT_serca_b3(:).peak_integralY],[ls2j_ryr_b3(:).peak_integralY]-[ls2j_serca_b3(:).peak_integralY],[ls2i_ryr_b3(:).peak_integralY] - [ls2i_serca_b3(:).peak_integralY],...
%       [WT_ryr_b4(:).peak_integralY]-[WT_serca_b4(:).peak_integralY],[ls2j_ryr_b4(:).peak_integralY]-[ls2j_serca_b4(:).peak_integralY],[ls2i_ryr_b4(:).peak_integralY] - [ls2i_serca_b4(:).peak_integralY],...
%       [WT_ryr_b5(:).peak_integralY]-[WT_serca_b5(:).peak_integralY],[ls2j_ryr_b5(:).peak_integralY]-[ls2j_serca_b5(:).peak_integralY],[ls2i_ryr_b5(:).peak_integralY] - [ls2i_serca_b5(:).peak_integralY],...
%       ]; 
% by = [zeros(length([WT_ryr_b1(:).peak_integralY]-[WT_serca_b1(:).peak_integralY]), 1);1*ones(length([ls2j_ryr_b1(:).peak_integralY]-[ls2j_serca_b1(:).peak_integralY]),1);2*ones(length([ls2i_ryr_b1(:).peak_integralY] - [ls2i_serca_b1(:).peak_integralY]), 1);...
%       3*ones(length([WT_ryr_b2(:).peak_integralY]-[WT_serca_b2(:).peak_integralY]), 1);4*ones(length([ls2j_ryr_b2(:).peak_integralY]-[ls2j_serca_b2(:).peak_integralY]), 1);5*ones(length([ls2i_ryr_b2(:).peak_integralY] - [ls2i_serca_b2(:).peak_integralY]), 1);...
%       6*ones(length([WT_ryr_b3(:).peak_integralY]-[WT_serca_b3(:).peak_integralY]), 1);7*ones(length([ls2j_ryr_b3(:).peak_integralY]-[ls2j_serca_b3(:).peak_integralY]), 1);8*ones(length([ls2i_ryr_b3(:).peak_integralY] - [ls2i_serca_b3(:).peak_integralY]), 1);...
%       9*ones(length([WT_ryr_b4(:).peak_integralY]-[WT_serca_b4(:).peak_integralY]), 1);10*ones(length([ls2j_ryr_b4(:).peak_integralY]-[ls2j_serca_b4(:).peak_integralY]), 1);11*ones(length([ls2i_ryr_b4(:).peak_integralY] - [ls2i_serca_b4(:).peak_integralY]), 1);...
%       12*ones(length([WT_ryr_b5(:).peak_integralY]-[WT_serca_b5(:).peak_integralY]), 1);13*ones(length([ls2j_ryr_b5(:).peak_integralY]-[ls2j_serca_b5(:).peak_integralY]), 1);14*ones(length([ls2i_ryr_b5(:).peak_integralY] - [ls2i_serca_b5(:).peak_integralY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 7;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Integral Peak Difference of','J_{RyR} Minus J_{SERCA} (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_Peakint_ryr-serca'),'-dtiff','-r300')
% close

%% pcc SR integral, ryr-serca peak integral 
% figure(20)
% %% c
% x = [[WT_y31_b5(:).integral]',...
%      ];
% y = gpdad;
% [rho_sWTy31,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% 
% x = [[WT_ryr_b5(:).peak_integralY]'-[WT_serca_b5(:).peak_integralY]',...
%      ];
% y = gpdad;
% [rho_sWTy38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[ls2j_y31_b5(:).integral]',...
%      ];
% y = gpdadjdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2j_ryr_b5(:).peak_integralY]'-[ls2j_serca_b5(:).peak_integralY]',...
%       ];  
% y = gpdadjdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[ls2i_y31_b5(:).integral]',...
%      ];
% y = gpdadidot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[ls2i_ryr_b5(:).peak_integralY]'-[ls2i_serca_b5(:).peak_integralY]',...
%      ];
% y = gpdadidot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{WT} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...    
%      '{WT} {Integral RyR and SERCA Peak Difference}',...
%      '{J_{ls2j} = 0} {Integral RyR and SERCA Peak Difference}',...
%      '{J_{ls2i} = 0} {Integral RyR and SERCA Peak Difference}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sWTy31;rho_sjy31;rho_siy31;rho_sWTy38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Fast Pacing and ISO of Beat 5');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_WT_j_i_ryrintminusserca_beat5'),'-dtiff','-r300')
% close

%% boxplot ryr dad amplitude
% figure(7)
% bx = [[WT_ryr_b1(:).dad_ampY],[ls2j_ryr_b1(:).dad_ampY],[ls2i_ryr_b1(:).dad_ampY],...
%       [WT_ryr_b2(:).dad_ampY],[ls2j_ryr_b2(:).dad_ampY],[ls2i_ryr_b2(:).dad_ampY],...
%       [WT_ryr_b3(:).dad_ampY],[ls2j_ryr_b3(:).dad_ampY],[ls2i_ryr_b3(:).dad_ampY],...
%       [WT_ryr_b4(:).dad_ampY],[ls2j_ryr_b4(:).dad_ampY],[ls2i_ryr_b4(:).dad_ampY],...
%       [WT_ryr_b5(:).dad_ampY],[ls2j_ryr_b5(:).dad_ampY],[ls2i_ryr_b5(:).dad_ampY],...
%       ]; 
% by = [zeros(length([WT_ryr_b1(:).dad_ampY]), 1);1*ones(length([ls2j_ryr_b1(:).dad_ampY]), 1);2*ones(length([ls2i_ryr_b1(:).dad_ampY]), 1);...
%       3*ones(length([WT_ryr_b2(:).dad_ampY]), 1);4*ones(length([ls2j_ryr_b2(:).dad_ampY]), 1);5*ones(length([ls2i_ryr_b2(:).dad_ampY]), 1);...
%       6*ones(length([WT_ryr_b3(:).dad_ampY]), 1);7*ones(length([ls2j_ryr_b3(:).dad_ampY]), 1);8*ones(length([ls2i_ryr_b3(:).dad_ampY]), 1);...
%       9*ones(length([WT_ryr_b4(:).dad_ampY]), 1);10*ones(length([ls2j_ryr_b4(:).dad_ampY]), 1);11*ones(length([ls2i_ryr_b4(:).dad_ampY]), 1);...
%       12*ones(length([WT_ryr_b5(:).dad_ampY]), 1);13*ones(length([ls2j_ryr_b5(:).dad_ampY]), 1);14*ones(length([ls2i_ryr_b5(:).dad_ampY]), 1);...
%       ];
%   
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',2:3:18)
% set(gca,'xticklabel',{'Beat 1','Beat 2','Beat 3','Beat 4','Beat 5'}) 
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'WT','J_{ls,up}=0','J_{ls,rel} = 0','Location','northwest','Orientation','horizontal');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'J_{RyR} DAD Amplitude (nM)'})
% title({'Fast Pacing and ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 1500 500])
% print(gcf, fullfile(pwd, 'bp_beat1_5_dadamp_ryr'),'-dtiff','-r300')
% close


% %% plot trace
% Y = [88,38,31,36,37];
% Yspace = {'Lysosome','Cytosol','SR','Junction','SL'};
% yaxis_lim = [4,3,5,5,3];
% for SP = 1: numel(Y)
% for ipeak = 1 : num    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(S3w(ipeak).t,S3w(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(S3wj(ipeak).t,S3wj(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(S3wi(ipeak).t,S3wi(ipeak).y(:,Y(SP)).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on 
% end    
%     linkaxes([ax2,ax4,ax6],'y');
%     yaxis = yaxis_lim(SP);
%     f60 = figure(60);
%     ax2 = subplot(1,1,1);
%     ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP == 1
%     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
%     else 
%     title({' ',' '});
%     end   
%     ax = gca;
%     ax.YAxis.Exponent = yaxis;
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
%     f61 = figure(61);
%     ax4 = subplot(1,1,1);
%     ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP ==1
%     title({'10Hz Fast Pacing and ISO, J_{ls,up} = 0',''});
%     else        
%     title({' ',' '})
%     end
% 
%     ax = gca;
%     ax.YAxis.Exponent = yaxis;
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
%     f62 = figure(62);
%     ax6= subplot(1,1,1);
%     ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
%     if SP ==1    
%     title({'10Hz Fast Pacing and ISO, J_{ls,rel} = 0',''});
%     else
%     title({' ',' '});
%     end
%     ax = gca;
%     ax.YAxis.Exponent = yaxis;
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
%     
% print(f60, fullfile(pwd, sprintf('swt_10hz %s',Yspace{SP})),'-dtiff','-r300');      
% print(f61, fullfile(pwd, sprintf('sjdot0_10hz %s',Yspace{SP})),'-dtiff','-r300');      
% print(f62, fullfile(pwd, sprintf('sidot0_10hz %s',Yspace{SP})),'-dtiff','-r300');      
% 
% close all    
%     
% end
%     
% %%            1        2     3       4         5     6       
% % currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i]; 
% Y = [1 2 3 4 5 6];
% Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}'};
% Yscale = [1 1 1e6 1e6 1e6 1e6]; 
% Yaxis = [1 -1 2 4 4 4];
% Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};
% 
% 
% for SP = 1: numel(Y)
% for idad = 1: numel(F3w)
%     
%     figure(1);ax1 = subplot(1,1,1);
%     p1 =plot(F3w(idad).tArray,F3w(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
%     figure(2);ax2 = subplot(1,1,1);
%     p2 =plot(F3wj(idad).tArray,F3wj(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
%     figure(3);ax3 = subplot(1,1,1);
%     p3 =plot(F3wi(idad).tArray,F3wi(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
% 
% end
% linkaxes([ax1,ax2,ax3],'y');
% fontsize = 35;
% 
% f1 = figure(1);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP == 7
% title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f1,'Units','pixels','Position',[0 0 700 500])
% print(f1, fullfile(pwd, sprintf('swt_10hz %s wt',Yspace{SP})),'-dtiff','-r300');
% 
% f2 = figure(2);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');  
% if SP == 7
% title({'10Hz Fast Pacing and ISO, J_{ls,up} = 0',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f2,'Units','pixels','Position',[0 0 700 500])
% print(f2, fullfile(pwd, sprintf('sjdot0_10hz %s jdot0',Yspace{SP})),'-dtiff','-r300');
% 
% f3 = figure(3);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP == 7
% title({'10Hz Fast Pacing and ISO, J_{ls,rel} = 0',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f3,'Units','pixels','Position',[0 0 700 500])
% print(f3, fullfile(pwd, sprintf('sidot0_10hz %s idot0',Yspace{SP})),'-dtiff','-r300');
% 
% close all
% end

%% 100 10/39 0
% X = categorical({'Beat1','Beat2','Beat3','Beat4'});
% % X = reordercats(X,{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'});
% %WT Beat1: 34/58, Beat2: 12/58, Beat3: 7/58, Beat4: 26/58
% %jdot0  Beat1: 8/58, Beat2: 1/58, Beat3: 2/58, Beat4: 2/58
% Y = [59 14 0;
%      21 2  0;
%      12 4  0;
%      45 4  0];
% b= bar(X,Y);
% % b(1).FaceColor = [0 0 1];
% % b(2).FaceColor = [1 0 1];
% % b(3).FaceColor = [1 0 0];
% % text(1:length(Y),Y,num2str(Y'),'vert','bottom','horiz','center'); 
% 
% ax = gca;
% ax. Position = [0.25 0.2 0.7 0.7];
% ylim([0 100])
% % ax.YAxis.Exponent = 5;
% legend('WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Percentage of Arrhythmic Models','in TPC-specific Category'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 840 600])
% print(gcf, fullfile(pwd, 'ba_hy'),'-dtiff','-r300')
% % close