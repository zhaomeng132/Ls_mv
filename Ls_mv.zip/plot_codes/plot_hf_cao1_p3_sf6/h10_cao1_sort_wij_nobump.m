clear all
close all

cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat

cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_arc_home
load y175_WT_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Sw = S(h1_cao1_sf1000_sf6_0);

load y175_i_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Si = S(h1_cao1_sf1000_sf6_0);


cd ~/downloads/SS/Ls_mv_sf6/h10_cao1_p3_local
load y175_j_dot0_herz10_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat 
Sj = S(h1_cao1_sf1000_sf6_0);

% rate1 = 1.3;

    
%% beat1
    peakrate = 1200  % 1000 modify 10.02.23
    bumprate = 0.16
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-1e3));
    Yw = Sw(ipeak).y(1:b1ind,38).*1e6;
    Tw = Sw(ipeak).t(1:b1ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-1e3));
    Yi = Si(ipeak).y(1:b1ind,38).*1e6;
    Ti = Si(ipeak).t(1:b1ind);    

    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h10_beat1_w_bump = find([Peak_wT1(:).bump]==1);
h10_beat1_i_bump = find([Peak_iT1(:).bump]==1);

%id 1-423
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));

% h10_beat1_w_nobump = lin423(find(ismember(lin423,h10_beat1_w_bump)~=1));
% h10_beat1_i_nobump = lin423(find(ismember(lin423,h10_beat1_i_bump)~=1));

h10_beat1_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h10_beat1_w_0 = find([Peak_wT1(:).peaknumel]<2);
h10_beat1_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h10_beat1_i_0 = find([Peak_iT1(:).peaknumel]<2);
% %nobump
% h10_beat1_w_1 = intersect(h10_beat1_w_1,h10_beat1_w_nobump);
% % h10_beat1_w_0 = intersect(h10_beat1_w_0,h10_beat1_w_nobump);
% h10_beat1_i_1 = intersect(h10_beat1_i_1,h10_beat1_i_nobump);
% % h10_beat1_i_0 = intersect(h10_beat1_i_0,h10_beat1_i_nobump);

% h10_beat1_w1i0 = intersect(h10_beat1_w_1,h10_beat1_i_0);
% h10_beat1_w1i1 = intersect(h10_beat1_w_1,h10_beat1_i_1);
% 
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat1_w_1.mat','h10_beat1_w_1');

% beat1_1 = h10_beat1_w1i0;
% 
% for ip = 1:numel(beat1_1)
%     
%     figure(1);subplot(2,1,1);
%     plot(Sw(beat1_1(ip)).t,Sw(beat1_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
%     subplot(2,1,2);
%     plot(Si(beat1_1(ip)).t,Si(beat1_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
% end
% f62 = figure(1);
% % ax6= subplot(1,1,1);
%     ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% % print(f62, fullfile(pwd, 'h50h1beat1_ca'),'-dpng','-r300');
% % close 
%% beat 2-5
    peakrate = 200
    bumprate = 0.16
    
% beat2
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-1e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-2e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-1e3));
    [~,b2ind] = min(abs(Si(ipeak).t-2e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h10_beat2_w_bump = find([Peak_wT1(:).bump]==1);
h10_beat2_i_bump = find([Peak_iT1(:).bump]==1);
 
% %id 1-423
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));
% 
% h10_beat2_w_nobump = lin423(find(ismember(lin423,h10_beat2_w_bump)~=1));
% h10_beat2_i_nobump = lin423(find(ismember(lin423,h10_beat2_i_bump)~=1));
 
h10_beat2_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h10_beat2_w_0 = find([Peak_wT1(:).peaknumel]<2);
h10_beat2_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h10_beat2_i_0 = find([Peak_iT1(:).peaknumel]<2);
% %nobump
% h10_beat2_w_1 = intersect(h10_beat2_w_1,h10_beat2_w_nobump);
% % h10_beat2_w_0 = intersect(h10_beat2_w_0,h10_beat2_w_nobump);
% h10_beat2_i_1 = intersect(h10_beat2_i_1,h10_beat2_i_nobump);
% % h10_beat2_i_0 = intersect(h10_beat2_i_0,h10_beat2_i_nobump);
%  
% h10_beat2_w1i0 = intersect(h10_beat2_w_1,h10_beat2_i_0);
% h10_beat2_w1i1 = intersect(h10_beat2_w_1,h10_beat2_i_1);
%  
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat2_w_1.mat','h10_beat2_w_1');
 
% beat2_1 = h10_beat2_w_0;
%  
% for ip = 1:numel(beat2_1)
%     
%     figure(1);subplot(2,1,1);
%     plot(Sw(beat2_1(ip)).t,Sw(beat2_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
%     subplot(2,1,2);
%     plot(Si(beat2_1(ip)).t,Si(beat2_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
% end
% f62 = figure(1);
% % ax6= subplot(1,1,1);
%     ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% % print(f62, fullfile(pwd, 'h50h1beat2_ca'),'-dpng','-r300');
% % close 
%% beat3
close all  
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-2e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-3e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-2e3));
    [~,b2ind] = min(abs(Si(ipeak).t-3e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h10_beat3_w_bump = find([Peak_wT1(:).bump]==1);
h10_beat3_i_bump = find([Peak_iT1(:).bump]==1);
 
% %id 1-423
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));
% 
% h10_beat3_w_nobump = lin423(find(ismember(lin423,h10_beat3_w_bump)~=1));
% h10_beat3_i_nobump = lin423(find(ismember(lin423,h10_beat3_i_bump)~=1));
 
h10_beat3_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h10_beat3_w_0 = find([Peak_wT1(:).peaknumel]<2);
h10_beat3_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h10_beat3_i_0 = find([Peak_iT1(:).peaknumel]<2);
% %nobump
% h10_beat3_w_1 = intersect(h10_beat3_w_1,h10_beat3_w_nobump);
% % h10_beat3_w_0 = intersect(h10_beat3_w_0,h10_beat3_w_nobump);
% h10_beat3_i_1 = intersect(h10_beat3_i_1,h10_beat3_i_nobump);
% % h10_beat3_i_0 = intersect(h10_beat3_i_0,h10_beat3_i_nobump);
%  
% h10_beat3_w1i0 = intersect(h10_beat3_w_1,h10_beat3_i_0);
% h10_beat3_w1i1 = intersect(h10_beat3_w_1,h10_beat3_i_1);
%  
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat3_w_1.mat','h10_beat3_w_1');
  
 
% beat3_1 = h10_beat3_w_0;
%  
% for ip = 1:numel(beat3_1)
%     
%     figure(1);subplot(2,1,1);
%     plot(Sw(beat3_1(ip)).t,Sw(beat3_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
%     subplot(2,1,2);
%     plot(Si(beat3_1(ip)).t,Si(beat3_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
% end
% f62 = figure(1);
% % ax6= subplot(1,1,1);
%     ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% % print(f62, fullfile(pwd, 'h50h1beat3_ca'),'-dpng','-r300');
% % close 
%% beat4
close all
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-3e3));
    [~,b2ind] = min(abs(Sw(ipeak).t-4e3));
    Yw = Sw(ipeak).y(b1ind:b2ind,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:b2ind);
    
    [~,b1ind] = min(abs(Si(ipeak).t-3e3));
    [~,b2ind] = min(abs(Si(ipeak).t-4e3));
    Yi = Si(ipeak).y(b1ind:b2ind,38).*1e6;
    Ti = Si(ipeak).t(b1ind:b2ind);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h10_beat4_w_bump = find([Peak_wT1(:).bump]==1);
h10_beat4_i_bump = find([Peak_iT1(:).bump]==1);
 
% %id 1-423
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));
% 
% h10_beat4_w_nobump = lin423(find(ismember(lin423,h10_beat4_w_bump)~=1));
% h10_beat4_i_nobump = lin423(find(ismember(lin423,h10_beat4_i_bump)~=1));
 
h10_beat4_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h10_beat4_w_0 = find([Peak_wT1(:).peaknumel]<2);
h10_beat4_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h10_beat4_i_0 = find([Peak_iT1(:).peaknumel]<2);
% %nobump
% h10_beat4_w_1 = intersect(h10_beat4_w_1,h10_beat4_w_nobump);
% % h10_beat4_w_0 = intersect(h10_beat4_w_0,h10_beat4_w_nobump);
% h10_beat4_i_1 = intersect(h10_beat4_i_1,h10_beat4_i_nobump);
% % h10_beat4_i_0 = intersect(h10_beat4_i_0,h10_beat4_i_nobump);
%  
% h10_beat4_w1i0 = intersect(h10_beat4_w_1,h10_beat4_i_0);
% h10_beat4_w1i1 = intersect(h10_beat4_w_1,h10_beat4_i_1);
%  
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat4_w_1.mat','h10_beat4_w_1');
   
 
% beat4_1 = h10_beat4_w_0;
%  
% for ip = 1:numel(beat4_1)
%     
%     figure(1);subplot(2,1,1);
%     plot(Sw(beat4_1(ip)).t,Sw(beat4_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
%     subplot(2,1,2);
%     plot(Si(beat4_1(ip)).t,Si(beat4_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
% end
% f62 = figure(1);
% % ax6= subplot(1,1,1);
%     ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% % print(f62, fullfile(pwd, 'h50h1beat4_ca'),'-dpng','-r300');
% % close 
%% beat5
close all    
for ipeak = 1: numel(Sw)
    [~,b1ind] = min(abs(Sw(ipeak).t-4e3));
    Yw = Sw(ipeak).y(b1ind:end,38).*1e6;
    Tw = Sw(ipeak).t(b1ind:end);
    
    [~,b1ind] = min(abs(Si(ipeak).t-4e3));
    Yi = Si(ipeak).y(b1ind:end,38).*1e6;
    Ti = Si(ipeak).t(b1ind:end);    
 
%     peakrate = 1000;
%     bumprate = 0.16;
    Peak_wT1(ipeak) = ca_peak_nobump(Tw,Yw,peakrate,bumprate);
    Peak_iT1(ipeak) = ca_peak_nobump(Ti,Yi,peakrate,bumprate);
end
h10_beat5_w_bump = find([Peak_wT1(:).bump]==1);
h10_beat5_i_bump = find([Peak_iT1(:).bump]==1);
 
% %id 1-423
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));
% 
% h10_beat5_w_nobump = lin423(find(ismember(lin423,h10_beat5_w_bump)~=1));
% h10_beat5_i_nobump = lin423(find(ismember(lin423,h10_beat5_i_bump)~=1));
 
h10_beat5_w_1 = find([Peak_wT1(:).peaknumel]>=2);
h10_beat5_w_0 = find([Peak_wT1(:).peaknumel]<2);
h10_beat5_i_1 = find([Peak_iT1(:).peaknumel]>=2);
h10_beat5_i_0 = find([Peak_iT1(:).peaknumel]<2);
% %nobump
% h10_beat5_w_1 = intersect(h10_beat5_w_1,h10_beat5_w_nobump);
% % h10_beat5_w_0 = intersect(h10_beat5_w_0,h10_beat5_w_nobump);
% h10_beat5_i_1 = intersect(h10_beat5_i_1,h10_beat5_i_nobump);
% % h10_beat5_i_0 = intersect(h10_beat5_i_0,h10_beat5_i_nobump);
%  
% h10_beat5_w1i0 = intersect(h10_beat5_w_1,h10_beat5_i_0);
% h10_beat5_w1i1 = intersect(h10_beat5_w_1,h10_beat5_i_1);
%  
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat5_w_1.mat','h10_beat5_w_1'); 
 
% beat5_1 = h10_beat5_w_0;
%  
% for ip = 1:numel(beat5_1)
%     
%     figure(1);subplot(2,1,1);
%     plot(Sw(beat5_1(ip)).t,Sw(beat5_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
%     subplot(2,1,2);
%     plot(Si(beat5_1(ip)).t,Si(beat5_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
% end
% f62 = figure(1);
% % ax6= subplot(1,1,1);
%     ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% % print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% % close 
%%
bump_w = unique([h10_beat1_w_bump,...
              h10_beat2_w_bump,...
              h10_beat3_w_bump,...
              h10_beat4_w_bump,...
              h10_beat5_w_bump]);

bump_o = unique([h10_beat1_i_bump,...
              h10_beat2_i_bump,...
              h10_beat3_i_bump,...
              h10_beat4_i_bump,...
              h10_beat5_i_bump]);
          
h10_w_1 = unique([h10_beat1_w_1, h10_beat2_w_1, h10_beat3_w_1,h10_beat4_w_1, h10_beat5_w_1]);
%no bump, excluding indexes with bump
h10_w_1_bump_w_intersect = intersect(h10_w_1,bump_w);
h10_w_1 = h10_w_1(find(ismember(h10_w_1,h10_w_1_bump_w_intersect)~=1));

h10_w_0 = intersect(intersect(intersect(intersect(h10_beat1_w_0, h10_beat2_w_0), h10_beat3_w_0),h10_beat4_w_0), h10_beat5_w_0);  

h10_i_1 = unique([h10_beat1_i_1, h10_beat2_i_1, h10_beat3_i_1,h10_beat4_i_1, h10_beat5_i_1]);  
%no bump, excluding indexes with bump
h10_i_1_bump_o_intersect = intersect(h10_i_1,bump_o);
h10_i_1 = h10_i_1(find(ismember(h10_i_1,h10_i_1_bump_o_intersect)~=1));

h10_i_0 = intersect(intersect(intersect(intersect(h10_beat1_i_0, h10_beat2_i_0), h10_beat3_i_0),h10_beat4_i_0), h10_beat5_i_0);  
  
% 1
h10_iTPC1 = intersect(h10_w_1,h10_i_0);
cd ~/downloads/SS/Ls_mv_sf6
save('h10_iTPC1.mat','h10_iTPC1');

% 2
h10_inoneTPC1 = intersect(h10_w_1,h10_i_1);
save('h10_inoneTPC1.mat','h10_inoneTPC1');

% 3
h10_inone_0= intersect(h10_w_0,h10_i_0);
save('h10_inone_0.mat','h10_inone_0');

% 4
h10_w0i1 = intersect(h10_w_0,h10_i_1);
%% check total
% lin423 = linspace(1,numel(h1_cao1_sf1000_sf6_0),numel(h1_cao1_sf1000_sf6_0));
% 
% tot = sort([h10_iTPC1, h10_inoneTPC1, h10_inone_0]);
% 
% rest = lin423(find(ismember(lin423,tot)~=1))          
          
numel(unique([bump_w,bump_o]))+numel(h10_iTPC1)+numel(h10_inoneTPC1)+numel(h10_inone_0)+numel(h10_w0i1)          
          
%% plot wt, idot0
beat5_1 = unique([bump_w,bump_o])
 
for ip = 1:numel(beat5_1)
    
    figure(1);subplot(2,1,1);
    plot(Sw(beat5_1(ip)).t,Sw(beat5_1(ip)).y(:,38).*1e6,'Color','#000000'); hold on
    subplot(2,1,2);
    plot(Si(beat5_1(ip)).t,Si(beat5_1(ip)).y(:,38).*1e6,'Color','#FF0000'); hold on
end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% close 
%% jdot0 id 1 343
% beat1
for ipeak = 1: numel(h10_iTPC1)
    [~,b1ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-1e3));
    Yj = Sj(h10_iTPC1(ipeak)).y(1:b1ind,38).*1e6;
    Tj = Sj(h10_iTPC1(ipeak)).t(1:b1ind);  
    Peak_jT1(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h10_beat1_j_bump = find([Peak_jT1(:).bump]==1);

% %id 1-h10_iTPC1
% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_beat1_j_nobump = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_beat1_j_bump)~=1));

h10_beat1_j_1 = find([Peak_jT1(:).peaknumel]>=2);
h10_beat1_j_0 = find([Peak_jT1(:).peaknumel]<2);

% h10_beat1_j_1 = intersect(h10_beat1_j_1,h10_beat1_j_nobump);
% h10_beat1_j_0 = intersect(h10_beat1_j_0,h10_beat1_j_nobump);
% 
% h10_beat1_423_j_1 = h10_iTPC1(h10_beat1_j_1);
% h10_beat1_423_j_0 = h10_iTPC1(h10_beat1_j_0);
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat1_423_j_1.mat','h10_beat1_423_j_1'); 
% save('h10_beat1_423_j_0.mat','h10_beat1_423_j_0'); 

% beat2 
for ipeak = 1: numel(h10_iTPC1)
    [~,b1ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-1e3));
    [~,b2ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-2e3));
    Yj = Sj(h10_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h10_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT2(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h10_beat2_j_bump = find([Peak_jT2(:).bump]==1);
 
% %id 1-h10_iTPC1
% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_beat2_j_nobump = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_beat2_j_bump)~=1));
 
h10_beat2_j_1 = find([Peak_jT2(:).peaknumel]>=2);
h10_beat2_j_0 = find([Peak_jT2(:).peaknumel]<2);
 
% h10_beat2_j_1 = intersect(h10_beat2_j_1,h10_beat2_j_nobump);
% h10_beat2_j_0 = intersect(h10_beat2_j_0,h10_beat2_j_nobump);
% 
% h10_beat2_423_j_1 = h10_iTPC1(h10_beat2_j_1);
% h10_beat2_423_j_0 = h10_iTPC1(h10_beat2_j_0);
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat2_423_j_1.mat','h10_beat2_423_j_1');
% save('h10_beat2_423_j_0.mat','h10_beat2_423_j_0');

% beat3
for ipeak = 1: numel(h10_iTPC1)
    [~,b1ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-2e3));
    [~,b2ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-3e3));
    Yj = Sj(h10_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h10_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT3(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h10_beat3_j_bump = find([Peak_jT3(:).bump]==1);
 
% %id 1-h10_iTPC1
% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_beat3_j_nobump = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_beat3_j_bump)~=1));
 
h10_beat3_j_1 = find([Peak_jT3(:).peaknumel]>=2);
h10_beat3_j_0 = find([Peak_jT3(:).peaknumel]<2);
 
% h10_beat3_j_1 = intersect(h10_beat3_j_1,h10_beat3_j_nobump);
% h10_beat3_j_0 = intersect(h10_beat3_j_0,h10_beat3_j_nobump);
% 
% h10_beat3_423_j_1 = h10_iTPC1(h10_beat3_j_1);
% h10_beat3_423_j_0 = h10_iTPC1(h10_beat3_j_0);
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat3_423_j_1.mat','h10_beat3_423_j_1'); 
% save('h10_beat3_423_j_0.mat','h10_beat3_423_j_0'); 

% beat 4
for ipeak = 1: numel(h10_iTPC1)
    [~,b1ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-3e3));
    [~,b2ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-4e3));
    Yj = Sj(h10_iTPC1(ipeak)).y(b1ind:b2ind,38).*1e6;
    Tj = Sj(h10_iTPC1(ipeak)).t(b1ind:b2ind);  
    Peak_jT4(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h10_beat4_j_bump = find([Peak_jT4(:).bump]==1);
 
% %id 1-h10_iTPC1
% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_beat4_j_nobump = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_beat4_j_bump)~=1));
 
h10_beat4_j_1 = find([Peak_jT4(:).peaknumel]>=2);
h10_beat4_j_0 = find([Peak_jT4(:).peaknumel]<2);
 
% h10_beat4_j_1 = intersect(h10_beat4_j_1,h10_beat4_j_nobump);
% h10_beat4_j_0 = intersect(h10_beat4_j_0,h10_beat4_j_nobump);
% 
% h10_beat4_423_j_1 = h10_iTPC1(h10_beat4_j_1);
% h10_beat4_423_j_0 = h10_iTPC1(h10_beat4_j_0);
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat4_423_j_1.mat','h10_beat4_423_j_1'); 
% save('h10_beat4_423_j_0.mat','h10_beat4_423_j_0'); 

% beat5
for ipeak = 1: numel(h10_iTPC1)
    [~,b1ind] = min(abs(Sj(h10_iTPC1(ipeak)).t-4e3));
    Yj = Sj(h10_iTPC1(ipeak)).y(b1ind:end,38).*1e6;
    Tj = Sj(h10_iTPC1(ipeak)).t(b1ind:end);  
    Peak_jT5(ipeak) = ca_peak_nobump(Tj,Yj,peakrate,bumprate);
end
h10_beat5_j_bump = find([Peak_jT5(:).bump]==1);
 
% %id 1-h10_iTPC1
% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_beat5_j_nobump = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_beat5_j_bump)~=1));
 
h10_beat5_j_1 = find([Peak_jT5(:).peaknumel]>=2);
h10_beat5_j_0 = find([Peak_jT5(:).peaknumel]<2);
 
% h10_beat5_j_1 = intersect(h10_beat5_j_1,h10_beat5_j_nobump);
% h10_beat5_j_0 = intersect(h10_beat5_j_0,h10_beat5_j_nobump);
% 
% h10_beat5_423_j_1 = h10_iTPC1(h10_beat5_j_1);
% h10_beat5_423_j_0 = h10_iTPC1(h10_beat5_j_0);
% cd ~/downloads/SS/Ls_mv_sf6
% save('h10_beat5_423_j_1.mat','h10_beat5_423_j_1'); 
% save('h10_beat5_423_j_0.mat','h10_beat5_423_j_0'); 

%%
bump_h10_iTPC1_j = unique([h10_beat1_j_bump,...
              h10_beat2_j_bump,...
              h10_beat3_j_bump,...
              h10_beat4_j_bump,...
              h10_beat5_j_bump]);
          
h10_j_0 = intersect(intersect(intersect(intersect(h10_beat1_j_0, h10_beat2_j_0), h10_beat3_j_0),h10_beat4_j_0), h10_beat5_j_0);  

h10_j_1 = unique([h10_beat1_j_1, h10_beat2_j_1, h10_beat3_j_1,h10_beat4_j_1, h10_beat5_j_1]);
%no bump, excluding indexes with bump
h10_j_1_bump_h10_iTPC1_j_intersect = intersect(h10_j_1,bump_h10_iTPC1_j);

h10_j_1 = h10_j_1(find(ismember(h10_j_1,h10_j_1_bump_h10_iTPC1_j_intersect)~=1));


% lin_h10_iTPC1 = linspace(1,numel(h10_iTPC1),numel(h10_iTPC1));
% h10_j_1_copy = lin_h10_iTPC1(find(ismember(lin_h10_iTPC1,h10_j_0)~=1)); 

h10_iTPC1_jdot_0_beat1_5 = h10_j_0;
h10_iTPC1_jdot_1_beat1_5 = h10_j_1;
cd ~/downloads/SS/Ls_mv_sf6
save('h10_iTPC1_jdot_0_beat1_5.mat','h10_iTPC1_jdot_0_beat1_5');
save('h10_iTPC1_jdot_1_beat1_5.mat','h10_iTPC1_jdot_1_beat1_5');
%% plot jdot0
close all
beat5_1 = h10_j_0;
for ip = 1:numel(beat5_1)
    
    figure(1);
    plot(Sj(h10_iTPC1(beat5_1(ip))).t,Sj(h10_iTPC1(beat5_1(ip))).y(:,38).*1e6,'Color','#0000FF'); hold on

end
f62 = figure(1);
% ax6= subplot(1,1,1);
    ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); title('ISO');
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',30)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',1);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
% print(f62, fullfile(pwd, 'h50h1beat5_ca'),'-dpng','-r300');
% close 
%%
iTPC_per_j2 = intersect(h10_beat2_j_1,h10_iTPC1);
iTPC_per_j3 = intersect(h10_beat3_j_1,h10_iTPC1);
iTPC_per_j4 = intersect(h10_beat4_j_1,h10_iTPC1);
iTPC_per_j5 = intersect(h10_beat5_j_1,h10_iTPC1);
%%
function Peak = ca_peak_nobump(T,Y,peakrate,bumprate)
    rate1 = 1.25;
    [TF,~] = islocalmax(Y,'MinProminence',max(Y)/peakrate);
    id = find(TF); 
    if abs(Y(end)) > min(abs(Y))*rate1
    TF(end) = 1;
    end 
    Peak.peaknumel =numel(find(TF));
    
    if numel(id) == 2 && (Y(id(2)) - min(Y))/(max(Y) - min(Y)) < bumprate && T(id(2)) < 500 +T(1)
%     Peak.bump_w_ratio = (Y(id(2)) - min(Y))/(max(Y) - min(Y));
    Peak.bump = 1; 
    else
%     Peak.bump_w_amplist = 0;
    Peak.bump = 0;     
    end

end