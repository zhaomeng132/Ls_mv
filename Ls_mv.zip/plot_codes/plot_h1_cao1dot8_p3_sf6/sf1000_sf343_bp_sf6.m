clear all
close all
addpath('~/downloads/SS/Ls_mv_sf6/plot_h1_cao1dot8_p3_sf6')
% load SS
cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat

cd ~/downloads/SS/Ls_mv_sf6/
load cao1dot8_iTPC_1.mat
iTPC_1 = cao1dot8_iTPC_1;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S = S(iTPC_1);
Swt = S;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S = S(iTPC_1);
Sjdot0 = S;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S = S(iTPC_1);
Sidot0 = S; 

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_herz1_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
F = F(iTPC_1);
Fwt = F;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_j_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
F = F(iTPC_1);
Fjdot0 = F;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_i_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
F = F(iTPC_1);
Fidot0 = F;

cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','fig56'])
cd(['./','fig56'])

%% CTRL TPC2KO
Y = [38,31,36,88,37,15];
Yspace = {'Cytosol','SR','Junction','Lysosome','Sarcolemma','Open Probability'};
Yscale = [1e6,1e6,1e6,1e6,1e6,1];
yaxis_lim = [2,4,5,4,3,0];

% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 10;

for SP = 1 : numel(Y)
for idad = id_median: id_median%numel(Sw_w1i0)
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(idad).t,Swt(idad).y(:,Y(SP)).*Yscale(SP),'b'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Sidot0(idad).t,Sidot0(idad).y(:,Y(SP)).*Yscale(SP),'m'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
end    
    fontsize = 40;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 2
    legend('WT','J_{ls,rel} = 0','Location', 'southeast');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    elseif SP == 6
    legend('WT','J_{ls,rel} = 0','Non-pro-arrhythmic','Location', 'northeast');legend boxoff
%     ylim([0 1.1])
    ylabel(sprintf('%s',Yspace{SP}));xlabel('Time (ms)');
    else
    legend('WT','J_{ls,rel} = 0','Location', 'northeast');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    end
 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[0 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i0_wt_ko',Y(SP))),'-dtiff','-r300');

close all
end

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
Y = [1 2 3 4 5 6 9 27];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{CaL}','J_RyR Leak'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1 1e6]; 
Yaxis = [1 -1 2 4 4 3 1 0];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{CaL} (pA/pF)','J_{RyR Leak} (nM/ms)'};

% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 10;
for SP = 3:4%numel(Y)
for idad = id_median: id_median%numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt(idad).tArray,Fwt(idad).currents(:,Y(SP)).*Yscale(SP),'b');
    hold on
    p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,Y(SP)).*Yscale(SP),'m');    

end

fontsize = 40;

f1 = figure(1);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');       
if SP ==7
title({'Hypercalcemia and ISO, WT_{ }',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               if SP == 1 | SP == 2 | SP==5 | SP==7 | SP==8
               legend('WT','J_{ls,rel} = 0','Location', 'southeast');legend boxoff
               else
               legend('WT','J_{ls,rel} = 0','Location', 'northeast');legend boxoff
               end
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('w1i0_wt_ko %s',Yspace{SP})),'-dtiff','-r300');

close all
end

%% CTRL TPC2KO
Y = [38,31,36,88,37,39];
Yspace = {'Cytosol','SR','Junction','Lysosome','Sarcolemma','Action Potential'};
Yscale = [1e6,1e6,1e6,1e6,1e6,1];
yaxis_lim = [2,5,5,4,3,0];

for SP = 1 : numel(Y)
for idad = 1: 1%numel(Sw_w1i0)
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(idad).t,Swt(idad).y(:,Y(SP)).*Yscale(SP),'k'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Sidot0(idad).t,Sidot0(idad).y(:,Y(SP)).*Yscale(SP),'r'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
end    
    fontsize = 40;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 2
    legend('CTRL','TPC2-KO','Location', 'southeast');legend boxoff
    else
    legend('CTRL','TPC2-KO','Location', 'northeast');legend boxoff
    end
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)'); 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[1000 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i0_id1',Y(SP))),'-dtiff','-r300');

close all
end

%%
Y = [14,15,16, 0];
Yspace = {'R', 'O', 'I', 'RI'};
Yscale = [1, 1, 1, 1];
yaxis_lim = [0, 0, 0, 0];

for SP = 1 : numel(Y)
for idad = 1: 1%numel(Sw_w1i0)
    
    if SP==4
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(idad).t,(1-Swt(idad).y(:,14)-Swt(idad).y(:,15)-Swt(idad).y(:,16)).*Yscale(SP),'k'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Sidot0(idad).t,1-Sidot0(idad).y(:,14)-Sidot0(idad).y(:,15)-Sidot0(idad).y(:,16).*Yscale(SP),'r'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
    else
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(idad).t,Swt(idad).y(:,Y(SP)).*Yscale(SP),'k'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Sidot0(idad).t,Sidot0(idad).y(:,Y(SP)).*Yscale(SP),'r'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on
    end
end    
    fontsize = 35;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 2
    legend('CTRL','TPC2-KO','Location', 'northeast');legend boxoff
    elseif SP == 1
    legend('CTRL','TPC2-KO','Location', 'south');legend boxoff
    elseif SP == 3
    legend('CTRL','TPC2-KO','Location', 'northeast');legend boxoff    
    else
    legend('CTRL','TPC2-KO','Location', 'north');legend boxoff
    end
    ylabel(sprintf('%s',Yspace{SP}));xlabel('Time (ms)'); 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[1000 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i0_ryr_id1',Y(SP))),'-dtiff','-r300');

close all
end
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
Y = [1 2 3 4 5 6 9 27];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{CaL}','J_RyR Leak'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1 1e6]; 
Yaxis = [1 -1 2 4 4 3 1 0];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{CaL} (pA/pF)','J_{RyR Leak} (nM/ms)'};

for SP = 8:8%numel(Y)
for idad = 1: 1%numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt(idad).tArray,Fwt(idad).currents(:,Y(SP)).*Yscale(SP),'k');
    hold on
    p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,Y(SP)).*Yscale(SP),'r');    

end

fontsize = 35;

f1 = figure(1);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');       
if SP ==7
title({'Hypercalcemia and ISO, WT_{ }',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               if SP == 1 | SP == 2 | SP==5 | SP==7 | SP==8
               legend('CTRL','TPC2-KO','Location', 'southeast');legend boxoff
               else
               legend('CTRL','TPC2-KO','Location', 'northeast');legend boxoff
               end
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('w1i0_id1 %s',Yspace{SP})),'-dtiff','-r300');

close all
end
%% plot y39 non-TPC-specific
% cd ~/downloads/SS/Ls_mv_sf6
% load h1_cao1_sf1000_sf6_0.mat
% 
% cd ~/downloads/SS/Ls_mv_sf6/
% load cao1dot8_inoneTPC_1.mat
% inoneTPC_1 = cao1dot8_inoneTPC_1;
% 
% cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
% load y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
% S = S(h1_cao1_sf1000_sf6_0);
% S = S(inoneTPC_1);
% Swt = S;
% 
% cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
% load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
% S = S(h1_cao1_sf1000_sf6_0);
% S = S(inoneTPC_1);
% Sjdot0 = S;
% 
% cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
% load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
% S = S(h1_cao1_sf1000_sf6_0);
% S = S(inoneTPC_1);
% Sidot0 = S; 
% 
% cd ~/downloads/SS/Ls_mv_sf6
% mkdir(['./','fig56'])
% cd(['./','fig56'])
% 
% for ipeak = 1: numel(Swt)    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,39),'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,39),'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,39),'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on               
% end
%     
% linkaxes([ax2,ax4,ax6],'y');
% % linkaxes([ax2,ax6],'y');
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('Action Potential (mV)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, WT_{ }','non-TPC-specific'});  
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
% f61 = figure(61);
% ax4 = subplot(1,1,1);ylabel('Action Potential (mV)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, J_{ls,up} = 0','non-TPC-specific'});
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
% f62 = figure(62);
% ax6= subplot(1,1,1);ylabel('Action Potential (mV)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, J_{ls,rel} = 0','non-TPC-specific'});
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% 
% print(f60, fullfile(pwd, 'swt_y39_inoneTPC_1'),'-dtiff','-r300');
% print(f61, fullfile(pwd, 'Sjdot0_y39_inoneTPC_1'),'-dtiff','-r300');
% print(f62, fullfile(pwd, 'Sidot0_y39_inoneTPC_1'),'-dtiff','-r300');
% 
% close all    

%% plot y39 TPC-specific
for ipeak = 1: numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,39),'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,39),'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,39),'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
% linkaxes([ax2,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);ylabel('M.P. (mV)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, WT_{ }','TPC-specific'});  
    legend('WT_{ }','location','northeast'); legend boxoff 
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);ylabel('M.P. (mV)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, J_{ls,up} = 0','TPC-specific'});
    legend('J_{ls,up} = 0','location','northeast'); legend boxoff 
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',40);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);ylabel('M.P. (mV)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, J_{ls,rel} = 0','TPC-specific'});
    legend('J_{ls,rel} = 0','location','northeast'); legend boxoff  
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_y39_iTPC_1'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y39_iTPC_1'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y39_iTPC_1'),'-dtiff','-r300');

close all    

%% plot y38
for ipeak = 1:numel(Swt)   %7

    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,38).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,38).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,38).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on 
end

linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, WT_{}',''});
title({' ',' '})
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
title({' ',' '})
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
title({' ',' '})
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])
      
print(f60, fullfile(pwd, 'swt_y38'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y38'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y38'),'-dtiff','-r300');

close all    

%%
% for ipeak = 1: 1%numel(Swt)  
%     x = Swt(ipeak).t;
%     y = Swt(ipeak).y(:,31);
%     k = boundary(x,y);
%     
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(x(k),y(k).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on 
% end
% close all

%% plot y14
for ipeak = 1: 1%numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,15),'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,15),'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,15),'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);ylabel('O');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, WT_{ }',' '});  
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);ylabel('O');xlabel('Time (ms)'); 
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);ylabel('O');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_y15'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y15'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y15'),'-dtiff','-r300');

close all    

%% plot RI
for ipeak = 1: 1%numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,1-Swt(ipeak).y(:,14)-Swt(ipeak).y(:,15)-Swt(ipeak).y(:,16),'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,1-Sjdot0(ipeak).y(:,14)-Sjdot0(ipeak).y(:,15)-Sjdot0(ipeak).y(:,16),'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,1-Sidot0(ipeak).y(:,14)-Sidot0(ipeak).y(:,15)-Sidot0(ipeak).y(:,16),'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);ylabel('RI');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, WT_{ }',' '});  
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);ylabel('RI');xlabel('Time (ms)'); 
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);ylabel('RI');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_ri'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_ri'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_ri'),'-dtiff','-r300');

close all    
%% plot y88
for ipeak = 1: numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,88).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,88).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,88).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, WT_{ }',' '});  
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)'); 
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',40);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)');
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',40)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_y88'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y88'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y88'),'-dtiff','-r300');

close all    

%% plot y31
for ipeak = 1:1%numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,31).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,31).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,31).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);
    ylabel('[Ca] SR (nM)');xlabel('Time (ms)'); 
%     title({'Hypercalcemia and ISO, CTRL',''});  
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);

    ylabel('[Ca] SR (nM)');xlabel('Time (ms)'); 
%     title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);
    ylabel('[Ca] SR (nM)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_y31'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y31'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y31'),'-dtiff','-r300');

close all   

%% plot y36
for ipeak = 1: 1%numel(Swt)    
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,36).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    figure(61)
    ax4 = subplot(1,1,1);
    p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,36).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
    hold on
    figure(62)
    ax6 = subplot(1,1,1);
    p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,36).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on               
end
    
linkaxes([ax2,ax4,ax6],'y');
f60 = figure(60);
ax2 = subplot(1,1,1);
    ylabel('[Ca] Junction (nM)');xlabel('Time (ms)'); 
%     title({'Hypercalcemia and ISO, CTRL',''});  
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(61);
ax4 = subplot(1,1,1);

    ylabel('[Ca] Junction (nM)');xlabel('Time (ms)'); 
%     title({'Hypercalcemia and ISO, J_{ls2j}=0',''});
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

f62 = figure(62);
ax6= subplot(1,1,1);
    ylabel('[Ca] Junction (nM)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
    set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f62,'type','axes'),'box','off')
    set(f62,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'swt_y36'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'Sjdot0_y36'),'-dtiff','-r300');
print(f62, fullfile(pwd, 'Sidot0_y36'),'-dtiff','-r300');

close all   

%% biomarkers for Swt, Sjdot0, Sidot0

for ipeak = 1: numel(Swt) 

t3w = Swt(ipeak).t;
y3w = Swt(ipeak).y.*1e6;

% biomarkers for Swt
owt_y38(ipeak) = peakfinder(t3w, y3w(:,38),200,200);
owt_y88(ipeak) = peakfinder(t3w, y3w(:,88),200,200);
% owt_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
owt_y36(ipeak) = peakfinder(t3w, y3w(:,36),200,200);
owt_y37(ipeak) = peakfinder(t3w, y3w(:,37),200,200);

owt_y31_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,31),200,200, y3w(:,36));
owt_y30_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,30),200,200, y3w(:,36));
% figure(1)
% plot(t3w, y3w(:,31));hold on
% plot(t3w(owt_y31_y36(ipeak).valleyI), y3w(owt_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
end


for ipeak = 1: numel(Sjdot0) 

t3w = Sjdot0(ipeak).t;
y3w = Sjdot0(ipeak).y.*1e6;

% biomarkers for Sjdot0
jdot0_y38(ipeak) = peakfinder(t3w, y3w(:,38),200,200);
jdot0_y88(ipeak) = peakfinder(t3w, y3w(:,88),200,200);
% jdot0_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
jdot0_y36(ipeak) = peakfinder(t3w, y3w(:,36),200,200);
jdot0_y37(ipeak) = peakfinder(t3w, y3w(:,37),200,200);

jdot0_y31_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,31),200,200, y3w(:,36));
jdot0_y30_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,30),200,200, y3w(:,36));

% figure(2)
% plot(t3w, y3w(:,31));hold on
% plot(t3w(jdot0_y31_y36(ipeak).valleyI), y3w(jdot0_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
end


for ipeak = 1: numel(Sidot0) 

t3w = Sidot0(ipeak).t;
y3w = Sidot0(ipeak).y.*1e6;

% biomarkers for Sidot0 
idot0_y38(ipeak) = peakfinder(t3w, y3w(:,38),200,200);
idot0_y88(ipeak) = peakfinder(t3w, y3w(:,88),200,200);
% idot0_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
idot0_y36(ipeak) = peakfinder(t3w, y3w(:,36),200,200);
idot0_y37(ipeak) = peakfinder(t3w, y3w(:,37),200,200);

idot0_y31_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,31),200,200, y3w(:,36));
idot0_y30_y36(ipeak) = y31_y36_peakfinder(t3w, y3w(:,30),200,200, y3w(:,36));

% figure(3)
% plot(t3w, y3w(:,31));hold on
% plot(t3w(idot0_y31_y36(ipeak).valleyI), y3w(idot0_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
end

%% S3w y31
close all
for ipeak = 1:1%numel(Swt)   
    
t1_1 = Swt(ipeak).t;
y31= Swt(ipeak).y(:,31).*1e6;


figure(1)    
plot(t1_1,y31,'r');hold on
% plot(t1_1,Swt(ipeak).y(:,30).*1e6,'k');
% plot(t1_1(owt_y31_y36(ipeak).valleyI),y31(owt_y31_y36(ipeak).valleyI),'r.','markersize',30); 

end

% yaxis = yaxis_lim(SP);
    f1 = figure(1);
    ax2 = subplot(1,1,1);
    ylabel(sprintf('[Ca] SR (nM)'));xlabel('Time (ms)'); 
%     if SP == 1
%     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
%     else 
%     title({' ',' '});
%     end   
%     xlim([0 5000])
%     ylim([0 12e5])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 5;
    set(findobj(f1,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f1, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f1,'type','axes'),'box','off')
    set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('iTPC_wt_10hz_id1_y30')),'-dtiff','-r300');
%% S3wj y31
close
for ipeak = 1:1%numel(Sjdot0)   
    
t1_1 = Sjdot0(ipeak).t;
y31= Sjdot0(ipeak).y(:,31).*1e6;

figure(2)    
plot(t1_1,y31,'r');hold on
plot(t1_1,Sjdot0(ipeak).y(:,30).*1e6,'k');
% plot(t1_1(jdot0_y31_y36(ipeak).valleyI),y31(jdot0_y31_y36(ipeak).valleyI),'r.','markersize',30); 

end

% yaxis = yaxis_lim(SP);
    f1 = figure(2);
    ax2 = subplot(1,1,1);
    ylabel(sprintf('[Ca] SR (nM)'));xlabel('Time (ms)'); 
%     if SP == 1
%     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
%     else 
%     title({' ',' '});
%     end   
%     xlim([0 5000])
    ylim([0 12e5])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 5;
    set(findobj(f1,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f1, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f1,'type','axes'),'box','off')
    set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('iTPC_jdot0_10hz_id1')),'-dtiff','-r300');
%% S3wi y31
% close
for ipeak = 1:1%numel(Sidot0)   
    
t1_1 = Sidot0(ipeak).t;
y31= Sidot0(ipeak).y(:,31).*1e6;

figure(3)    
plot(t1_1,y31,'r');hold on
plot(t1_1,Sidot0(ipeak).y(:,30).*1e6,'k');
% plot(t1_1(idot0_y31_y36(ipeak).valleyI),y31(idot0_y31_y36(ipeak).valleyI),'r.','markersize',30); 
end

% yaxis = yaxis_lim(SP);
    f1 = figure(3);
    ax2 = subplot(1,1,1);
    ylabel(sprintf('[Ca] SR (nM)'));xlabel('Time (ms)'); 
%     if SP == 1
%     title({'10Hz Fast Pacing and ISO, WT_{ }',' '});
%     else 
%     title({' ',' '});
%     end   
%     xlim([0 5000])
    ylim([0 12e5])
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 5;
    set(findobj(f1,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f1, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f1,'type','axes'),'box','off')
    set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('iTPC_idot0_10hz_id1')),'-dtiff','-r300');
% sort idot0 of
% for i = 1:numel(Sidot0) 
% 
% [TFmax3w,Pmax3w] = islocalmax(abs(Sidot0(i).y(:,88)),'MinProminence',max(abs(Sidot0(i).y(:,88)))/2000);
% % id(i) = Sidot0(i).t(max(find(TFmax3w))) > 650; % sort 2nd peak later than 650ms
% idot0_id(i) = find(TFmax3w > 1);
% end


%% median
% jdot0_inty38_y36_median = median([abs([owt_y31(:).integralY] - [owt_y36(:).integralY])])

%% total calcium
% cellLength = 100; % cell length [um]
% cellRadius = 10.25; % cell radius [um]
% junctionLength = 15e-3; % junc length [um]
% junctionRadius = 160e-3; % junc radius [um]
% distSLcyto = 0.45; % dist. SL to cytosol [um]
% %distJuncSL = 0.5; % dist. junc to SL [um] RABBIT
% distJuncSL = 0.3; % dist. junc to SL [um] MOUSE
% DcaJuncSL = 1.64e-6; % Dca junc to SL [cm^2/sec]
% DcaSLcyto = 1.22e-6; % Dca SL to cyto [cm^2/sec]
% DnaJuncSL = 1.09e-5; % Dna junc to SL [cm^2/sec]
% DnaSLcyto = 1.79e-5; % Dna SL to cyto [cm^2/sec] 
% Vcell = pi*cellRadius^2*cellLength*1e-15; % [L]
% Vmyo = 0.65*Vcell; Vsr = 0.035*Vcell; Vsl = 0.02*Vcell; Vjunc = 0.0539*.01*Vcell; 
% Vls = 0.020*Vcell;
% 
% % WT
% tot_WT = [owt_y36(:).integralY].*Vjunc + [owt_y31(:).integralY].*Vsr + [owt_y37(:).integralY].*Vsl + ...
%             [owt_y38(:).integralY].*Vmyo + [owt_y88(:).integralY].*Vls;        
% % ls2j
% tot_ls2j = [jdot0_y36(:).integralY].*Vjunc + [jdot0_y31(:).integralY].*Vsr + [jdot0_y37(:).integralY].*Vsl + ...
%             [jdot0_y38(:).integralY].*Vmyo + [jdot0_y88(:).integralY].*Vls;
% % ls2i
% tot_ls2i = [idot0_y36(:).integralY].*Vjunc + [idot0_y31(:).integralY].*Vsr + [idot0_y37(:).integralY].*Vsl + ...
%             [idot0_y38(:).integralY].*Vmyo + [idot0_y88(:).integralY].*Vls;
% %
% close all
% figure(7)
% bx = [tot_WT;...
%       tot_ls2j;...
%       tot_ls2i;... 
%       ]; 
% by = [ zeros(length(tot_WT), 1);...
%        1*ones(length(tot_ls2j), 1);...       
%        2*ones(length(tot_ls2i), 1);...
%        ];
% boxplot(bx, by,'Notch','on', 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% % ylim([0 10.5*1e7])
% 
% ax = gca;
% % ax.YAxis.Exponent = -5;
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% % ylabel({'Intracellular Calcium minus', 'Lysosomal Calcium (nmol)'})
% ylabel({'Intracellular Calcium (nmol)'})
% title({' ',' '})
% 
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'er_beat1_4_tot_integral_vol_ls'),'-dtiff','-r300')
% close

%% plot y38 jdot0
% 
% for i = 1: numel(jdot_dad)    %
%     figure(1)
%     p2 = plot(Sjdot0(jdot_dad(i)).t,Sjdot0(jdot_dad(i)).y(:,38).*1e6,'Color','#000000'); 
% %     [TFmax3w,Pmax3w] = islocalmax(abs(Sjdot0(jdot_dad(i)).y(:,38)),'MinProminence',max(abs(Sjdot0(jdot_dad(i)).y(:,38)))/200);
% %     if abs(Sjdot0(jdot_dad(i)).y(:,38)) > min(abs(Sjdot0(jdot_dad(i)).y(:,38)))*1.5 % oct15, 1.1
% %     TFmax3w(end) = 1;
% %     end 
% %   
% %     peakidx = find(TFmax3w)
%     hold on
% %     pause(0.5)s
% end
% % sort jdot0 of jdot_dad
% for i = 1: numel(jdot_dad)    %
%     [TFmax3w,Pmax3w] = islocalmax(abs(Sjdot0(jdot_dad(i)).y(:,38)),'MinProminence',max(abs(Sjdot0(jdot_dad(i)).y(:,38)))/200);
% %     if abs(Sjdot0(jdot_dad(i)).y(:,38)) > min(abs(Sjdot0(jdot_dad(i)).y(:,38)))*1.5 % oct15, 1.1
% %     TFmax3w(end) = 1;
% %     end 
%     id(i) = Sjdot0(jdot_dad(i)).t(max(find(TFmax3w))) > 650; % sort 2nd peak later than 650ms
% 
% end

%% count occurence of SCR in jdot0 
% numel(find([jdot0_y38(:).peakYnumel]~=1))
% jdot0_dad_1 = find([jdot0_y38(:).peakYnumel]~=1);   % of cao1dot8_p3_wyno
% 
% jdot_dad_tot = 1:1:numel(sf343_0);
% jdot0_dad_0 = jdot_dad_tot(find(ismember(jdot_dad_tot,jdot0_dad_1)~=1));
% numel(jdot0_dad_0)
% save('jdot0_dad_1.mat','jdot0_dad_1');  % all dad 
% save('jdot0_dad_0.mat','jdot0_dad_0');
%% 
% jdot_dad_1 = 1:1:numel(jdot_dad);
% jdot_dad_1_laterthan650ms_1 = find(id);
% jdot_dad_1_laterthan650ms_0 = jdot_dad_1(find(ismember(jdot_dad_1,jdot_dad_1_laterthan650ms_1)~=1));
% save('jdot_dad_1_laterthan650ms_1.mat','jdot_dad_1_laterthan650ms_1');  % all dad 
% save('jdot_dad_1_laterthan650ms_0.mat','jdot_dad_1_laterthan650ms_0');

%% boxplot
%% y30+y31
close all
figure(7)
bx = [[owt_y31_y36(:).sumY]+[owt_y30_y36(:).sumY],...
      [jdot0_y31_y36(:).sumY]+[jdot0_y30_y36(:).sumY],...
      [idot0_y31_y36(:).sumY]+[idot0_y30_y36(:).sumY],... 
      ]; 
by = [ zeros(length([owt_y31_y36(:).sumY]), 1);...
       1*ones(length([jdot0_y31_y36(:).sumY]), 1);...       
       2*ones(length([idot0_y31_y36(:).sumY]), 1);...
       ];
lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];

%5
ax.YAxis.Exponent = 7;
% ylim([21e4 60*1e4])
ylabel({'Calsequestrin [Ca] SR +','[Ca] SR (nM)'})

set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y30_y31_2'),'-dtiff','-r300')
%% y31 
close all
figure(7)
bx = [[owt_y31_y36(:).sumY],...
      [jdot0_y31_y36(:).sumY],...
      [idot0_y31_y36(:).sumY],... 
      ]; 
by = [ zeros(length([owt_y31_y36(:).sumY]), 1);...
       1*ones(length([jdot0_y31_y36(:).sumY]), 1);...       
       2*ones(length([idot0_y31_y36(:).sumY]), 1);...
       ];
lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];

%5
ax.YAxis.Exponent = 7;
% ylim([21e4 60*1e4])
ylabel({'[Ca] SR (nM)'})

set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y31_5'),'-dtiff','-r300')
%% y31-y36
close all
figure(7)
bx = [[owt_y31_y36(:).sum_y31_y36],...
      [jdot0_y31_y36(:).sum_y31_y36],...
      [idot0_y31_y36(:).sum_y31_y36],...
      ]; 
by = [ zeros(length([owt_y31_y36(:).sum_y31_y36]), 1);...
       1*ones(length([jdot0_y31_y36(:).sum_y31_y36]), 1);...       
       2*ones(length([idot0_y31_y36(:).sum_y31_y36]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','bkr');

c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];

%5
ax.YAxis.Exponent = 7;
% ylim([21e4 60*1e4])
ylabel({'[Ca] Difference of','Junction and SR (nM)'})

set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y31-y36_5'),'-dtiff','-r300')
% close

%% median y31
median_wt = median([abs([owt_y31_y36(:).sumY] - [owt_y31_y36(:).sumY])])
median_jdot0 = median([abs([owt_y31_y36(:).sumY] - [owt_y31_y36(:).sumY])])
median_idot0 = median([abs([owt_y31_y36(:).sumY] - [owt_y31_y36(:).sumY])])
%% y38 
figure(7)
bx = [[owt_y38(:).sumY],...
      [jdot0_y38(:).sumY],...
      [idot0_y38(:).sumY],... 
      ]; 
by = [ zeros(length([owt_y38(:).sumY]), 1);...
       1*ones(length([jdot0_y38(:).sumY]), 1);...       
       2*ones(length([idot0_y38(:).sumY]), 1);...
       ];
lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})

ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
% legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Cytosol (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y38_5'),'-dtiff','-r300')
% close
%% y36 integral over beat
figure(7)
bx = [[owt_y36(:).sumY],...
      [jdot0_y36(:).sumY],...
      [idot0_y36(:).sumY],... 
      ]; 
by = [ zeros(length([owt_y36(:).sumY]), 1);...
       1*ones(length([jdot0_y36(:).sumY]), 1);...       
       2*ones(length([idot0_y36(:).sumY]), 1);...
       ];
lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up}=0','J_{ls,rel} = 0'})

ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y36_5'),'-dtiff','-r300')
% close

%% pearson correlation 
%% normalised
% figure(1)
% num = numel([owt_y38(:).dad_ampY]);
% numrep31 = repmat(min([owt_y31(:).integralY]), 1, num);
% numrep38 = repmat(min([owt_y38(:).dad_ampY]), 1, num);
% 
% x = ([owt_y31(:).integralY] - numrep31)./(max([owt_y31(:).integralY]) - min([owt_y31(:).integralY])); 
% y = ([owt_y38(:).dad_ampY] - numrep38)./(max([owt_y38(:).dad_ampY]) - min([owt_y38(:).dad_ampY])); 
% 
% corre = corr(x',y','type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('[Ca] SR of Integral Loading'); ylabel('[Ca] Cytosol of DAD Amplitude');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pc_y38amp_ctrlj'),'-dtiff','-r300')
% close 
%% cc =0.66
% figure(1)
% x = [owt_y31(:).integralY]; 
% y = [owt_y38(:).dad_ampY];
% 
% corre = corr(x',y','type','pearson');
% plot(x,y, 'k.', 'MarkerSize',20);
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% % text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% legend({sprintf(CTRL)} )
% xlabel('[Ca] SR of Integral Loading'); ylabel('[Ca] Cytosol of DAD Amplitude');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'pc_y38amp_ctrlj'),'-dtiff','-r300')
% close 

%% y38 amp
% figure(7)
% bx = [[owt_y38(:).ampY],...
%       [jdot0_y38(:).ampY],...
%       [idot0_y38(:).ampY],... 
%       ]; 
% by = [ zeros(length([owt_y38(:).ampY]), 1);...
%        1*ones(length([jdot0_y38(:).ampY]), 1);...       
%        2*ones(length([idot0_y38(:).ampY]), 1);...
%        ];
% lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] Cytosol (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y38_amp'),'-dtiff','-r300')
% close
%% y38 DAD amp
% figure(7)
% bx = [[owt_y38(:).dad_ampY],...
%       [jdot0_y38(:).dad_ampY],...
%       [idot0_y38(:).dad_ampY],... 
%       ]; 
% by = [ zeros(length([owt_y38(:).dad_ampY]), 1);...
%        1*ones(length([jdot0_y38(:).dad_ampY]), 1);...       
%        2*ones(length([idot0_y38(:).dad_ampY]), 1);...
%        ];
% lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','Spontaneous [Ca] Cytosol (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y38_ampdad'),'-dtiff','-r300')
% close
% %% y38 Amp timepoint
% figure(8)
% bx = [[owt(:).y38_ampT],...
%       [ojdot0(:).y38_ampT],...
%       [oidot0(:).y38_ampT],...   
%       ]; 
% by = [ zeros(length([owt(:).y38_ampT]), 1);...
%        1*ones(length([ojdot0(:).y38_ampT]), 1);...       
%        2*ones(length([oidot0(:).y38_ampT]), 1);...
%        ];
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Timepoint of','Amplitude (ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y38_amptp'),'-dtiff','-r300')
% close
% %% y38 DAD timepoint
% figure(9)
% bx = [[owt(:).y38_dad_ampT],...
%       [ojdot0(:).y38_dad_ampT],...
%       [oidot0(:).y38_dad_ampT],...      
%       ]; 
% by = [ zeros(length([owt(:).y38_dad_ampT]), 1);...
%        1*ones(length([ojdot0(:).y38_dad_ampT]), 1);...
%        2*ones(length([oidot0(:).y38_dad_ampT]), 1);...
%        ];
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% % c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Timepoint of','DAD Amplitude (ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y38_dadtp'),'-dtiff','-r300')
% close
% %% y88 loading
% figure(10)
% bx = [[owt(:).y88_initial],...
%       [ojdot0(:).y88_initial],...
%       [oidot0(:).y88_initial],...
%       ]; 
% by = [ zeros(length([owt(:).y88_initial]), 1);...
%        1*ones(length([ojdot0(:).y88_initial]), 1);... 
%        2*ones(length([oidot0(:).y88_initial]), 1);... 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 3;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] Lysosome of','Initial Loading (nM)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y88_initial'),'-dtiff','-r300')
% close
%  
% figure(11)
% bx = [[owt(:).y88_integral],...
%       [ojdot0(:).y88_integral],...
%       [oidot0(:).y88_integral],...
%       ]; 
% by = [ zeros(length([owt(:).y88_integral]), 1);...
%        1*ones(length([ojdot0(:).y88_integral]), 1);... 
%        2*ones(length([oidot0(:).y88_integral]), 1);... 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] Lysosome of','Integral Loading (nM)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y88_integral'),'-dtiff','-r300')
% close
% 
% figure(11)
% bx = [[owt(:).y88_amp],...
%       [ojdot0(:).y88_amp],...
%       [oidot0(:).y88_amp],...
%       ]; 
% by = [ zeros(length([owt(:).y88_amp]), 1);...
%        1*ones(length([ojdot0(:).y88_amp]), 1);... 
%        2*ones(length([oidot0(:).y88_amp]), 1);... 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] Lysosome of','Amplitude (nM)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y88_amp'),'-dtiff','-r300')
% close
% %% y31 biomarkers 
% figure(10)
% bx = [[owt(:).y31_initial],...
%       [ojdot0(:).y31_initial],...
%       [oidot0(:).y31_initial],...
%       ]; 
% by = [ zeros(length([owt(:).y31_initial]), 1);...
%        1*ones(length([ojdot0(:).y31_initial]), 1);... 
%        2*ones(length([oidot0(:).y31_initial]), 1);...\ 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR of','Initial Loading (nM)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_initial'),'-dtiff','-r300')
% close
%  
% figure(11)
% bx = [[owt_y31(:).integralY],...
%       [jdot0_y31(:).integralY],...
%       [idot0_y31(:).integralY],...
%       ]; 
% by = [ zeros(length([owt_y31(:).integralY]), 1);...
%        1*ones(length([jdot0_y31(:).integralY]), 1);... 
%        2*ones(length([idot0_y31(:).integralY]), 1);... 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 7;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Integral [Ca] SR over','a Beat (nM)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_integralbeat'),'-dtiff','-r300')
% close
%  
% figure(11)
% bx = [[owt(:).y31_amp],...
%       [ojdot0(:).y31_amp],...
%       [oidot0(:).y31_amp],...
%       ]; 
% by = [ zeros(length([owt(:).y31_amp]), 1);...
%        1*ones(length([ojdot0(:).y31_amp]), 1);... 
%        2*ones(length([oidot0(:).y31_amp]), 1);... 
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% % legend([c(2);c(1)],'WT','TPC-KO','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR of','Amplitude (nM)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_amp'),'-dtiff','-r300')
% close

% %% multivariable partialcorri
% rng('default');                 % for reproducibility of results
% lhs_p = 9;                      % number of parameters
% lhs_n = 1000;                     % number of models (combinations)  
% X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
% lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
% ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
% sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
% sf = sf(h1_cao1_sf1000_sf6_0,:);
% sf55 = sf(sf343_0,:);
%  
% %% reducing 0 ls_j, less CICR 
% sf106jdot0 = sf55;
% lsj_0 = sf106jdot0(:,1).*0;
% sf106jdot0(:,1) = lsj_0;
% %% reducing 0 ls_i, less CICR 
% sf106idot0 = sf55;
% lsi_0 = sf106idot0(:,2).*0;
% sf106idot0(:,2) = lsi_0;
% 
% %% pcc y36-y31
% figure(20)
% %% ctrl
% x = [[owt_y36(:).peak_integralY]'-[owt_y31(:).peak_integralY]',...
%      ];
% y = sf55;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owt_y36(:).integralY]'-[owt_y31(:).integralY]',...
%      ];
% y = sf55;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0_y36(:).peak_integralY]'-[jdot0_y31(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0_y36(:).integralY]'-[jdot0_y31(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0_y36(:).peak_integralY]'-[idot0_y31(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0_y36(:).integralY]'-[idot0_y31(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL}, {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{J_{j2l} = 0}, {Integral [Ca] Difference of Junction and SR over Peak}',...    
%      '{J_{ls2i} = 0}, {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{CTRL}, {Integral [Ca] Difference of Junction and SR }',...
%      '{J_{j2l} = 0}, {Integral [Ca] Difference of Junction and SR }',...
%      '{J_{ls2i} = 0}, {Integral [Ca] Difference of Junction and SR }',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_y36-y31'),'-dtiff','-r300')
% close 

%% //pcc SR integral, y38 DAD 
% figure(20)
% x = [[owt_y31(:).integralY]',...
%      [owt_y38(:).dad_ampY]',...
%      [owt_y38(:).dad_integralY]',...
%      ];
% y = sf106;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% 
% yv= {'{CTRL} {Integral [Ca] SR}',...
%      '{CTRL} {Amplitude DAD [Ca] CS}',...
%      '{CTRL} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 400])
% print(gcf, fullfile(pwd, 'pcc_ctrl'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0_y31(:).integralY]',...
%      [jdot0_y38(:).dad_ampY]',...
%      [jdot0_y38(:).dad_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% 
% yv= {'{J_{ls2j} = 0} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Amplitude DAD [Ca] CS}',...
%      '{J_{ls2j} = 0} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO in J_{ls2j}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 400])
% print(gcf, fullfile(pwd, 'pcc_ls2j'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[idot0_y31(:).integralY]',...
%      [idot0_y38(:).dad_ampY]',...
%      [idot0_y38(:).dad_integralY]',...
%      ];
% y = sf106idot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% 
% yv= {'{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      '{J_{ls2i} = 0} {Amplitude DAD [Ca] CS}',...
%      '{J_{ls2i} = 0} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO in J_{ls2i}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 400])
% print(gcf, fullfile(pwd, 'pcc_ls2i'),'-dtiff','-r300')
% close 

%% /pcc SR integral, y38 DAD 
% figure(20)
% %% ctrl
% x = [[owt_y31(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owt_y38(:).dad_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0_y31(:).integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0_y38(:).dad_integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0_y31(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0_y38(:).dad_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      '{CTRL} {Integral DAD [Ca] CS}',...
%      '{J_{ls2j} = 0} {Integral DAD [Ca] CS}',...
%      '{J_{ls2i} = 0} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_dadintegral'),'-dtiff','-r300')
% close

%% pcc SR integral, y38 DAD 
% figure(20)
% %% ctrl
% x = [[owt_y31(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owt_y38(:).dad_ampY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0_y31(:).integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0_y38(:).dad_ampY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0_y31(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0_y38(:).dad_ampY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] SR}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SR}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      '{CTRL} {Amplitude DAD [Ca] CS}',...
%      '{J_{ls2j} = 0} {Amplitude DAD [Ca] CS}',...
%      '{J_{ls2i} = 0} {Amplitude DAD [Ca] CS}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_dadamp'),'-dtiff','-r300')
% close 

%% pcc diagnol
% figure(20)
% x = [[owt_y31(:).integralY]',[jdot0_y31(:).integralY]',[idot0_y31(:).integralY]',...
%      [owt_y38(:).dad_ampY]',[jdot0_y38(:).dad_ampY]',[idot0_y38(:).dad_ampY]',...
%      [owt_y38(:).dad_integralY]',[jdot0_y38(:).dad_integralY]',[idot0_y38(:).dad_integralY]',...
%      ];
% y = [[owt_y31(:).integralY]',[jdot0_y31(:).integralY]',[idot0_y31(:).integralY]',...
%      [owt_y38(:).dad_ampY]',[jdot0_y38(:).dad_ampY]',[idot0_y38(:).dad_ampY]',...
%      [owt_y38(:).dad_integralY]',[jdot0_y38(:).dad_integralY]',[idot0_y38(:).dad_integralY]',...
%      ];
%  
% [rho_s,pval_s] = corr(x,y,'type','pearson','rows','complete');
% 
% 
% yv= {'{CTRL} {Integral [Ca] SR}','{J_{ls2j} = 0} {Integral [Ca] SR}','{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      '{CTRL} {Amplitude [Ca] CS}','{J_{ls2j} = 0} {Amplitude [Ca] CS}','{J_{ls2i} = 0} {Amplitude [Ca] CS}',...
%      '{CTRL} {Integral DAD [Ca] CS}','{J_{ls2j} = 0} {Integral DAD [Ca] CS}','{J_{ls2i} = 0} {Integral DAD [Ca] CS}',...
%     };
% 
% xv= {'{CTRL} {Integral [Ca] SR}','{J_{ls2j} = 0} {Integral [Ca] SR}','{J_{ls2i} = 0} {Integral [Ca] SR}',...
%      '{CTRL} {Amplitude [Ca] CS}','{J_{ls2j} = 0} {Amplitude [Ca] CS}','{J_{ls2i} = 0} {Amplitude [Ca] CS}',...
%      '{CTRL} {Integral DAD [Ca] CS}','{J_{ls2j} = 0} {Integral DAD [Ca] CS}','{J_{ls2i} = 0} {Integral DAD [Ca] CS}',...
%     };
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[0 1]);
% mymap = [0 0 0
%     1 0 0
%     0 1 0
%     0 0 1
%     1 1 1];
% colormap(mymap)
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia in ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 1400])
% print(gcf, fullfile(pwd, 'pcc_ctrl_ls2j_ls2i_pearson'),'-dtiff','-r300')
% close 

%% pcc y38 amplitude 
% figure(20)
% x = [[owt(:).y38_ampY]',[owt(:).y38_dad_ampY]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = sf106;
% [rho_s_owt,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38ctrl'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[ojdot0(:).y38_ampY]',[ojdot0(:).y38_dad_ampY]', [ojdot0(:).y38_ampT]',[ojdot0(:).y38_dad_ampT]',...
%      ];
% y = sf106jdot0;
% [rho_s_ojdot0,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2j=0}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38jdot0'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[oidot0(:).y38_ampY]',[oidot0(:).y38_dad_ampY]', [oidot0(:).y38_ampT]',[oidot0(:).y38_dad_ampT]',...
%      ];
% y = sf106idot0;
% [rho_s_oidot0,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2i=0}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38idot0'),'-dtiff','-r300')
% close 

%% scatter plot 
%% test
% figure(1)
% notnan_id = find(~logical(isnan([owtF_serca(:).dad_ampY]')));
% x = [owtF_serca(notnan_id).dad_ampY]'; % ls2i
% y = [owt(notnan_id).y38_dad_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% legend(sprintf('CC = %.2f ',corre));
% % text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2j}'); ylabel('Amp');title('[Ca] Cytosol CTRL')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38amp_ctrlj'),'-dtiff','-r300')
% close 

%% ctrl ls2j 
% figure(1)
% x = sf106(:,1); % ls2i
% y = [owt(:).y38_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2j}'); ylabel('Amp');title('[Ca] Cytosol CTRL')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38amp_ctrlj'),'-dtiff','-r300')
% close 
% 
% % ls2i to y38amp_dad
% figure(1)
% x = sf106(:,1); % ls2i
% y = [owt(:).y38_dad_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2j}'); ylabel('Amp_{DAD}');title('[Ca] Cytosol CTRL')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38dad_ctrlj'),'-dtiff','-r300')
% close 
% %% ctrl ls2i 
% figure(1)
% x = sf106(:,2); % ls2i
% y = [owt(:).y38_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2i}'); ylabel('Amp');title('[Ca] Cytosol CTRL')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38amp_ctrli'),'-dtiff','-r300')
% close 
% 
% % ls2i to y38amp_dad
% figure(1)
% x = sf106(:,2); % ls2i
% y = [owt(:).y38_dad_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),10/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2i}'); ylabel('Amp_{DAD}');title('[Ca] Cytosol CTRL')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38dad_ctrli'),'-dtiff','-r300')
% close 
 
%% jdot0 
% figure(1)
% x = sf106jdot0(:,2); % ls2i
% y = [ojdot0(:).y38_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),9/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2i}'); ylabel('Amp');title('[Ca] Cytosol J_{ls2j} = 0')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38amp_jdot0i'),'-dtiff','-r300')
% close 
% 
% % ls2i to y38amp_dad
% figure(1)
% 
% notnan_id = find(~logical(isnan([ojdot0(:).y38_dad_ampY]')));
% x = sf106jdot0(notnan_id,2); % ls2i
% y = [ojdot0(notnan_id).y38_dad_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),9/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2i}'); ylabel('Amp_{DAD}');title('[Ca] Cytosol J_{ls2j} = 0')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38dad_jdot0i'),'-dtiff','-r300')
% close 
% 
% %% idot0 
% figure(1)
% x = sf106idot0(:,1); % ls2i
% y = [oidot0(:).y38_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),9/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2j}'); ylabel('Amp');title('[Ca] Cytosol J_{ls2i} = 0')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38amp_idot0j'),'-dtiff','-r300')
% close 
% 
% % ls2i to y38amp_dad
% figure(1)
% 
% notnan_id = find(~logical(isnan([oidot0(:).y38_dad_ampY]')));
% x = sf106idot0(notnan_id,1); % ls2i
% y = [oidot0(notnan_id).y38_dad_ampY]';
% corre = corr(x,y,'type','pearson');
% plot(x,y, 'k.');
% hold on
% % text(7/10*max(x),20/20*max(y),sprintf('PCC = %.2f ',rho_s_owt(1,2)),'FontName','Times New Roman','FontSize',30); 
% text(7/10*max(x),9/10*max(y),sprintf('CC = %.2f ',corre),'FontName','Times New Roman','FontSize',30); 
% xlabel('J_{ls2j}'); ylabel('Amp_{DAD}');title('[Ca] Cytosol J_{ls2i} = 0')
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'pcc_sp_y38dad_idot0j'),'-dtiff','-r300')
% close 

%% pcc y38 timepoint
% figure(20)
% x = [[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = sf106;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38ctrlT'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[ojdot0(:).y38_ampT]',[ojdot0(:).y38_dad_ampT]', [ojdot0(:).y38_ampT]',[ojdot0(:).y38_dad_ampT]',...
%      ];
% y = sf106jdot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls2j=0}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38jdot0T'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[oidot0(:).y38_ampT]',[oidot0(:).y38_dad_ampT]', [oidot0(:).y38_ampT]',[oidot0(:).y38_dad_ampT]',...
%      ];
% y = sf106idot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls2i=0}');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y38idot0T'),'-dtiff','-r300')
% close 

%% y31
% figure(21)
% x = [[owt(:).y31_amp]',[owt(:).y31_initial]',[owt(:).y31_integral]',...
%      ];
% y = sf106;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'CTRL {Amp}','CTRL {Initial Loading}','CTRL {Integral Loading}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] SR biomarkers of Calcium Overload under ISO \n CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y31ctrl'),'-dtiff','-r300')
% close 
% 
% figure(21)
% x = [[ojdot0(:).y31_amp]',[ojdot0(:).y31_initial]', [ojdot0(:).y31_integral]',...
%      ];
% y = sf106jdot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'J_{ls2j=0} {Amp}','J_{ls2j=0} {Initial Loading}','J_{ls2j=0} {Integral Loading}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] SR biomarkers of Calcium Overload under ISO \n J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y31jdot0'),'-dtiff','-r300')
% close 
% 
% figure(21)
% x = [[oidot0(:).y31_amp]',[oidot0(:).y31_initial]', [oidot0(:).y31_integral]',...
%      ];
% y = sf106idot0;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% % rho_s(isnan(rho_s)) =0;
% yv= {'J_{ls2i=0} {Amp}','J_{ls2i=0} {Initial Loading}','J_{ls2i=0} {Integral Loading}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] SR biomarkers of Calcium Overload under ISO \n J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1400 500])
% print(gcf, fullfile(pwd, 'pcc_y31idot0'),'-dtiff','-r300')
% close 



%%                1        2       3            4      5       6    
% currentname = {'Jserca' 'J_RyR' 'I_Ca_store' 'Incx' 'JLS2J' 'JLS2I'};  
% currents = {1 2 3 4 5 6};
% Fwt 2 F3w
% for j = 1: numel(Fwt)
% F3w(j).t = Fwt(j).tArray;
% F3w(j).currents = [Fwt(j).Jserca',Fwt(j).J_RyR',Fwt(j).I_Ca_store',Fwt(j).Incx',Fwt(j).JLS2J',Fwt(j).JLS2I'];
% end
% 
% % Fidot0 2 F3o
% Fwt = Fidot0;
% for j = 1: numel(Fwt)
% F3o(j).t = Fwt(j).tArray;
% F3o(j).currents = [Fwt(j).Jserca',Fwt(j).J_RyR',Fwt(j).I_Ca_store',Fwt(j).Incx',Fwt(j).JLS2J',Fwt(j).JLS2I'];
% end
% 
% % Fjdot0 2 F3j
% Fwt = Fjdot0;
% for j = 1: numel(Fwt)
% F3j(j).t = Fwt(j).tArray;
% F3j(j).currents = [Fwt(j).Jserca',Fwt(j).J_RyR',Fwt(j).I_Ca_store',Fwt(j).Incx',Fwt(j).JLS2J',Fwt(j).JLS2I'];
% end


% Y = [1 2 3 4 5 6];
% Yspace = {'J_SERCA','J_RyR','I_Cal','I_NCX','J_{ls,up}','J_{ls,rel}'};
% Yscale = [1e6 1e6 1 1 1e6 1e6]; 
% Yaxis = [2 4 1 0 4 4];
% Yylabel = {'J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};
% 

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
Y = [1 2 3 4 5 6 11];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{NCX}'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1]; 
Yaxis = [1 -1 2 4 4 3 -1];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{NCX} (pA/pF)'};

for SP = 5:6%numel(Y)
for idad = 1: numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt(idad).tArray,Fwt(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(2);ax2 = subplot(1,1,1);
    p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(3);ax3 = subplot(1,1,1);
    p3 =plot(Fjdot0(idad).tArray,Fjdot0(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
%       figure(1);ax1 = subplot(1,1,1);
%     p1 =plot(Fwt(idad).tArray,Fwt(idad).currents(:,27).*1,'Color','#000000');
%     hold on
%     
%     figure(2);ax2 = subplot(1,1,1);
%     p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,27).*1,'Color','#000000');
%     hold on
%     
%     figure(3);ax3 = subplot(1,1,1);
%     p3 =plot(Fjdot0(idad).tArray,Fjdot0(idad).currents(:,27).*1,'Color','#000000');
%     hold on

end
linkaxes([ax1,ax2,ax3],'y');
fontsize = 40;

f1 = figure(1);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% ylabel(sprintf('RyR Leak'));xlabel('Time (ms)');   
if SP ==7
title({'Hypercalcemia and ISO, WT_{ }',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
%                ax.YAxis.Exponent = -6;%Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s WT',Yspace{SP})),'-dtiff','-r300');
% print(f1, fullfile(pwd, sprintf('wt_ryrleak')),'-dtiff','-r300');


f2 = figure(2);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');  
% ylabel(sprintf('RyR Leak'));xlabel('Time (ms)');  
if SP ==7
title({'Hypercalcemia and ISO, J_{ls,rel} = 0',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
%                ax.YAxis.Exponent = -6;%Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f2,'Units','pixels','Position',[0 0 700 500])
print(f2, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s idot0',Yspace{SP})),'-dtiff','-r300');
% print(f2, fullfile(pwd, sprintf('idot0_ryrleak')),'-dtiff','-r300');

f3 = figure(3);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)'); 
% ylabel(sprintf('RyR Leak'));xlabel('Time (ms)');  
if SP ==7
title({'Hypercalcemia and ISO, J_{ls,up} = 0',' '});
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
%                ax.YAxis.Exponent = -6;%Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f3,'Units','pixels','Position',[0 0 700 500])
print(f3, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s jdot0',Yspace{SP})),'-dtiff','-r300');
% print(f2, fullfile(pwd, sprintf('jdot0_ryrleak')),'-dtiff','-r300');

close all
end

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%% inset   17        18     19       20       21             22            23               24       25       26
Y = [1 2 3 4 5 6 11];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{NCX}'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1]; 
Yaxis = [1 -1 2 4 4 3 -1];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{NCX} (pA/pF)'};

for SP = 5:5%numel(Y)
for idad = 1: numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt(idad).tArray,Fwt(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(2);ax2 = subplot(1,1,1);
    p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    
    figure(3);ax3 = subplot(1,1,1);
    p3 =plot(Fjdot0(idad).tArray,Fjdot0(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
    hold on
    

end
linkaxes([ax1,ax2,ax3],'y');
fontsize = 70;

f1 = figure(1);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP ==7
% title({'Hypercalcemia and ISO, WT_{ }',' '});
% else
% title({' ',' '})
% end
               ax = gca;
%                ax. Position = [0.2 0.2 0.7 0.7];
               % zoom in
               xlim([0 50])
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('h1_cao1dot8_wyon_zoom %s wt',Yspace{SP})),'-dtiff','-r300');

f2 = figure(2);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');  
% if SP ==7
% title({'Hypercalcemia and ISO, J_{ls,rel} = 0',' '});
% else
% title({' ',' '})
% end
               ax = gca;
%                ax. Position = [0.2 0.2 0.7 0.7];
               % zoom in
               xlim([0 50])
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f2,'Units','pixels','Position',[0 0 700 500])
print(f2, fullfile(pwd, sprintf('h1_cao1dot8_wyon_zoom %s idot0',Yspace{SP})),'-dtiff','-r300');

f3 = figure(3);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP ==7
% title({'Hypercalcemia and ISO, J_{ls,up} = 0',' '});
% else
% title({' ',' '})
% end
               ax = gca;
%                ax. Position = [0.2 0.2 0.7 0.7];
               % zoom in
               xlim([0 50])
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f3,'Units','pixels','Position',[0 0 700 500])
print(f3, fullfile(pwd, sprintf('h1_cao1dot8_wyon_zoom %s jdot0',Yspace{SP})),'-dtiff','-r300');

close all
end

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
for ipeak = 1: numel(Fwt)
   
tflux = Fwt(ipeak).tArray;
yserca = Fwt(ipeak).Jserca.*1e6;    
yryr = Fwt(ipeak).J_RyR.*1e6;  

ycal = abs(Fwt(ipeak).I_Ca_store);    
yncx = abs(Fwt(ipeak).Incx);    
yls2j = abs(Fwt(ipeak).JLS2J.*1e6); 

yls2i = Fwt(ipeak).JLS2I.*1e6;  

owtF_serca(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr(ipeak) = peakfinder(tflux,yryr,200,200);
[~,it500] = min(abs(tflux - 500));
%     owtF_ryr_0_500(ipeak) = trapz(tflux(1:it500),yryr(1:it500));
%     owtF_ryr_500_end(ipeak) = trapz(tflux(it500:end),yryr(it500:end));
owtF_cal(ipeak) = peakfinder(tflux,ycal,2,2);
owtF_ls2j(ipeak) = peakfinder(tflux,yls2j,200,200);
owtF_ls2i(ipeak) = peakfinder(tflux,yls2i,200,200);
owtF_ncx(ipeak) = peakfinder(tflux,yncx,2,2);

owtF_juncx(ipeak) = peakfinder(tflux,Fwt(ipeak).currents(:,11),2,2);
owtF_jucal(ipeak) = peakfinder(tflux,Fwt(ipeak).currents(:,9),2,2);

end



%% biomarker oidot0
for ipeak = 1: numel(Fidot0)
   
tflux = Fidot0(ipeak).tArray;
yserca = Fidot0(ipeak).Jserca.*1e6;    
yryr = Fidot0(ipeak).J_RyR.*1e6;   

ycal = abs(Fidot0(ipeak).I_Ca_store);    
yncx = abs(Fidot0(ipeak).Incx);    
yls2j = abs(Fidot0(ipeak).JLS2J.*1e6);    
%ls2j_portion
yls2j_portion = Fidot0(ipeak).JLS2J.*1e6;   

yls2i = Fidot0(ipeak).JLS2I.*1e6;  

idot0F_serca(ipeak) = peakfinder(tflux,yserca,200,200);
idot0F_ryr(ipeak) = peakfinder(tflux,yryr,200,200);
[~,it500] = min(abs(tflux - 500));
%     idot0F_ryr_0_500(ipeak) = trapz(tflux(1:it500),yryr(1:it500));
%     idot0F_ryr_500_end(ipeak) = trapz(tflux(it500:end),yryr(it500:end));
idot0F_cal(ipeak) = peakfinder(tflux,ycal,2,2);
idot0F_ls2j(ipeak) = peakfinder(tflux,yls2j,200,200);
idot0F_ls2i(ipeak) = peakfinder(tflux,yls2i,200,200);
idot0F_ncx(ipeak) = peakfinder(tflux,yncx,2,2);

idot0F_ls2j_portion(ipeak) = ls2j_portion(tflux,yls2j_portion,200,200);

idot0F_juncx(ipeak) = peakfinder(tflux,Fidot0(ipeak).currents(:,11),2,2);
idot0F_jucal(ipeak) = peakfinder(tflux,Fidot0(ipeak).currents(:,9),2,2);
end  

%%            1        2     3       4         5     6       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i]; 
% Y = [1 2 3 4 5 6];
% Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}'};
% Yscale = [1 1 1e6 1e6 1e6 1e6]; 
% Yaxis = [1 -1 2 4 4 3];
% Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};
% 
% for SP = 5:5%numel(Y)
% for idad = 1: numel(Fwt)
%     figure(2);ax2 = subplot(1,1,1);
%     p2 =plot(Fidot0(idad).tArray,Fidot0(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');hold on
%     id1 = idot0F_ls2j_portion(idad).valleyidx;
%     plot(Fidot0(idad).tArray(id1),Fidot0(idad).currents(id1,Y(SP)).*Yscale(SP),'r.','markersize',30);
%     id2 = idot0F_ls2j_portion(idad).peakidx;
%     plot(Fidot0(idad).tArray(id2),Fidot0(idad).currents(id2,Y(SP)).*Yscale(SP),'b.','markersize',30);
%     
% end
% end
% 
% median_outperin= median(abs([idot0F_ls2j_portion(:).ls2jout]))/median(abs([idot0F_ls2j_portion(:).ls2jin]))
%% biomarker ojdot0
for ipeak = 1: numel(Fjdot0)
   
tflux = Fjdot0(ipeak).tArray;
yserca = Fjdot0(ipeak).Jserca.*1e6;    
yryr = Fjdot0(ipeak).J_RyR.*1e6; 

ycal = abs(Fjdot0(ipeak).I_Ca_store);    
yncx = abs(Fjdot0(ipeak).Incx);    
yls2j = abs(Fjdot0(ipeak).JLS2J.*1e6);    

yls2i = Fjdot0(ipeak).JLS2I.*1e6;  

jdot0F_serca(ipeak) = peakfinder(tflux,yserca,200,200);
jdot0F_ryr(ipeak) = peakfinder(tflux,yryr,200,200);
[~,it500] = min(abs(tflux - 500));
%     jdot0F_ryr_0_500(ipeak) = trapz(tflux(1:it500),yryr(1:it500));
%     jdot0F_ryr_500_end(ipeak) = trapz(tflux(it500:end),yryr(it500:end));
jdot0F_cal(ipeak) = peakfinder(tflux,ycal,2,2);
jdot0F_ls2j(ipeak) = peakfinder(tflux,yls2j,200,200);
jdot0F_ls2i(ipeak) = peakfinder(tflux,yls2i,200,200);
jdot0F_ncx(ipeak) = peakfinder(tflux,yncx,2,2);

jdot0F_juncx(ipeak) = peakfinder(tflux,Fjdot0(ipeak).currents(:,11),2,2);
jdot0F_jucal(ipeak) = peakfinder(tflux,Fjdot0(ipeak).currents(:,9),2,2);

end
% sort serca peak
% idot_serca_dad_1 = find([idot0F_serca(:).peakYnumel]~=1);   % of cao1dot8_p3_wyno
% idot_serca_dad_tot = 1:1:numel(cao1dot8_p3_wyno);
% idot_serca_dad_0 = idot_serca_dad_tot(find(ismember(idot_serca_dad_tot,idot_serca_dad_1)~=1));
% numel(idot_serca_dad_0)
% numel(idot_serca_dad_1)
% save('idot_serca_dad_1.mat','idot_serca_dad_1');  % all dad 
% save('idot_serca_dad_0.mat','idot_serca_dad_0');

%% bp integral serca 
figure(7)
bx = [[owtF_serca(:).integralY],...
      [jdot0F_serca(:).integralY],...
      [idot0F_serca(:).integralY],...  
      ]; 
by = [ zeros(length([owtF_serca(:).integralY]), 1);...
       1*ones(length([jdot0F_serca(:).integralY]), 1);...       
       2*ones(length([idot0F_serca(:).integralY]), 1);...
       ];
   
lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})

ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
% legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'serca'),'-dtiff','-r300')
% close

%% bp integral ryr 
figure(7)
bx = [[owtF_ryr(:).integralY],...
      [jdot0F_ryr(:).integralY],...
      [idot0F_ryr(:).integralY],...  
      ]; 
by = [ zeros(length([owtF_ryr(:).integralY]), 1);...
       1*ones(length([jdot0F_ryr(:).integralY]), 1);...       
       2*ones(length([idot0F_ryr(:).integralY]), 1);...
       ];
   
lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})

ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'ryr'),'-dtiff','-r300')
% close

% %% bp juncx   
% figure(7)
% bx = [[owtF_juncx(:).integralY],...
%       [jdot0F_juncx(:).integralY],...
%       [idot0F_juncx(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx(:).integralY]), 1);...
%        1*ones(length([jdot0F_juncx(:).integralY]), 1);...       
%        2*ones(length([idot0F_juncx(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(abs(bx), by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Juncitonal NCX Current (pA/pF)'})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'juncx'),'-dtiff','-r300')

% %% bp jucal figure(7)
% bx = [[owtF_jucal(:).integralY],...
%       [jdot0F_jucal(:).integralY],...
%       [idot0F_jucal(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jucal(:).integralY]), 1);...
%        1*ones(length([jdot0F_jucal(:).integralY]), 1);...       
%        2*ones(length([idot0F_jucal(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(abs(bx), by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax. Position = [0.2 0.15 0.7 0.7];
% ax.YAxis.Exponent = 1;
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Juncitonal L-type Current (pA/pF)'})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'jucal'),'-dtiff','-r300')

% close

% %% 0 500
% %% bp integral ryr 
% figure(7)
% bx = [[owtF_ryr_0_500(:)],...
%       [jdot0F_ryr_0_500(:)],...
%       [idot0F_ryr_0_500(:)],...  
%       ]; 
% by = [ zeros(length([owtF_ryr(:).integralY]), 1);...
%        1*ones(length([jdot0F_ryr(:).integralY]), 1);...       
%        2*ones(length([idot0F_ryr(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 6;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'RyR [Ca] Flux','from 0 to 500ms (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_ryr_integralbeat_0_500'),'-dtiff','-r300')
% close
% 
% %% 500-1000
% %% bp integral ryr 
% figure(7)
% bx = [[owtF_ryr_500_end(:)],...
%       [jdot0F_ryr_500_end(:)],...
%       [idot0F_ryr_500_end(:)],...  
%       ]; 
% by = [ zeros(length([owtF_ryr(:).integralY]), 1);...
%        1*ones(length([jdot0F_ryr(:).integralY]), 1);...       
%        2*ones(length([idot0F_ryr(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 5;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'RyR [Ca] Flux', 'from 500 to 1000ms (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_ryr_integralbeat_500_1000'),'-dtiff','-r300')
% close
% 
% %% bp integral cal
% figure(7)
% bx = [[owtF_cal(:).integralY],...
%       [jdot0F_cal(:).integralY],...
%       [idot0F_cal(:).integralY],...  
%       ]; 
% by = [ zeros(length([owtF_cal(:).integralY]), 1);...
%        1*ones(length([jdot0F_cal(:).integralY]), 1);...       
%        2*ones(length([idot0F_cal(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls,up} = 0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
%  
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'CaL [Ca] Current (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_cal_integralbeat'),'-dtiff','-r300')
% close


%% pcc serca
% figure(20)
% %% ctrl
% x = [[owtF_serca(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owtF_serca(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0F_serca(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0F_serca(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0F_serca(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0F_serca(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] of SERCA over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA over Peak}',...
%      '{CTRL} {Integral [Ca] SERCA }',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA }',...
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA }',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_serca'),'-dtiff','-r300')
% close 

%% pcc serca-ryr
% figure(20)
% %% ctrl
% x = [[owtF_serca(:).peak_integralY]'-[owtF_ryr(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owtF_serca(:).integralY]'-[owtF_ryr(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0F_serca(:).peak_integralY]'-[jdot0F_ryr(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0F_serca(:).integralY]'-[jdot0F_ryr(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0F_serca(:).peak_integralY]'-[idot0F_ryr(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0F_serca(:).integralY]'-[idot0F_ryr(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{CTRL} {Integral [Ca] Difference of SERCA and RyR }',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR }',...
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR }',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_serca-ryr'),'-dtiff','-r300')
% close 


%% pcc integral calcium difference of y36 - y31
% figure(20)
% %% ctrl
% x = [[owt_y36(:).peak_integralY]'-[owt_y31(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owt_y36(:).integralY]'-[owt_y31(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0_y36(:).peak_integralY]'-[jdot0_y31(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0_y36(:).integralY]'-[jdot0_y31(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0_y36(:).peak_integralY]'-[idot0_y31(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0_y36(:).integralY]'-[idot0_y31(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of Junction and SR over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{CTRL} {Integral [Ca] Difference of Junction and SR }',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of Junction and SR }',...
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of Junction and SR }',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_y36-y31'),'-dtiff','-r300')
% close 

%% integral peak y31
% figure(7)
% bx = [[owt_y31(:).peak_integralY],...
%       [jdot0_y31(:).peak_integralY],...
%       [idot0_y31(:).peak_integralY],...  
%       ]; 
% by = [ zeros(length([owt_y31(:).peak_integralY]), 1);...
%        1*ones(length([jdot0_y31(:).peak_integralY]), 1);...       
%        2*ones(length([idot0_y31(:).peak_integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 7;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR Integral Peak (nM)'})
% title({'Hypercalcemia','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_integralpeak'),'-dtiff','-r300')
% close

%% bp ls2j
% figure(7)
% bx = [[owtF_ls2j(:).ampY],...
%       [jdot0F_ls2j(:).ampY],...
%       [idot0F_ls2j(:).ampY],...  
%       ]; 
% by = [ zeros(length([owtF_ls2j(:).ampY]), 1);...
%        1*ones(length([jdot0F_ls2j(:).ampY]), 1);...       
%        2*ones(length([idot0F_ls2j(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2j} of','Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2j_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ls2j(:).dad_ampY],...
%       [jdot0F_ls2j(:).dad_ampY],...
%       [idot0F_ls2j(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ls2j(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ls2j(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ls2j(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 3;
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2j} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2j_ampdad'),'-dtiff','-r300')
% close 
% 
% %% bp ls2i
% figure(7)
% bx = [[owtF_ls2i(:).ampY],...
%       [jdot0F_ls2i(:).ampY],...
%       [idot0F_ls2i(:).ampY],...   
%       ]; 
% by = [ zeros(length([owtF_ls2i(:).ampY]), 1);...
%        1*ones(length([jdot0F_ls2i(:).ampY]), 1);...       
%        2*ones(length([idot0F_ls2i(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2i} of','Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2i_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ls2i(:).dad_ampY],...
%       [jdot0F_ls2i(:).dad_ampY],...
%       [idot0F_ls2i(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ls2i(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ls2i(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ls2i(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2i} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2i_ampdad'),'-dtiff','-r300')
% close
% 
% %% bp ryr
% figure(7)
% bx = [[owtF_ryr(:).ampY],...
%       [jdot0F_ryr(:).ampY],...
%       [idot0F_ryr(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_ryr(:).ampY]), 1);...
%        1*ones(length([jdot0F_ryr(:).ampY]), 1);...       
%        2*ones(length([idot0F_ryr(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] J_{RyR} (nM/ms)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ryr_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ryr(:).dad_ampY],...
%       [jdot0F_ryr(:).dad_ampY],...
%       [idot0F_ryr(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ryr(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ryr(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ryr(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{RyR} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ryr_ampdad'),'-dtiff','-r300')
% close
% 
%% bp serca
% figure(7)
% bx = [[owtF_serca(:).ampY],...
%       [jdot0F_serca(:).ampY],...
%       [idot0F_serca(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_serca(:).ampY]), 1);...
%        1*ones(length([jdot0F_serca(:).ampY]), 1);...       
%        2*ones(length([idot0F_serca(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] J_{SERCA} (nM/ms)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_serca_amp'),'-dtiff','-r300')
% close

% figure(7)
% bx = [[owtF_serca(:).dad_ampY],...
%       [jdot0F_serca(:).dad_ampY],...
%       [idot0F_serca(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_serca(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_serca(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_serca(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{SERCA} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_serca_ampdad'),'-dtiff','-r300')
% close
% 
% %% bp cal
% figure(7)
% bx = [[owtF_cal(:).ampY],...
%       [jdot0F_cal(:).ampY],...
%       [idot0F_cal(:).ampY],...
%       ] 
% by = [ zeros(length([owtF_cal(:).ampY]), 1);...
%        1*ones(length([jdot0F_cal(:).ampY]), 1);...       
%        2*ones(length([idot0F_cal(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{CaL} of','Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_cal_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_cal(:).dad_ampY],...
%       [jdot0F_cal(:).dad_ampY],...
%       [idot0F_cal(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_cal(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_cal(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_cal(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% % ax = gca;
% % ax.YAxis.Exponent = 0.01;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{CaL} of','DAD Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_cal_ampdad'),'-dtiff','-r300')
% close
% 

%% bp ncx integral 
% figure(7)
% bx = [[owtF_ncx(:).integralY],...
%       [jdot0F_ncx(:).integralY],...
%       [idot0F_ncx(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_ncx(:).integralY]), 1);...
%        1*ones(length([jdot0F_ncx(:).integralY]), 1);...       
%        2*ones(length([idot0F_ncx(:).integralY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'NCX [Ca] (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_intergralbeat'),'-dtiff','-r300')
% close

%% bp ncx
% figure(7)
% bx = [[owtF_ncx(:).ampY],...
%       [jdot0F_ncx(:).ampY],...
%       [idot0F_ncx(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_ncx(:).ampY]), 1);...
%        1*ones(length([jdot0F_ncx(:).ampY]), 1);...       
%        2*ones(length([idot0F_ncx(:).ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% % ax = gca;
% % ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] I_{NCX} (pA/pF)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ncx(:).dad_ampY],...
%       [jdot0F_ncx(:).dad_ampY],...
%       [idot0F_ncx(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ncx(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ncx(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ncx(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'WT','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 0.01;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{NCX} of','DAD Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_ampdad'),'-dtiff','-r300')
% close
% 
% %% pcc amp
% 
% %%
% figure(20)
% x = [[owt(:).y38_ampY]',[owt(:).y38_dad_ampY]'];
% 
% y = [[owtF_serca(:).ampY]',[owtF_serca(:).dad_ampY]',...
%      [owtF_ryr(:).ampY]',[owtF_ryr(:).dad_ampY]',...
%      [owtF_ls2j(:).ampY]',[owtF_ls2j(:).dad_ampY]',...
%      [owtF_ls2i(:).ampY]',[owtF_ls2i(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF_iflux'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampY]',[jdot0(:).y38_dad_ampY]'];
% 
% y = [[jdot0F_serca(:).ampY]',[jdot0F_serca(:).dad_ampY]',...
%     [jdot0F_ryr(:).ampY]',[jdot0F_ryr(:).dad_ampY]',...
%      [jdot0F_ls2j(:).ampY]',[jdot0F_ls2j(:).dad_ampY]',...
%      [jdot0F_ls2i(:).ampY]',[jdot0F_ls2i(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F_iflux'),'-dtiff','-r300')
% close 
% 
% 
% figure(20)
% x = [[idot0(:).y38_ampY]',[idot0(:).y38_dad_ampY]'];
% 
% y = [[idot0F_serca(:).ampY]',[idot0F_serca(:).dad_ampY]',...
%     [idot0F_ryr(:).ampY]',[idot0F_ryr(:).dad_ampY]',...
%      [idot0F_ls2j(:).ampY]',[idot0F_ls2j(:).dad_ampY]',...
%      [idot0F_ls2i(:).ampY]',[idot0F_ls2i(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F_iflux'),'-dtiff','-r300')
% close 
% 
% %%
% figure(20)
% x = [[owt(:).y38_ampY]',[owt(:).y38_dad_ampY]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = [[owtF_cal(:).ampY]',[owtF_ls2j(:).ampY]',[owtF_ls2j(:).dad_ampY]',...
%     [owtF_ls2i(:).ampY]',[owtF_ls2i(:).dad_ampY]',...
%     [owtF_ryr(:).ampY]',[owtF_ryr(:).dad_ampY]',[owtF_serca(:).ampY]',[owtF_serca(:).dad_ampY]',...
%      [owtF_ncx(:).ampY]',[owtF_ncx(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampY]',[jdot0(:).y38_dad_ampY]',[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',...
%      ];
%  
% y = [[jdot0F_cal(:).ampY]',[jdot0F_ls2j(:).ampY]',[jdot0F_ls2j(:).dad_ampY]',...
%     [jdot0F_ls2i(:).ampY]',[jdot0F_ls2i(:).dad_ampY]',...
%     [jdot0F_ryr(:).ampY]',[jdot0F_ryr(:).dad_ampY]',[jdot0F_serca(:).ampY]',[jdot0F_serca(:).dad_ampY]',...
%      [jdot0F_ncx(:).ampY]',[jdot0F_ncx(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[idot0(:).y38_ampY]',[idot0(:).y38_dad_ampY]',[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',...
%      ];
% y = [[idot0F_cal(:).ampY]',[idot0F_ls2j(:).ampY]',[idot0F_ls2j(:).dad_ampY]',...
%     [idot0F_ls2i(:).ampY]',[idot0F_ls2i(:).dad_ampY]',...
%     [idot0F_ryr(:).ampY]',[idot0F_ryr(:).dad_ampY]',[idot0F_serca(:).ampY]',[idot0F_serca(:).dad_ampY]',...
%      [idot0F_ncx(:).ampY]',[idot0F_ncx(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F'),'-dtiff','-r300')
% close 
% 
% %% pcc T
% figure(20)
% x = [[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = [[owtF_cal(:).ampT]',[owtF_ls2j(:).ampT]',[owtF_ls2i(:).ampT]',...
%     [owtF_ryr(:).ampT]',[owtF_ryr(:).dad_ampT]',[owtF_serca(:).ampT]',[owtF_serca(:).dad_ampT]',...
%      [owtF_ncx(:).ampT]',[owtF_ncx(:).dad_ampT]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF_T'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',...
%      ];
% y = [[jdot0F_cal(:).ampT]',[jdot0F_ls2j(:).ampT]',[jdot0F_ls2i(:).ampT]',...
%     [jdot0F_ryr(:).ampT]',[jdot0F_ryr(:).dad_ampT]',[jdot0F_serca(:).ampT]',[jdot0F_serca(:).dad_ampT]',...
%      [jdot0F_ncx(:).ampT]',[jdot0F_ncx(:).dad_ampT]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F_T'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',...
%      ];
% y = [[idot0F_cal(:).ampT]',[idot0F_ls2j(:).ampT]',[idot0F_ls2i(:).ampT]',...
%     [idot0F_ryr(:).ampT]',[idot0F_ryr(:).dad_ampT]',[idot0F_serca(:).ampT]',[idot0F_serca(:).dad_ampT]',...
%      [idot0F_ncx(:).ampT]',[idot0F_ncx(:).dad_ampT]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F_T'),'-dtiff','-r300')
% close 

%% 100 10/39 0
% X = categorical({'WT','J_{ls,up} = 0','J_{ls,rel} = 0'});
% X = reordercats(X,{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'});
% Y = [100 26 0];
% b= bar(X,Y);
% % b(1).FaceColor = [0 0 1];
% % b(2).FaceColor = [1 0 1];
% % b(3).FaceColor = [1 0 0];
% % text(1:length(Y),Y,num2str(Y'),'vert','bottom','horiz','center'); 
% 
% ax = gca;
% ax. Position = [0.25 0.2 0.7 0.7];
% % ax.YAxis.Exponent = 5;
% % legend([c(3);c(2);c(1)],'WT','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Percentage of Arrhythmic Models','in TPC-specific Category'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 700])
% print(gcf, fullfile(pwd, 'ba_hy'),'-dtiff','-r300')
% % close