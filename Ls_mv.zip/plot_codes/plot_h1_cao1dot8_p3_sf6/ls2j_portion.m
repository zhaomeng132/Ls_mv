function Fpeak = ls2j_portion(T,Y,rate1,rate2)

[TFmax3w,~] = islocalmax(abs(Y),'MinProminence',max(abs(Y))/rate1);
[TFmin3w,~] = islocalmin(abs(Y),'MinProminence',max(abs(Y))/rate2);
peakidx = find(TFmax3w);
valleyidx = find(TFmin3w);
valleyidx = valleyidx(find(valleyidx> peakidx(1) & valleyidx< peakidx(2)));% in between two peakidx localmax

Fpeak.peakidx = peakidx;
Fpeak.valleyidx = valleyidx;

Fpeak.balanceidx = valleyidx;
Fpeak.ls2jin = trapz(T(1:valleyidx), Y(1:valleyidx));
Fpeak.ls2jout = trapz(T(valleyidx:end), Y(valleyidx:end));

[~,iminY] = min(Y);
[~,imaxY] = max(Y);

[~,ibalanceY]= min(Y(iminY:imaxY) - Y(1));
balanceidx = valleyidx+ibalanceY-1;
Fpeak.dbalanceidx = balanceidx;
Fpeak.dls2jin = trapz(T(1:balanceidx), Y(1:balanceidx));
Fpeak.dls2jout = trapz(T(balanceidx:end), Y(balanceidx:end));


end