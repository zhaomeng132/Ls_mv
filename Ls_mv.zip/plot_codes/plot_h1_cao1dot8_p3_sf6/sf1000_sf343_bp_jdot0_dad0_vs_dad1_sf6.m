clear all
close all
addpath('~/downloads/SS/Ls_mv_sf6/plot_h1_cao1dot8_p3_sf6')
% load SS
cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat

cd ~/downloads/SS/Ls_mv_sf6
load cao1dot8_iTPC_1_jdot_0.mat
jdot0_0 = cao1dot8_iTPC_1_jdot_0;
load cao1dot8_iTPC_1_jdot_1.mat
jdot0_1 = cao1dot8_iTPC_1_jdot_1;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
Swt = S(h1_cao1_sf1000_sf6_0);
% S = S(sf343_0);
% Swt = S;
Swt_jd0 = Swt(jdot0_0);
Swt_jd1 = Swt(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
Sjdot0 = S(h1_cao1_sf1000_sf6_0);
% S = S(sf343_0);
% Sjdot0 = S;
Sjdot0_jd0 = Sjdot0(jdot0_0);
Sjdot0_jd1 = Sjdot0(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
Sidot0 = S(h1_cao1_sf1000_sf6_0);
% S = S(sf343_0);
% Sidot0 = S;
Sidot0_jd0 = Sidot0(jdot0_0);
Sidot0_jd1 = Sidot0(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_herz1_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
Fwt = F(h1_cao1_sf1000_sf6_0);
% F = F(sf343_0);
% Fwt = F;
Fwt_jd0 = Fwt(jdot0_0);
Fwt_jd1 = Fwt(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_j_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
Fjdot0 = F(h1_cao1_sf1000_sf6_0);
% F = F(sf343_0);
% Fjdot0 = F;
Fjdot0_jd0 = Fjdot0(jdot0_0);
Fjdot0_jd1 = Fjdot0(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_i_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
Fidot0 = F(h1_cao1_sf1000_sf6_0);
% F = F(sf343_0); 
% Fidot0 = F;
Fidot0_jd0 = Fidot0(jdot0_0);
Fidot0_jd1 = Fidot0(jdot0_1);

cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','figs1'])
cd(['./','figs1'])

%% multivariable partialcorri
rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                     % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
sf = sf(h1_cao1_sf1000_sf6_0,:);


sf_0 = sf(jdot0_0,:);
sf_1 = sf(jdot0_1,:);



bx = [
     sf_0(:,1)',sf_1(:,1)'...
     sf_0(:,2)',sf_1(:,2)'...
     sf_0(:,3)',sf_1(:,3)'...
     sf_0(:,4)',sf_1(:,4)'...
     sf_0(:,5)',sf_1(:,5)'...
     sf_0(:,6)',sf_1(:,6)'...
     sf_0(:,7)',sf_1(:,7)'...
     sf_0(:,8)',sf_1(:,8)'...
     sf_0(:,9)',sf_1(:,9)'...
     ];
by = [ zeros(length(sf_0), 1);1*ones(length([sf_1]), 1);2*ones(length([sf_0]), 1);... 
       3*ones(length([sf_1]), 1);4*ones(length([sf_0]), 1);5*ones(length([sf_1]), 1);... 
       6*ones(length([sf_0]), 1);7*ones(length([sf_1]), 1);8*ones(length([sf_0]), 1);... 
       9*ones(length([sf_1]), 1);10*ones(length([sf_0]), 1);11*ones(length([sf_1]), 1);...
       12*ones(length([sf_0]), 1);13*ones(length([sf_1]), 1);14*ones(length([sf_0]), 1);... 
       15*ones(length([sf_1]), 1);16*ones(length([sf_0]), 1);17*ones(length([sf_1]), 1);...
     ];
figure(1);
boxplot(bx,by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
ylabel({'Variations of Conductances'})
ylim([0.25 3])

set(gca,'TickLabelInterpreter','Tex')
lbl= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
set(gca,'xticklabel',lbl)
set(gca,'xtick',1.5:2:18.5)
set(gca,'ytick',0.5:0.5:2)
set(gca,'box','off');

% ax = gca;
% ax. Position = [0.2 0.2 0.7 0.7];

legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northeast');legend boxoff

set(gca, 'FontName','Times New Roman','FontSize',35)
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 1500 600])
print(gcf, fullfile(pwd, 'bp_cao1dot8'),'-dtiff','-r300')
% close


% ncx - cal
jdot0_0_ = median(sf_0(:,6)) - median(sf_0(:,7))
jdot0_1_ = median(sf_1(:,6)) - median(sf_1(:,7))

%% plot y38
% for ipeak = 1: numel(Swt)    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,38).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,38).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,38).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on 
% end
% 
% linkaxes([ax2,ax4,ax6],'y');
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% % title({'Hypercalcemia and ISO, WT_{}',''});
% title({' ',' '})
%     ax = gca;
% ax.YAxis.Exponent = 2;
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
% f61 = figure(61);
% ax4 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% % title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
% title({' ',' '})
%     ax = gca;
% ax.YAxis.Exponent = 2;
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
% f62 = figure(62);
% ax6= subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
% % title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
% title({' ',' '})
%     ax = gca;
% ax.YAxis.Exponent = 2;
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
%       
% print(f60, fullfile(pwd, 'swt_y38'),'-dtiff','-r300');
% print(f61, fullfile(pwd, 'Sjdot0_y38'),'-dtiff','-r300');
% print(f62, fullfile(pwd, 'Sidot0_y38'),'-dtiff','-r300');
% 
% close all    
% 
% %% plot y88
% for ipeak = 1: numel(Swt)    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(Swt(ipeak).t,Swt(ipeak).y(:,88).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(Sjdot0(ipeak).t,Sjdot0(ipeak).y(:,88).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(Sidot0(ipeak).t,Sidot0(ipeak).y(:,88).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on               
% end
%     
% linkaxes([ax2,ax4,ax6],'y');
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, WT_{ }',' '});  
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
% f61 = figure(61);
% ax4 = subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
% f62 = figure(62);
% ax6= subplot(1,1,1);ylabel('[Ca] Lysosome (nM)');xlabel('Time (ms)');
%     title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% 
% print(f60, fullfile(pwd, 'swt_y88'),'-dtiff','-r300');
% print(f61, fullfile(pwd, 'Sjdot0_y88'),'-dtiff','-r300');
% print(f62, fullfile(pwd, 'Sidot0_y88'),'-dtiff','-r300');
% 
% close all    
% 
%% plot y31
% for ipeak = 1: numel(Swt_jd1)    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(Swt_jd1(ipeak).t,Swt_jd1(ipeak).y(:,31).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(Sjdot0_jd1(ipeak).t,Sjdot0_jd1(ipeak).y(:,31).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(Sidot0_jd1(ipeak).t,Sidot0_jd1(ipeak).y(:,31).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on               
% end
%     
% linkaxes([ax2,ax4,ax6],'y');
% f60 = figure(60);
% ax2 = subplot(1,1,1);
%     ylabel('[Ca] SR (nM)');xlabel('Time (ms)'); 
% %     title({'Hypercalcemia and ISO, CTRL',''});  
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
% f61 = figure(61);
% ax4 = subplot(1,1,1);
% 
%     ylabel('[Ca] SR (nM)');xlabel('Time (ms)'); 
% %     title({'Hypercalcemia and ISO, J_{ls,up} = 0',''});
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
% f62 = figure(62);
% ax6= subplot(1,1,1);
%     ylabel('[Ca] SR (nM)');xlabel('Time (ms)');
% %     title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% 
% print(f60, fullfile(pwd, 'swt_y31'),'-dtiff','-r300');
% print(f61, fullfile(pwd, 'Sjdot0_y31'),'-dtiff','-r300');
% print(f62, fullfile(pwd, 'Sidot0_y31'),'-dtiff','-r300');
% 
% close all   
% % 
%% plot y36
% for ipeak = 2:2% numel(Swt_jd1)    
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(Swt_jd1(ipeak).t,Swt_jd1(ipeak).y(:,36).*1e6,'Color','#000000'); %p1.Color(1) = 1;%  38 cytosolic space
%     hold on
%     figure(61)
%     ax4 = subplot(1,1,1);
%     p2 = plot(Sjdot0_jd1(ipeak).t,Sjdot0_jd1(ipeak).y(:,36).*1e6,'Color','#000000'); %p2.Color(2) = 1;%  38 cytosolic space
%     hold on
%     figure(62)
%     ax6 = subplot(1,1,1);
%     p3 = plot(Sidot0_jd1(ipeak).t,Sidot0_jd1(ipeak).y(:,36).*1e6,'Color','#000000'); %p3.Color(3) = 1;%  38 cytosolic space
%     hold on               
% end
%     
% linkaxes([ax2,ax4,ax6],'y');
% f60 = figure(60);
% ax2 = subplot(1,1,1);
%     ylabel('[Ca] Junction (nM)');xlabel('Time (ms)'); 
% %     title({'Hypercalcemia and ISO, CTRL',''});  
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
% 
% f61 = figure(61);
% ax4 = subplot(1,1,1);
% 
%     ylabel('[Ca] Junction (nM)');xlabel('Time (ms)'); 
% %     title({'Hypercalcemia and ISO, J_{ls2j}=0',''});
%     set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35);
%     set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f61,'type','axes'),'box','off')
%     set(f61,'Units','pixels','Position',[0 0 700 500])
% 
% f62 = figure(62);
% ax6= subplot(1,1,1);
%     ylabel('[Ca] Junction (nM)');xlabel('Time (ms)');
% %     title({'Hypercalcemia and ISO, J_{ls,rel} = 0',''});
%     set(findobj(f62,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f62, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f62,'type','axes'),'box','off')
%     set(f62,'Units','pixels','Position',[0 0 700 500])
% 
% print(f60, fullfile(pwd, 'swt_y36'),'-dtiff','-r300');
% print(f61, fullfile(pwd, 'Sjdot0_y36'),'-dtiff','-r300');
% print(f62, fullfile(pwd, 'Sidot0_y36'),'-dtiff','-r300');
% 
% close all   

%% biomarkers for Swt, Sjdot0, Sidot0

for ipeak = 1: numel(Swt_jd0) 

t3w0 = Swt_jd0(ipeak).t;
y3w0 = Swt_jd0(ipeak).y.*1e6;
% biomarkers for jd0
owt_y38_0(ipeak) = peakfinder(t3w0, y3w0(:,38),200,200);
owt_y88_0(ipeak) = peakfinder(t3w0, y3w0(:,88),200,200);
% owt_y31_0(ipeak) = srpeakfinder(t3w0, y3w0(:,31),200,200);
owt_y36_0(ipeak) = peakfinder(t3w0, y3w0(:,36),200,200);
owt_y37_0(ipeak) = peakfinder(t3w0, y3w0(:,37),200,200);

owt_y31_y36_0(ipeak) = y31_y36_peakfinder(t3w0, y3w0(:,31),200,200, y3w0(:,36));
end

for ipeak = 1: numel(Swt_jd1) 
t3w1 = Swt_jd1(ipeak).t;
y3w1 = Swt_jd1(ipeak).y.*1e6;
% biomarkers for jd1
owt_y38_1(ipeak) = peakfinder(t3w1, y3w1(:,38),200,200);
owt_y88_1(ipeak) = peakfinder(t3w1, y3w1(:,88),200,200);
% owt_y31_1(ipeak) = srpeakfinder(t3w1, y3w1(:,31),200,200);
owt_y36_1(ipeak) = peakfinder(t3w1, y3w1(:,36),200,200);
owt_y37_1(ipeak) = peakfinder(t3w1, y3w1(:,37),200,200);

owt_y31_y36_1(ipeak) = y31_y36_peakfinder(t3w1, y3w1(:,31),200,200, y3w1(:,36));
end


for ipeak = 1: numel(Sjdot0_jd0) 

t3w0 = Sjdot0_jd0(ipeak).t;
y3w0 = Sjdot0_jd0(ipeak).y.*1e6;

% biomarkers for Sjdot0_0
jdot0_y38_0(ipeak) = peakfinder(t3w0, y3w0(:,38),200,200);
jdot0_y88_0(ipeak) = peakfinder(t3w0, y3w0(:,88),200,200);
% jdot0_y31_0(ipeak) = srpeakfinder(t3w0, y3w0(:,31),200,200);
jdot0_y36_0(ipeak) = peakfinder(t3w0, y3w0(:,36),200,200);
jdot0_y37_0(ipeak) = peakfinder(t3w0, y3w0(:,37),200,200);

jdot0_y31_y36_0(ipeak) = y31_y36_peakfinder(t3w0, y3w0(:,31),200,200, y3w0(:,36));
end

for ipeak = 1: numel(Sjdot0_jd1) 
t3w1 = Sjdot0_jd1(ipeak).t;
y3w1 = Sjdot0_jd1(ipeak).y.*1e6;

% biomarkers for Sjdot0_1
jdot0_y38_1(ipeak) = peakfinder(t3w1, y3w1(:,38),200,200);
jdot0_y88_1(ipeak) = peakfinder(t3w1, y3w1(:,88),200,200);
% jdot0_y31_1(ipeak) = srpeakfinder(t3w1, y3w1(:,31),200,200);
jdot0_y36_1(ipeak) = peakfinder(t3w1, y3w1(:,36),200,200);
jdot0_y37_1(ipeak) = peakfinder(t3w1, y3w1(:,37),200,200);

jdot0_y31_y36_1(ipeak) = y31_y36_peakfinder(t3w1, y3w1(:,31),200,200, y3w1(:,36));
end

for ipeak = 1: numel(Sidot0_jd0) 

t3w0 = Sidot0_jd0(ipeak).t;
y3w0 = Sidot0_jd0(ipeak).y.*1e6;

% biomarkers for Sidot0_0
idot0_y38_0(ipeak) = peakfinder(t3w0, y3w0(:,38),200,200);
idot0_y88_0(ipeak) = peakfinder(t3w0, y3w0(:,88),200,200);
% idot0_y31_0(ipeak) = srpeakfinder(t3w0, y3w0(:,31),200,200);
idot0_y36_0(ipeak) = peakfinder(t3w0, y3w0(:,36),200,200);
idot0_y37_0(ipeak) = peakfinder(t3w0, y3w0(:,37),200,200);

idot0_y31_y36_0(ipeak) = y31_y36_peakfinder(t3w0, y3w0(:,31),200,200, y3w0(:,36));
end

for ipeak = 1: numel(Sidot0_jd1) 
t3w1 = Sidot0_jd1(ipeak).t;
y3w1 = Sidot0_jd1(ipeak).y.*1e6;

% biomarkers for Sidot0_1
idot0_y38_1(ipeak) = peakfinder(t3w1, y3w1(:,38),200,200);
idot0_y88_1(ipeak) = peakfinder(t3w1, y3w1(:,88),200,200);
% idot0_y31_1(ipeak) = srpeakfinder(t3w1, y3w1(:,31),200,200);
idot0_y36_1(ipeak) = peakfinder(t3w1, y3w1(:,36),200,200);
idot0_y37_1(ipeak) = peakfinder(t3w1, y3w1(:,37),200,200);

idot0_y31_y36_1(ipeak) = y31_y36_peakfinder(t3w1, y3w1(:,31),200,200, y3w1(:,36));
end

%% boxplot
%% y31 sum
close all
figure(8)
bx = [
      [owt_y31_y36_0(:).sumY],...
      [owt_y31_y36_1(:).sumY],...
      [jdot0_y31_y36_0(:).sumY],...
      [jdot0_y31_y36_1(:).sumY],...
      [idot0_y31_y36_0(:).sumY],... 
      [idot0_y31_y36_1(:).sumY],...                              
      ]; 
by = [ zeros(length([owt_y31_y36_0(:).sumY]), 1);...
       1*ones(length([owt_y31_y36_1(:).sumY]), 1);...       
       2*ones(length([jdot0_y31_y36_0(:).sumY]), 1);...
       3*ones(length([jdot0_y31_y36_1(:).sumY]), 1);...       
       4*ones(length([idot0_y31_y36_0(:).sumY]), 1);...
       5*ones(length([idot0_y31_y36_1(:).sumY]), 1);...             
       ];

boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%5
ax.YAxis.Exponent = 7;
ylim([1e7 24e7])
ylabel({'[Ca] SR (nM)'})

legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)

title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y31_5'),'-dtiff','-r300')
% close
%% y31-y36 sum
close all
figure(8)
bx = [
      [owt_y31_y36_0(:).sum_y31_y36],...
      [owt_y31_y36_1(:).sum_y31_y36],...
      [jdot0_y31_y36_0(:).sum_y31_y36],...
      [jdot0_y31_y36_1(:).sum_y31_y36],...
      [idot0_y31_y36_0(:).sum_y31_y36],... 
      [idot0_y31_y36_1(:).sum_y31_y36],...                              
      ]; 
by = [ zeros(length([owt_y31_y36_0(:).sum_y31_y36]), 1);...
       1*ones(length([owt_y31_y36_1(:).sum_y31_y36]), 1);...       
       2*ones(length([jdot0_y31_y36_0(:).sum_y31_y36]), 1);...
       3*ones(length([jdot0_y31_y36_1(:).sum_y31_y36]), 1);...       
       4*ones(length([idot0_y31_y36_0(:).sum_y31_y36]), 1);...
       5*ones(length([idot0_y31_y36_1(:).sum_y31_y36]), 1);...             
       ];

boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
%5
ax.YAxis.Exponent = 7;
ylim([1e7 24e7])

legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Difference', 'of Junction and SR (nM)'})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y36-y31_5'),'-dtiff','-r300')
% close

%% median 
% y3136_median_wt = median([abs([owt_y31(:).sumY] - [owt_y36(:).sumY])])
% y3136_median_jdot0 = median([abs([jdot0_y31(:).sumY] - [jdot0_y36(:).sumY])])
% y3136_median_idot0 = median([abs([idot0_y31(:).sumY] - [idot0_y36(:).sumY])])
% 
% y31_median_wt = median([owt_y31(:).sumY])
% y31_median_jdot0 = median([jdot0_y31(:).sumY])
% y31_median_idot0 = median([idot0_y31(:).sumY])
%% y36 sum
close all
figure(7)
bx = [
      [owt_y36_0(:).sumY],...
      [owt_y36_1(:).sumY],...
      [jdot0_y36_0(:).sumY],...
      [jdot0_y36_1(:).sumY],...
      [idot0_y36_0(:).sumY],... 
      [idot0_y36_1(:).sumY],... 
      ];
by = [ zeros(length([owt_y36_0(:).sumY]), 1);...
       1*ones(length([owt_y36_1(:).sumY]), 1);...       
       2*ones(length([jdot0_y36_0(:).sumY]), 1);...
       3*ones(length([jdot0_y36_1(:).sumY]), 1);...       
       4*ones(length([idot0_y36_0(:).sumY]), 1);...
       5*ones(length([idot0_y36_1(:).sumY]), 1);...             
       ];
   
boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff

ylim([0e6 14e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y36_5'),'-dtiff','-r300')

%% y88 sum
close all
figure(7)
bx = [
      [owt_y88_0(:).sumY],...
      [owt_y88_1(:).sumY],...
      [jdot0_y88_0(:).sumY],...
      [jdot0_y88_1(:).sumY],...
      [idot0_y88_0(:).sumY],... 
      [idot0_y88_1(:).sumY],... 
      ];
by = [ zeros(length([owt_y88_0(:).sumY]), 1);...
       1*ones(length([owt_y88_1(:).sumY]), 1);...       
       2*ones(length([jdot0_y88_0(:).sumY]), 1);...
       3*ones(length([jdot0_y88_1(:).sumY]), 1);...       
       4*ones(length([idot0_y88_0(:).sumY]), 1);...
       5*ones(length([idot0_y88_1(:).sumY]), 1);...             
       ];
   
boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
 
ylim([-0.5e6 5e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Lysosome (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'y88_5'),'-dtiff','-r300')
%%            1        2     3       4         5     6       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i]; 
% close all
% Y = [1 2 3 4 5 6];
% Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}'};
% Yscale = [1 1 1e6 1e6 1e6 1e6]; 
% Yaxis = [1 -1 2 4 4 3];
% Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)'};
% 
% for SP = 2: 2%numel(Y)
% for idad = 2: 2%numel(Fwt_jd1)
%     
%     figure(1);ax1 = subplot(1,1,1);
%     p1 =plot(Fwt_jd1(idad).tArray,Fwt_jd1(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
%     figure(2);ax2 = subplot(1,1,1);
%     p2 =plot(Fidot0_jd1(idad).tArray,Fidot0_jd1(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
%     figure(3);ax3 = subplot(1,1,1);
%     p3 =plot(Fjdot0_jd1(idad).tArray,Fjdot0_jd1(idad).currents(:,Y(SP)).*Yscale(SP),'Color','#000000');
%     hold on
%     
% 
% end
% linkaxes([ax1,ax2,ax3],'y');
% fontsize = 35;
% 
% f1 = figure(1);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP ==3
% title({'Hypercalcemia and ISO, WT_{ }',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f1,'Units','pixels','Position',[0 0 700 500])
% print(f1, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s wt',Yspace{SP})),'-dtiff','-r300');
% 
% f2 = figure(2);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');  
% if SP ==3
% title({'Hypercalcemia and ISO, J_{ls,rel} = 0',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f2,'Units','pixels','Position',[0 0 700 500])
% print(f2, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s idot0',Yspace{SP})),'-dtiff','-r300');
% 
% f3 = figure(3);subplot(1,1,1); 
% ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');     
% if SP ==3
% title({'Hypercalcemia and ISO, J_{ls,up} = 0',' '});
% else
% title({' ',' '})
% end
%                ax = gca;
%                ax.YAxis.Exponent = Yaxis(SP);
%                set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
%                set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
%                set(findobj(gcf,'type','axes'),'box','off')
%                set(f3,'Units','pixels','Position',[0 0 700 500])
% print(f3, fullfile(pwd, sprintf('h1_cao1dot8_wyon %s jdot0',Yspace{SP})),'-dtiff','-r300');
% 
% close all
% end
              
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
for ipeak = 1: numel(Fwt_jd0)
   
tflux = Fwt_jd0(ipeak).tArray;
yserca = Fwt_jd0(ipeak).Jserca.*1e6;    
yryr = Fwt_jd0(ipeak).J_RyR.*1e6;  

ycal = abs(Fwt_jd0(ipeak).I_Ca_store);    
yncx = Fwt_jd0(ipeak).Incx;    
yls2j = abs(Fwt_jd0(ipeak).JLS2J.*1e6); 

yls2i = Fwt_jd0(ipeak).JLS2I.*1e6;  

owtF_serca_0(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_0(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_0(ipeak) = peakfinder(tflux,ycal,2,2);
owtF_ls2j_0(ipeak) = peakfinder(tflux,yls2j,200,200);
owtF_ls2i_0(ipeak) = peakfinder(tflux,yls2i,200,200);
owtF_ncx_0(ipeak) = peakfinder(tflux,yncx,2,2);

owtF_juncx_0(ipeak) = peakfinder(tflux,Fwt_jd0(ipeak).currents(:,11),2,2);
owtF_jucal_0(ipeak) = peakfinder(tflux,Fwt_jd0(ipeak).currents(:,9),2,2);
end
% biomarker Fwt_jd1
for ipeak = 1: numel(Fwt_jd1)
   
tflux = Fwt_jd1(ipeak).tArray;
yserca = Fwt_jd1(ipeak).Jserca.*1e6;    
yryr = Fwt_jd1(ipeak).J_RyR.*1e6;  

ycal = abs(Fwt_jd1(ipeak).I_Ca_store);    
yncx = abs(Fwt_jd1(ipeak).Incx);    
yls2j = abs(Fwt_jd1(ipeak).JLS2J.*1e6); 

yls2i = Fwt_jd1(ipeak).JLS2I.*1e6;  

owtF_serca_1(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_1(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_1(ipeak) = peakfinder(tflux,ycal,2,2);
owtF_ls2j_1(ipeak) = peakfinder(tflux,yls2j,200,200);
owtF_ls2i_1(ipeak) = peakfinder(tflux,yls2i,200,200);
owtF_ncx_1(ipeak) = peakfinder(tflux,yncx,2,2);

owtF_juncx_1(ipeak) = peakfinder(tflux,Fwt_jd1(ipeak).currents(:,11),2,2);
owtF_jucal_1(ipeak) = peakfinder(tflux,Fwt_jd1(ipeak).currents(:,9),2,2);
end

%biomarker oidot0_jd0
for ipeak = 1: numel(Fidot0_jd0)
   
tflux = Fidot0_jd0(ipeak).tArray;
yserca = Fidot0_jd0(ipeak).Jserca.*1e6;    
yryr = Fidot0_jd0(ipeak).J_RyR.*1e6;   

ycal = abs(Fidot0_jd0(ipeak).I_Ca_store);    
yncx = abs(Fidot0_jd0(ipeak).Incx);    
yls2j = abs(Fidot0_jd0(ipeak).JLS2J.*1e6);    

yls2i = Fidot0_jd0(ipeak).JLS2I.*1e6;  

idot0F_serca_0(ipeak) = peakfinder(tflux,yserca,200,200);
idot0F_ryr_0(ipeak) = peakfinder(tflux,yryr,200,200);
idot0F_cal_0(ipeak) = peakfinder(tflux,ycal,2,2);
idot0F_ls2j_0(ipeak) = peakfinder(tflux,yls2j,200,200);
idot0F_ls2i_0(ipeak) = peakfinder(tflux,yls2i,200,200);
idot0F_ncx_0(ipeak) = peakfinder(tflux,yncx,2,2);

idot0F_juncx_0(ipeak) = peakfinder(tflux,Fidot0_jd0(ipeak).currents(:,11),2,2);
idot0F_jucal_0(ipeak) = peakfinder(tflux,Fidot0_jd0(ipeak).currents(:,9),2,2);
end 

% biomarker oidot0_jd1
for ipeak = 1: numel(Fidot0_jd1)
   
tflux = Fidot0_jd1(ipeak).tArray;
yserca = Fidot0_jd1(ipeak).Jserca.*1e6;    
yryr = Fidot0_jd1(ipeak).J_RyR.*1e6;   

ycal = abs(Fidot0_jd1(ipeak).I_Ca_store);    
yncx = abs(Fidot0_jd1(ipeak).Incx);    
yls2j = abs(Fidot0_jd1(ipeak).JLS2J.*1e6);    

yls2i = Fidot0_jd1(ipeak).JLS2I.*1e6;  

idot0F_serca_1(ipeak) = peakfinder(tflux,yserca,200,200);
idot0F_ryr_1(ipeak) = peakfinder(tflux,yryr,200,200);
idot0F_cal_1(ipeak) = peakfinder(tflux,ycal,2,2);
idot0F_ls2j_1(ipeak) = peakfinder(tflux,yls2j,200,200);
idot0F_ls2i_1(ipeak) = peakfinder(tflux,yls2i,200,200);
idot0F_ncx_1(ipeak) = peakfinder(tflux,yncx,2,2);

idot0F_juncx_1(ipeak) = peakfinder(tflux,Fidot0_jd1(ipeak).currents(:,11),2,2);
idot0F_jucal_1(ipeak) = peakfinder(tflux,Fidot0_jd1(ipeak).currents(:,9),2,2);
end 

% biomarker ojdot0_jd0
for ipeak = 1: numel(Fjdot0_jd0)
   
tflux = Fjdot0_jd0(ipeak).tArray;
yserca = Fjdot0_jd0(ipeak).Jserca.*1e6;    
yryr = Fjdot0_jd0(ipeak).J_RyR.*1e6; 

ycal = abs(Fjdot0_jd0(ipeak).I_Ca_store);    
yncx = abs(Fjdot0_jd0(ipeak).Incx);    
yls2j = abs(Fjdot0_jd0(ipeak).JLS2J.*1e6);    

yls2i = Fjdot0_jd0(ipeak).JLS2I.*1e6;  

jdot0F_serca_0(ipeak) = peakfinder(tflux,yserca,200,200);
jdot0F_ryr_0(ipeak) = peakfinder(tflux,yryr,200,200);
jdot0F_cal_0(ipeak) = peakfinder(tflux,ycal,2,2);
jdot0F_ls2j_0(ipeak) = peakfinder(tflux,yls2j,200,200);
jdot0F_ls2i_0(ipeak) = peakfinder(tflux,yls2i,200,200);
jdot0F_ncx_0(ipeak) = peakfinder(tflux,yncx,2,2);

jdot0F_juncx_0(ipeak) = peakfinder(tflux,Fjdot0_jd0(ipeak).currents(:,11),2,2);
jdot0F_jucal_0(ipeak) = peakfinder(tflux,Fjdot0_jd0(ipeak).currents(:,9),2,2);
end
% biomarker ojdot0_jd1
for ipeak = 1: numel(Fjdot0_jd1)
   
tflux = Fjdot0_jd1(ipeak).tArray;
yserca = Fjdot0_jd1(ipeak).Jserca.*1e6;    
yryr = Fjdot0_jd1(ipeak).J_RyR.*1e6; 

ycal = abs(Fjdot0_jd1(ipeak).I_Ca_store);    
yncx = abs(Fjdot0_jd1(ipeak).Incx);    
yls2j = abs(Fjdot0_jd1(ipeak).JLS2J.*1e6);    

yls2i = Fjdot0_jd1(ipeak).JLS2I.*1e6;  

jdot0F_serca_1(ipeak) = peakfinder(tflux,yserca,200,200);
jdot0F_ryr_1(ipeak) = peakfinder(tflux,yryr,200,200);
jdot0F_cal_1(ipeak) = peakfinder(tflux,ycal,2,2);
jdot0F_ls2j_1(ipeak) = peakfinder(tflux,yls2j,200,200);
jdot0F_ls2i_1(ipeak) = peakfinder(tflux,yls2i,200,200);
jdot0F_ncx_1(ipeak) = peakfinder(tflux,yncx,2,2);

jdot0F_juncx_1(ipeak) = peakfinder(tflux,Fjdot0_jd1(ipeak).currents(:,11),2,2);
jdot0F_jucal_1(ipeak) = peakfinder(tflux,Fjdot0_jd1(ipeak).currents(:,9),2,2);
end
%% median 
% serca_median_wt = median([owtF_serca(:).integralY])
% serca_median_jdot0 = median([jdot0F_serca(:).integralY])
% serca_median_idot0 = median([idot0F_serca(:).integralY])
%% bp jucal
close all
figure(7)
bx = [
      [owtF_jucal_0(:).integralY],...
      [owtF_jucal_1(:).integralY],...
      [jdot0F_jucal_0(:).integralY],...
      [jdot0F_jucal_1(:).integralY],...
      [idot0F_jucal_0(:).integralY],...
      [idot0F_jucal_1(:).integralY],...
      ]; 
by = [ zeros(length([owtF_jucal_0(:).integralY]), 1);...
       1*ones(length([owtF_jucal_1(:).integralY]), 1);...       
       2*ones(length([jdot0F_jucal_0(:).integralY]), 1);...
       3*ones(length([jdot0F_jucal_1(:).integralY]), 1);...       
       4*ones(length([idot0F_jucal_0(:).integralY]), 1);...
       5*ones(length([idot0F_jucal_1(:).integralY]), 1);...
       ];
   
boxplot(abs(bx), by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff

ylim([4e1 90e1])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'Junctional L-type','[Ca] Current (pA/pF)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'jucal'),'-dtiff','-r300')
% close
% %% bp juncx
% figure(7)
% bx = [
%       [owtF_juncx_0(:).integralY],...
%       [owtF_juncx_1(:).integralY],...
%       [jdot0F_juncx_0(:).integralY],...
%       [jdot0F_juncx_1(:).integralY],...
%       [idot0F_juncx_0(:).integralY],...
%       [idot0F_juncx_1(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx_0(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_0(:).integralY]), 1);...
%        3*ones(length([owtF_juncx_1(:).integralY]), 1);...       
%        4*ones(length([owtF_juncx_0(:).integralY]), 1);...
%        5*ones(length([owtF_juncx_1(:).integralY]), 1);...
%        ];
%    
% boxplot(abs(bx), by,'Notch','on','Colors','br');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 1;
% legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
% 
% ylim([5e1 20e1])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional NCX','Current (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'juncx'),'-dtiff','-r300')
% % close
%% bp integral serca over a beat
close all
figure(7)
bx = [
      [owtF_serca_0(:).integralY],...
      [owtF_serca_1(:).integralY],...
      [jdot0F_serca_0(:).integralY],...
      [jdot0F_serca_1(:).integralY],...
      [idot0F_serca_0(:).integralY],...
      [idot0F_serca_1(:).integralY],...
      ]; 
by = [ zeros(length([owtF_serca_0(:).integralY]), 1);...
       1*ones(length([owtF_serca_1(:).integralY]), 1);...       
       2*ones(length([owtF_serca_0(:).integralY]), 1);...
       3*ones(length([owtF_serca_1(:).integralY]), 1);...       
       4*ones(length([owtF_serca_0(:).integralY]), 1);...
       5*ones(length([owtF_serca_1(:).integralY]), 1);...
       ];
   
boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1.5:2:5.5)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff

ylim([4e4 25e4])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'serca'),'-dtiff','-r300')


%% bp integral ryr over a beat
close all
figure(7)
bx = [
      [owtF_ryr_0(:).integralY],...
      [owtF_ryr_1(:).integralY],...
      [jdot0F_ryr_0(:).integralY],...
      [jdot0F_ryr_1(:).integralY],...
      [idot0F_ryr_0(:).integralY],...
      [idot0F_ryr_1(:).integralY],...
      ]; 
  
by = [ zeros(length([owtF_ryr_0(:).integralY]), 1);...
       1*ones(length([owtF_ryr_1(:).integralY]), 1);...       
       2*ones(length([owtF_ryr_0(:).integralY]), 1);...
       3*ones(length([owtF_ryr_1(:).integralY]), 1);...       
       4*ones(length([owtF_ryr_0(:).integralY]), 1);...
       5*ones(length([owtF_ryr_1(:).integralY]), 1);...
       ];

boxplot(bx, by,'Notch','on','Colors','br');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:2:6)
set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff

ylim([0.5e6 5e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf, fullfile(pwd, 'ryr'),'-dtiff','-r300')
close
% %% bp integral cal over a beat
% figure(7)
% bx = [
%       [owtF_cal_0(:).integralY],...
%       [owtF_cal_1(:).integralY],...
%       [jdot0F_cal_0(:).integralY],...
%       [jdot0F_cal_1(:).integralY],...
%       [idot0F_cal_0(:).integralY],...
%       [idot0F_cal_1(:).integralY],...
%       ]; 
%   
% by = [ zeros(length([owtF_cal_0(:).integralY]), 1);...
%        1*ones(length([owtF_cal_1(:).integralY]), 1);...       
%        2*ones(length([owtF_cal_0(:).integralY]), 1);...
%        3*ones(length([owtF_cal_1(:).integralY]), 1);...       
%        4*ones(length([owtF_cal_0(:).integralY]), 1);...
%        5*ones(length([owtF_cal_1(:).integralY]), 1);...
%        ];
%  
% boxplot(bx, by,'Notch','on','Colors','br');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:2:6)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
%  
% ylim([1.5e2 5e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'L-type Current (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'bp_cal_integralbeat'),'-dtiff','-r300')
% close

%% bp integral ryr- serca over a beat
% figure(7)
% bx = [
%       [[owtF_ryr_0(:).integralY] - [owtF_serca_0(:).integralY]],...
%       [[owtF_ryr_1(:).integralY] - [owtF_serca_1(:).integralY]],...
%       [[jdot0F_ryr_0(:).integralY] - [jdot0F_serca_0(:).integralY]],...
%       [[jdot0F_ryr_1(:).integralY] - [jdot0F_serca_1(:).integralY]],...
%       [[idot0F_ryr_0(:).integralY] - [idot0F_serca_0(:).integralY]],...
%       [[idot0F_ryr_1(:).integralY] - [idot0F_serca_1(:).integralY]],...
%       ]; 
%   
% by = [ zeros(length([owtF_serca_0(:).integralY]), 1);...
%        1*ones(length([owtF_serca_1(:).integralY]), 1);...       
%        2*ones(length([owtF_serca_0(:).integralY]), 1);...
%        3*ones(length([owtF_serca_1(:).integralY]), 1);...       
%        4*ones(length([owtF_serca_0(:).integralY]), 1);...
%        5*ones(length([owtF_serca_1(:).integralY]), 1);...
%        ];
% 
% boxplot(bx, by,'Notch','on','Colors','bk');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:2:6)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(2);c(1)],'No Spontaneous Release when J_{ls,up} = 0','Spontaneous Release when J_{ls,up} = 0','Location','northwest');legend boxoff
% 
% ylim([1e6 3.5e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Integral [Ca] SR Balance over','a Beat (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf, fullfile(pwd, 'bp_ryr-serca_integralbeat'),'-dtiff','-r300')
% close

%% plt serca ryr
% figure(7)
% plot([jdot0F_serca_0(:).integralY], [jdot0F_ryr_0(:).integralY],'b.','markersize',20)
% hold on
% plot([jdot0F_serca_1(:).integralY], [jdot0F_ryr_1(:).integralY],'k.','markersize',20)
% legend('No Spontaneous Release','Spontaneous Release','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'SERCA [Ca] Flux over a Beat (nM)'})
% xlabel({'RyR [Ca] Flux over a Beat (nM)'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 700])
% print(gcf, fullfile(pwd, 'baseline_int_y38'),'-dtiff','-r300')
% close
%% pcc serca
% figure(20)
% %% ctrl
% x = [[owtF_serca(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owtF_serca(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0F_serca(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0F_serca(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0F_serca(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0F_serca(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] of SERCA over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA over Peak}',...
%      '{CTRL} {Integral [Ca] SERCA over a Beat}',...
%      '{J_{ls2j} = 0} {Integral [Ca] SERCA over a Beat}',...
%      '{J_{ls2i} = 0} {Integral [Ca] SERCA over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_serca'),'-dtiff','-r300')
% close 

%% pcc serca-ryr
% figure(20)
% %% ctrl
% x = [[owtF_serca(:).peak_integralY]'-[owtF_ryr(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owtF_serca(:).integralY]'-[owtF_ryr(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0F_serca(:).peak_integralY]'-[jdot0F_ryr(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0F_serca(:).integralY]'-[jdot0F_ryr(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0F_serca(:).peak_integralY]'-[idot0F_ryr(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0F_serca(:).integralY]'-[idot0F_ryr(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR over Peak}',...
%      '{CTRL} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of SERCA and RyR over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_serca-ryr'),'-dtiff','-r300')
% close 


%% pcc integral calcium difference of y36 - y31
% figure(20)
% %% ctrl
% x = [[owt_y36(:).peak_integralY]'-[owt_y31(:).peak_integralY]',...
%      ];
% y = sf106;
% [rho_sctrly31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[owt_y36(:).integralY]'-[owt_y31(:).integralY]',...
%      ];
% y = sf106;
% [rho_sctrly38,~] = partialcorri(x,y,'type','Spearman','rows','complete'); 
% %% j 
% x = [[jdot0_y36(:).peak_integralY]'-[jdot0_y31(:).peak_integralY]',...
%      ];
% y = sf106jdot0;
% [rho_sjy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[jdot0_y36(:).integralY]'-[jdot0_y31(:).integralY]',...
%       ];  
% y = sf106jdot0;
% [rho_sjy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% %% i
% x = [[idot0_y36(:).peak_integralY]'-[idot0_y31(:).peak_integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy31,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% x = [[idot0_y36(:).integralY]'-[idot0_y31(:).integralY]',...
%      ];
% y = sf106idot0;
% [rho_siy38,~] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{CTRL} {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of Junction and SR over Peak}',...    
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of Junction and SR over Peak}',...
%      '{CTRL} {Integral [Ca] Difference of Junction and SR over a Beat}',...
%      '{J_{ls2j} = 0} {Integral [Ca] Difference of Junction and SR over a Beat}',...
%      '{J_{ls2i} = 0} {Integral [Ca] Difference of Junction and SR over a Beat}',...
%     };
% 
% xv= {'J_{ls2j}','J_{ls2i}','J_{lslk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round([rho_sctrly31;rho_sjy31;rho_siy31;rho_sctrly38;rho_sjy38;rho_siy38],+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Biomarkers under Hypercalcemia and ISO');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 600])
% print(gcf, fullfile(pwd, 'pcc_ctrl_j_i_y36-y31'),'-dtiff','-r300')
% close 

%% integral peak y31
% figure(7)
% bx = [[owt_y31(:).peak_integralY],...
%       [jdot0_y31(:).peak_integralY],...
%       [idot0_y31(:).peak_integralY],...  
%       ]; 
% by = [ zeros(length([owt_y31(:).peak_integralY]), 1);...
%        1*ones(length([jdot0_y31(:).peak_integralY]), 1);...       
%        2*ones(length([idot0_y31(:).peak_integralY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 7;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] SR Integral Peak (nM)'})
% title({'Hypercalcemia','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_y31_integralpeak'),'-dtiff','-r300')
% close

%% bp ls2j
% figure(7)
% bx = [[owtF_ls2j(:).ampY],...
%       [jdot0F_ls2j(:).ampY],...
%       [idot0F_ls2j(:).ampY],...  
%       ]; 
% by = [ zeros(length([owtF_ls2j(:).ampY]), 1);...
%        1*ones(length([jdot0F_ls2j(:).ampY]), 1);...       
%        2*ones(length([idot0F_ls2j(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2j} of','Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2j_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ls2j(:).dad_ampY],...
%       [jdot0F_ls2j(:).dad_ampY],...
%       [idot0F_ls2j(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ls2j(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ls2j(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ls2j(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 3;
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2j} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2j_ampdad'),'-dtiff','-r300')
% close 
% 
% %% bp ls2i
% figure(7)
% bx = [[owtF_ls2i(:).ampY],...
%       [jdot0F_ls2i(:).ampY],...
%       [idot0F_ls2i(:).ampY],...   
%       ]; 
% by = [ zeros(length([owtF_ls2i(:).ampY]), 1);...
%        1*ones(length([jdot0F_ls2i(:).ampY]), 1);...       
%        2*ones(length([idot0F_ls2i(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2i} of','Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2i_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ls2i(:).dad_ampY],...
%       [jdot0F_ls2i(:).dad_ampY],...
%       [idot0F_ls2i(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ls2i(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ls2i(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ls2i(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{ls2i} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ls2i_ampdad'),'-dtiff','-r300')
% close
% 
% %% bp ryr
% figure(7)
% bx = [[owtF_ryr(:).ampY],...
%       [jdot0F_ryr(:).ampY],...
%       [idot0F_ryr(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_ryr(:).ampY]), 1);...
%        1*ones(length([jdot0F_ryr(:).ampY]), 1);...       
%        2*ones(length([idot0F_ryr(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] J_{RyR} (nM/ms)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ryr_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ryr(:).dad_ampY],...
%       [jdot0F_ryr(:).dad_ampY],...
%       [idot0F_ryr(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ryr(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ryr(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ryr(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 4;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{RyR} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ryr_ampdad'),'-dtiff','-r300')
% close
% 
%% bp serca
% figure(7)
% bx = [[owtF_serca(:).ampY],...
%       [jdot0F_serca(:).ampY],...
%       [idot0F_serca(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_serca(:).ampY]), 1);...
%        1*ones(length([jdot0F_serca(:).ampY]), 1);...       
%        2*ones(length([idot0F_serca(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] J_{SERCA} (nM/ms)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_serca_amp'),'-dtiff','-r300')
% close

% figure(7)
% bx = [[owtF_serca(:).dad_ampY],...
%       [jdot0F_serca(:).dad_ampY],...
%       [idot0F_serca(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_serca(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_serca(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_serca(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 2;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] J_{SERCA} of','DAD Amplitude (nM/ms)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_serca_ampdad'),'-dtiff','-r300')
% close
% 
% %% bp cal
% figure(7)
% bx = [[owtF_cal(:).ampY],...
%       [jdot0F_cal(:).ampY],...
%       [idot0F_cal(:).ampY],...
%       ] 
% by = [ zeros(length([owtF_cal(:).ampY]), 1);...
%        1*ones(length([jdot0F_cal(:).ampY]), 1);...       
%        2*ones(length([idot0F_cal(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{CaL} of','Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_cal_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_cal(:).dad_ampY],...
%       [jdot0F_cal(:).dad_ampY],...
%       [idot0F_cal(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_cal(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_cal(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_cal(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% % ax = gca;
% % ax.YAxis.Exponent = 0.01;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{CaL} of','DAD Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_cal_ampdad'),'-dtiff','-r300')
% close
% 

%% bp ncx integral over a beat
% figure(7)
% bx = [[owtF_ncx(:).integralY],...
%       [jdot0F_ncx(:).integralY],...
%       [idot0F_ncx(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_ncx(:).integralY]), 1);...
%        1*ones(length([jdot0F_ncx(:).integralY]), 1);...       
%        2*ones(length([idot0F_ncx(:).integralY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% % ax = gca;
% % ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Integral [Ca] I_{NCX} over','a Beat (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_intergralbeat'),'-dtiff','-r300')
% close

%% bp ncx
% figure(7)
% bx = [[owtF_ncx(:).ampY],...
%       [jdot0F_ncx(:).ampY],...
%       [idot0F_ncx(:).ampY],...
%       ]; 
% by = [ zeros(length([owtF_ncx(:).ampY]), 1);...
%        1*ones(length([jdot0F_ncx(:).ampY]), 1);...       
%        2*ones(length([idot0F_ncx(:).ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% % ax = gca;
% % ax.YAxis.Exponent = 1;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'Amplitude of','[Ca] I_{NCX} (pA/pF)'})
% title({'Hypercalcemia and ISO',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_amp'),'-dtiff','-r300')
% close
% 
% figure(7)
% bx = [[owtF_ncx(:).dad_ampY],...
%       [jdot0F_ncx(:).dad_ampY],...
%       [idot0F_ncx(:).dad_ampY],...      
%       ]; 
% by = [ zeros(length([owtF_ncx(:).dad_ampY]), 1);...
%        1*ones(length([jdot0F_ncx(:).dad_ampY]), 1);...       
%        2*ones(length([idot0F_ncx(:).dad_ampY]), 1);...
%        ];
%    
% lbl ={'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'}; %,'Ca_{DAD}','Ca_{DAD}','Ca_{DAD}'
% boxplot(bx, by,'Notch','on','label', lbl, 'Colors','bkr');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'CTRL','J_{ls2j}=0','J_{ls,rel} = 0'})
% 
% ax = gca;
% ax.YAxis.Exponent = 0.01;
% % legend([c(3);c(2);c(1)],'CTRL','J_{ls2j}=0','J_{ls,rel} = 0','Location','northeast');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',30)
% ylabel({'[Ca] I_{NCX} of','DAD Amplitude (pA/pF)'})
% title({'Calcium Overload','ISO'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',1);
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% print(gcf, fullfile(pwd, 'bp_ncx_ampdad'),'-dtiff','-r300')
% close
% 
% %% pcc amp
% 
% %%
% figure(20)
% x = [[owt(:).y38_ampY]',[owt(:).y38_dad_ampY]'];
% 
% y = [[owtF_serca(:).ampY]',[owtF_serca(:).dad_ampY]',...
%      [owtF_ryr(:).ampY]',[owtF_ryr(:).dad_ampY]',...
%      [owtF_ls2j(:).ampY]',[owtF_ls2j(:).dad_ampY]',...
%      [owtF_ls2i(:).ampY]',[owtF_ls2i(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF_iflux'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampY]',[jdot0(:).y38_dad_ampY]'];
% 
% y = [[jdot0F_serca(:).ampY]',[jdot0F_serca(:).dad_ampY]',...
%     [jdot0F_ryr(:).ampY]',[jdot0F_ryr(:).dad_ampY]',...
%      [jdot0F_ls2j(:).ampY]',[jdot0F_ls2j(:).dad_ampY]',...
%      [jdot0F_ls2i(:).ampY]',[jdot0F_ls2i(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F_iflux'),'-dtiff','-r300')
% close 
% 
% 
% figure(20)
% x = [[idot0(:).y38_ampY]',[idot0(:).y38_dad_ampY]'];
% 
% y = [[idot0F_serca(:).ampY]',[idot0F_serca(:).dad_ampY]',...
%     [idot0F_ryr(:).ampY]',[idot0F_ryr(:).dad_ampY]',...
%      [idot0F_ls2j(:).ampY]',[idot0F_ls2j(:).dad_ampY]',...
%      [idot0F_ls2i(:).ampY]',[idot0F_ls2i(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% yv= {'{Amp}','{Amp_{DAD}}'};
% xv= {'AMP_{SERCA}','DAD_{SERCA}','AMP_{RyR}','DAD_{RyR}','AMP_{ls2j}','DAD_{ls2j}','AMP_{ls2i}','DAD_{ls2i}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1800 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F_iflux'),'-dtiff','-r300')
% close 
% 
% %%
% figure(20)
% x = [[owt(:).y38_ampY]',[owt(:).y38_dad_ampY]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = [[owtF_cal(:).ampY]',[owtF_ls2j(:).ampY]',[owtF_ls2j(:).dad_ampY]',...
%     [owtF_ls2i(:).ampY]',[owtF_ls2i(:).dad_ampY]',...
%     [owtF_ryr(:).ampY]',[owtF_ryr(:).dad_ampY]',[owtF_serca(:).ampY]',[owtF_serca(:).dad_ampY]',...
%      [owtF_ncx(:).ampY]',[owtF_ncx(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampY]',[jdot0(:).y38_dad_ampY]',[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',...
%      ];
%  
% y = [[jdot0F_cal(:).ampY]',[jdot0F_ls2j(:).ampY]',[jdot0F_ls2j(:).dad_ampY]',...
%     [jdot0F_ls2i(:).ampY]',[jdot0F_ls2i(:).dad_ampY]',...
%     [jdot0F_ryr(:).ampY]',[jdot0F_ryr(:).dad_ampY]',[jdot0F_serca(:).ampY]',[jdot0F_serca(:).dad_ampY]',...
%      [jdot0F_ncx(:).ampY]',[jdot0F_ncx(:).dad_ampY]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[idot0(:).y38_ampY]',[idot0(:).y38_dad_ampY]',[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',...
%      ];
% y = [[idot0F_cal(:).ampY]',[idot0F_ls2j(:).ampY]',[idot0F_ls2j(:).dad_ampY]',...
%     [idot0F_ls2i(:).ampY]',[idot0F_ls2i(:).dad_ampY]',...
%     [idot0F_ryr(:).ampY]',[idot0F_ryr(:).dad_ampY]',[idot0F_serca(:).ampY]',[idot0F_serca(:).dad_ampY]',...
%      [idot0F_ncx(:).ampY]',[idot0F_ncx(:).dad_ampY]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','DAD_{ls2j}','Amp_{ls2i}','DAD_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2400 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F'),'-dtiff','-r300')
% close 
% 
% %% pcc T
% figure(20)
% x = [[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',[owt(:).y38_ampT]',[owt(:).y38_dad_ampT]',...
%      ];
% y = [[owtF_cal(:).ampT]',[owtF_ls2j(:).ampT]',[owtF_ls2i(:).ampT]',...
%     [owtF_ryr(:).ampT]',[owtF_ryr(:).dad_ampT]',[owtF_serca(:).ampT]',[owtF_serca(:).dad_ampT]',...
%      [owtF_ncx(:).ampT]',[owtF_ncx(:).dad_ampT]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in CTRL');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_ctrlF_T'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',[jdot0(:).y38_ampT]',[jdot0(:).y38_dad_ampT]',...
%      ];
% y = [[jdot0F_cal(:).ampT]',[jdot0F_ls2j(:).ampT]',[jdot0F_ls2i(:).ampT]',...
%     [jdot0F_ryr(:).ampT]',[jdot0F_ryr(:).dad_ampT]',[jdot0F_serca(:).ampT]',[jdot0F_serca(:).dad_ampT]',...
%      [jdot0F_ncx(:).ampT]',[jdot0F_ncx(:).dad_ampT]'];
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','{Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls2j}=0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_jdot0F_T'),'-dtiff','-r300')
% close 
% 
% figure(20)
% x = [[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',[idot0(:).y38_ampT]',[idot0(:).y38_dad_ampT]',...
%      ];
% y = [[idot0F_cal(:).ampT]',[idot0F_ls2j(:).ampT]',[idot0F_ls2i(:).ampT]',...
%     [idot0F_ryr(:).ampT]',[idot0F_ryr(:).dad_ampT]',[idot0F_serca(:).ampT]',[idot0F_serca(:).dad_ampT]',...
%      [idot0F_ncx(:).ampT]',[idot0F_ncx(:).dad_ampT]'];
%  
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman','rows','complete');
% 
% yv= {'{Amp}','{Amp_{DAD}}','{Timepoint_{Amp}}','Timepoint_{DAD}}',...
%     };
% 
% xv= {'Amp_{CaL}','Amp_{ls2j}','Amp_{ls2i}','Amp_{RyR}','DAD_{RyR}','Amp_{SERCA}','DAD_{SERCA}','Amp_{NCX}','DAD_{NCX}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);
% colormap('redblue')
% hs.Title = sprintf('[Ca] Cytosol Timepoint Biomarkers of Calcium Overload under ISO in J_{ls,rel} = 0');
% set(gca, 'FontName','Times New Roman','FontSize',30)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 2000 500])
% print(gcf, fullfile(pwd, 'pcc_idot0F_T'),'-dtiff','-r300')
% close 

