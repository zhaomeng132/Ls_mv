clear all
close all
addpath('~/downloads/SS/Ls_mv_sf6/plot_h1_cao1dot8_p3_sf6')
% id 1 -1000
cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat

cd ~/downloads/SS/Ls_mv_sf6
% index 0 - 343
load cao1dot8_iTPC_1.mat
iTPC_1 = cao1dot8_iTPC_1;
load cao1dot8_inoneTPC_1.mat
inoneTPC_1 = cao1dot8_inoneTPC_1;
load cao1dot8_inone_0.mat
inone_0 = cao1dot8_inone_0;

% 5beat
% load cao1dot8_iTPC_1_5beat.mat
% iTPC_1 = cao1dot8_iTPC_1_5beat;
% load cao1dot8_inoneTPC_1_5beat.mat
% inoneTPC_1 = cao1dot8_inoneTPC_1_5beat;
% load cao1dot8_inone_0_5beat.mat
% inone_0 = cao1dot8_inone_0_5beat;


cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
Swt_TPC_1 = S(iTPC_1);
Swt_noneTPC_1 = S(inoneTPC_1);
Swt_none_0 = S(inone_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
Sjdot0_TPC_1 = S(iTPC_1);
Sjdot0_noneTPC_1 = S(inoneTPC_1);
Sjdot0_none_0 = S(inone_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
Sidot0_TPC_1 = S(iTPC_1);
Sidot0_noneTPC_1 = S(inoneTPC_1);
Sidot0_none_0 = S(inone_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_herz1_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
Fwt_TPC_1 = F(iTPC_1);
Fwt_noneTPC_1 = F(inoneTPC_1);
Fwt_none_0 = F(inone_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_j_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
Fjdot0_TPC_1 = F(iTPC_1);
Fjdot0_noneTPC_1 = F(inoneTPC_1);
Fjdot0_none_0 = F(inone_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc/h1_cao1dot8_sf1000_FLUX_
load y175_FLUX_WT_i_dot0_cao1dot8_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
F = F(h1_cao1_sf1000_sf6_0);
Fidot0_TPC_1 = F(iTPC_1);
Fidot0_noneTPC_1 = F(inoneTPC_1);
Fidot0_none_0 = F(inone_0);

cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','fig4'])
cd(['./','fig4'])

%%
rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                     % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
sf = sf(h1_cao1_sf1000_sf6_0,:);

% index 0 - 343

sf_noneTPC_1 = sf(inoneTPC_1,:);
sf_space = nan(1);
sf_TPC_1 = sf(iTPC_1,:);
sf_none_0 = sf(inone_0,:);

close all

bx = [
     sf_noneTPC_1(:,1);sf_TPC_1(:,1);sf_none_0(:,1);sf_space;...
     sf_noneTPC_1(:,2);sf_TPC_1(:,2);sf_none_0(:,2);sf_space;...
     sf_noneTPC_1(:,3);sf_TPC_1(:,3);sf_none_0(:,3);sf_space;...
     sf_noneTPC_1(:,4);sf_TPC_1(:,4);sf_none_0(:,4);sf_space;...
     sf_noneTPC_1(:,5);sf_TPC_1(:,5);sf_none_0(:,5);sf_space;...
     sf_noneTPC_1(:,6);sf_TPC_1(:,6);sf_none_0(:,6);sf_space;...
     sf_noneTPC_1(:,7);sf_TPC_1(:,7);sf_none_0(:,7);sf_space;...
     sf_noneTPC_1(:,8);sf_TPC_1(:,8);sf_none_0(:,8);sf_space;...
     sf_noneTPC_1(:,9);sf_TPC_1(:,9);sf_none_0(:,9);sf_space;...
     ];
 
% bx = [
%      sf_noneTPC_1(:);sf_TPC_1(:,1);sf_none_0(:,1);...
%      sf_noneTPC_1(:);sf_TPC_1(:,2);sf_none_0(:,2);...
%      sf_noneTPC_1(:);sf_TPC_1(:,3);sf_none_0(:,3);...
%      sf_noneTPC_1(:);sf_TPC_1(:,4);sf_none_0(:,4);...
%      sf_noneTPC_1(:);sf_TPC_1(:,5);sf_none_0(:,5);...
%      sf_noneTPC_1(:);sf_TPC_1(:,6);sf_none_0(:,6);...
%      sf_noneTPC_1(:);sf_TPC_1(:,7);sf_none_0(:,7);...
%      sf_noneTPC_1(:);sf_TPC_1(:,8);sf_none_0(:,8);...
%      sf_noneTPC_1(:);sf_TPC_1(:,9);sf_none_0(:,9);...
%      ];
 
% by = [ zeros(length([sf_noneTPC_1]), 1);1*ones(length([sf_TPC_1]), 1);2*ones(length([sf_none_0]), 1);... 
%        3*ones(length([sf_noneTPC_1]), 1);4*ones(length([sf_TPC_1]), 1);5*ones(length([sf_none_0]), 1);... 
%        6*ones(length([sf_noneTPC_1]), 1);7*ones(length([sf_TPC_1]), 1);8*ones(length([sf_none_0]), 1);... 
%        9*ones(length([sf_noneTPC_1]), 1);10*ones(length([sf_TPC_1]), 1);11*ones(length([sf_none_0]), 1);...
%        12*ones(length([sf_noneTPC_1]), 1);13*ones(length([sf_TPC_1]), 1);14*ones(length([sf_none_0]), 1);... 
%        15*ones(length([sf_noneTPC_1]), 1);16*ones(length([sf_TPC_1]), 1);17*ones(length([sf_none_0]), 1);...
%        18*ones(length([sf_noneTPC_1]), 1);19*ones(length([sf_TPC_1]), 1);20*ones(length([sf_none_0]), 1);...
%        21*ones(length([sf_noneTPC_1]), 1);22*ones(length([sf_TPC_1]), 1);23*ones(length([sf_none_0]), 1);...
%        24*ones(length([sf_noneTPC_1]), 1);25*ones(length([sf_TPC_1]), 1);26*ones(length([sf_none_0]), 1);...
%      ];

by = [ zeros(length([sf_noneTPC_1]), 1);1*ones(length([sf_TPC_1]), 1);2*ones(length([sf_none_0]), 1);3*ones(length([sf_space]), 1);... 
       4*ones(length([sf_noneTPC_1]), 1);5*ones(length([sf_TPC_1]), 1);6*ones(length([sf_none_0]), 1);7*ones(length([sf_space]), 1);... 
       8*ones(length([sf_noneTPC_1]), 1);9*ones(length([sf_TPC_1]), 1);10*ones(length([sf_none_0]), 1);11*ones(length([sf_space]), 1);... 
       12*ones(length([sf_noneTPC_1]), 1);13*ones(length([sf_TPC_1]), 1);14*ones(length([sf_none_0]), 1);15*ones(length([sf_space]), 1);...
       16*ones(length([sf_noneTPC_1]), 1);17*ones(length([sf_TPC_1]), 1);18*ones(length([sf_none_0]), 1);19*ones(length([sf_space]), 1);...
       20*ones(length([sf_noneTPC_1]), 1);21*ones(length([sf_TPC_1]), 1);22*ones(length([sf_none_0]), 1);23*ones(length([sf_space]), 1);...
       24*ones(length([sf_noneTPC_1]), 1);25*ones(length([sf_TPC_1]), 1);26*ones(length([sf_none_0]), 1);27*ones(length([sf_space]), 1);...
       28*ones(length([sf_noneTPC_1]), 1);29*ones(length([sf_TPC_1]), 1);30*ones(length([sf_none_0]), 1);31*ones(length([sf_space]), 1);...
       32*ones(length([sf_noneTPC_1]), 1);33*ones(length([sf_TPC_1]), 1);34*ones(length([sf_none_0]), 1);35*ones(length([sf_space]), 1);...
     ];
 
figure(1);
boxplot(bx,by,'Notch','on','Colors','rbmk');
% boxplot(bx,by,'Notch','on','Colors','bm');
c = findobj(gca,'Tag','Box');
ylabel({'Variations of Conductances'})
ylim([0.25 3])
set(gca,'TickLabelInterpreter','Tex')
ax = gca;
% ax. Position = [0.25 0.2 0.7 0.7];
lbl= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
set(gca,'xticklabel',lbl)
set(gca,'xtick',2:4:36)
% set(gca,'xtick',1.5:2:26)
set(gca,'ytick',0.5:0.5:2)
set(gca,'box','off');
legend([c(4);c(3);c(2)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast');legend boxoff
% legend([c(2);c(1)],'Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast');legend boxoff

set(gca, 'FontName','Times New Roman','FontSize',35)
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 1500 600])
print(gcf, fullfile(pwd, 'bp_cao1dot8'),'-dtiff','-r300')
% close

% % ncx - cal
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,7))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,7))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,7))

% ncx - ryr
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,5))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,5))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,5))

% ncx - serca
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,6)) - median(sf_noneTPC_1(:,4))
% ncd_TPC_1 = median(sf_TPC_1(:,6)) - median(sf_TPC_1(:,4))
% ncd_none_0 = median(sf_none_0(:,6)) - median(sf_none_0(:,4))

% ls,up - ls,rel
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,1)) - median(sf_noneTPC_1(:,2))
% ncd_TPC_1 = median(sf_TPC_1(:,1)) - median(sf_TPC_1(:,2))
% ncd_none_0 = median(sf_none_0(:,1)) - median(sf_none_0(:,2))

% serca - ryr
% ncd_noneTPC_1 = median(sf_noneTPC_1(:,4)) - median(sf_noneTPC_1(:,5))
% ncd_TPC_1 = median(sf_TPC_1(:,4)) - median(sf_TPC_1(:,5))
% ncd_none_0 = median(sf_none_0(:,4)) - median(sf_none_0(:,5))

%% CTRL TPC2KO
Y = [38,31,36,88,37,15];
Yspace = {'Cytosol','SR','Junction','Lysosome','Sarcolemma','Open Probability'};
Yscale = [1e6,1e6,1e6,1e6,1e6,1];
yaxis_lim = [2,5,5,4,3,0];

% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 1;  % 10
idad_1 = 9;
for SP = 1 : 6%numel(Y)
for idad = id_median: id_median%numel(Sw_w1i0)
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt_TPC_1(idad_1).t,Swt_TPC_1(idad_1).y(:,Y(SP)).*Yscale(SP),'b'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Swt_none_0(idad).t,Swt_none_0(idad).y(:,Y(SP)).*Yscale(SP),'m'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
end    
    fontsize = 35;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 2
    legend('Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location', 'southeast');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    elseif SP == 6
    legend('Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location', 'northeast');legend boxoff
%     ylim([0 1.1])
    ylabel(sprintf('%s',Yspace{SP}));xlabel('Time (ms)');
    else
    legend('Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location', 'northeast');legend boxoff
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');
    end
 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[0 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i1_w1i0',Y(SP))),'-dtiff','-r300');

close all
end

%% inset
Y = [38,31,36,88,37,15];
Yspace = {'Cytosol','SR','Junction','Lysosome','Sarcolemma','Open Probability'};
Yscale = [1e6,1e6,1e6,1e6,1e6,1];
yaxis_lim = [2,5,5,4,3,0];
id_median = 1;
idad_1 = 9;
for SP = 6 : 6%numel(Y)
for idad = id_median: id_median%numel(Sw_w1i0)
    figure(60)
    ax2 = subplot(1,1,1);
    p1 = plot(Swt_TPC_1(idad_1).t,Swt_TPC_1(idad_1).y(:,Y(SP)).*Yscale(SP),'b'); %p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p3 = plot(Swt_none_0(idad).t,Swt_none_0(idad).y(:,Y(SP)).*Yscale(SP),'m'); %p3.Color(3) = 1;%  38 cytosolic space
    hold on           
end    
    fontsize = 70;
    yaxis = yaxis_lim(SP);
    f4 = figure(60);  
    xlim([0 20]);
    ax = gca;

    ax.YAxis.Exponent = yaxis;
 
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(f4,'Units','pixels','Position',[0 0 770 550]) 
    set(findobj(f4, 'Type', 'Line'),'LineWidth',4);
    set(findobj(f4,'type','axes'),'box','off') 
    hold off 
    
print(f4, fullfile(pwd, sprintf('%d w1i1_w1i0_inset',Y(SP))),'-dtiff','-r300');

close all
end

%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot15_1term ydot15_2term]; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30           31
Y = [1 2 3 4 5 6 9 27];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{CaL}','J_RyR Leak'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1 1e6]; 
Yaxis = [1 -1 2 4 4 3 1 0];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{CaL} (pA/pF)','J_{RyR Leak} (nM/ms)'};
close
% tpcy = linspace(1,numel(iTPC_1),numel(iTPC_1)); 
% id_median = round(median(tpcy));
id_median = 1; % 10, 1-30 no identical
idad_1 = 9;
for SP = 7:7%numel(Y)
for idad = id_median: id_median%numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt_TPC_1(idad_1).tArray,Fwt_TPC_1(idad_1).currents(:,Y(SP)).*Yscale(SP),'b');
    hold on
    p2 =plot(Fwt_none_0(idad).tArray,Fwt_none_0(idad).currents(:,Y(SP)).*Yscale(SP),'m');    

end

fontsize = 35;

f1 = figure(1);subplot(1,1,1); 
ylabel(sprintf('%s',Yylabel{SP}));xlabel('Time (ms)');       
if SP ==7
% title({'Hypercalcemia and ISO, WT_{ }',' '});
title({' ',' '})
else
title({' ',' '})
end
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = Yaxis(SP);
               if SP == 1 | SP == 2 | SP==5 | SP==7 | SP==8
               legend('Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location', 'southeast');legend boxoff
               else
               legend('Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location', 'northeast');legend boxoff
               end
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
print(f1, fullfile(pwd, sprintf('w1i1_w1i0 %s',Yspace{SP})),'-dtiff','-r300');

close all
end

%% inset
Y = [1 2 3 4 5 6 9 27];
Yspace = {'I_Cal','I_NCX','J_SERCA','J_RyR','J_{ls,up}','J_{ls,rel}', 'Ju I_{CaL}','J_RyR Leak'};
Yscale = [1 1 1e6 1e6 1e6 1e6 1 1e6]; 
Yaxis = [1 -1 2 4 4 3 1 0];
Yylabel = {'I_{CaL} (pA/pF)','I_{NCX} (pA/pF)','J_{SERCA} (nM/ms)','J_{RyR} (nM/ms)','J_{ls,up} (nM/ms)','J_{ls,rel} (nM/ms)', 'Junctional I_{CaL} (pA/pF)','J_{RyR Leak} (nM/ms)'};

id_median = 1;
idad_1 = 9;

for SP = 4:4%numel(Y)
for idad = id_median: id_median%numel(Fwt)
    
    figure(1);ax1 = subplot(1,1,1);
    p1 =plot(Fwt_TPC_1(idad_1).tArray,Fwt_TPC_1(idad_1).currents(:,Y(SP)).*Yscale(SP),'b','linewidth',2);
    hold on
    p2 =plot(Fwt_none_0(idad).tArray,Fwt_none_0(idad).currents(:,Y(SP)).*Yscale(SP),'m','linewidth',2);    

end

fontsize = 70;

f1 = figure(1);subplot(1,1,1); 
xlim([0 20])
               ax = gca;
               ax.YAxis.Exponent = Yaxis(SP);
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',fontsize)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f1,'Units','pixels','Position',[0 0 700 500])
               
print(f1, fullfile(pwd, sprintf('w1i1_w1i0_inset %s',Yspace{SP})),'-dtiff','-r300');

close all
end
%% indirect derivatives
% Swt
for ipeak = 1: numel(Swt_TPC_1) 

t3 = Swt_TPC_1(ipeak).t;
y3 = Swt_TPC_1(ipeak).y;

% biomarkers for Swt
owt_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200); %mM/ms to nM/ms 
owt_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
% owt_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_TPC_1(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_TPC_1(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200,200, y3(:,36).*1e6);

% figure(1)
% plot(t3, y3(:,30),'k');hold on
% plot(t3, y3(:,31),'r');
% % plot(t3(owt_y31_y36_TPC_1(ipeak).valleyI), y3(owt_y31_y36_TPC_1(ipeak).valleyI,31),'r.','MarkerSize',30)
% legend('Calsequestrin [Ca] SR','[Ca] SR','Location','northwest');legend boxoff
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel('(mM)')
% ylim([0 2])
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'y30_y31'),'-dtiff','-r300')

% figure(4)
% plot(t3, y3(:,36));hold on
% plot(t3(owt_y31_TPC_1(ipeak).valleyI), y3(owt_y31_TPC_1(ipeak).valleyI,36),'r.','MarkerSize',30)

end

for ipeak = 1:numel(Swt_noneTPC_1) 

t3 = Swt_noneTPC_1(ipeak).t;
y3 = Swt_noneTPC_1(ipeak).y;

% biomarkers for Swt
owt_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200);
owt_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
% owt_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_noneTPC_1(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_noneTPC_1(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200,200, y3(:,36).*1e6);

% figure(2)
% plot(t3, y3(:,31));hold on
% plot(t3(owt_y31_y36_noneTPC_1(ipeak).valleyI), y3(owt_y31_y36_noneTPC_1(ipeak).valleyI,31),'r.','MarkerSize',30)

end

for ipeak = 1: numel(Swt_none_0) 

t3 = Swt_none_0(ipeak).t;
y3 = Swt_none_0(ipeak).y;

% biomarkers for Swt
owt_y38_none_0(ipeak) = peakfinder(t3, y3(:,38).*1e6,200,200);
owt_y88_none_0(ipeak) = peakfinder(t3, y3(:,88).*1e6,200,200);
% owt_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31).*1e6,200,200);
owt_y36_none_0(ipeak) = peakfinder(t3, y3(:,36).*1e6,200,200);
owt_y37_none_0(ipeak) = peakfinder(t3, y3(:,37).*1e6,200,200);

owt_y31_y36_none_0(ipeak) = y31_y36_peakfinder(t3, y3(:,31).*1e6,200, 200, y3(:,36).*1e6);

% figure(3)
% plot(t3, y3(:,31));hold on
% plot(t3(owt_y31_y36_none_0(ipeak).valleyI), y3(owt_y31_y36_none_0(ipeak).valleyI,31),'r.','MarkerSize',30)

end

%% direct derivaties nM/ms
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot(31) ydot(36) ydot(38) ydot(88)] ; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     29     30       31       32       33
close all
% noneTPC
for ipeak = 1: numel(Fwt_noneTPC_1)
   
tflux = Fwt_noneTPC_1(ipeak).tArray;
ydot31 = Fwt_noneTPC_1(ipeak).currents(:,30).*1e6;     % nM/ms   
ydot36 = Fwt_noneTPC_1(ipeak).currents(:,31).*1e6;     % nM/ms
ydot38 = Fwt_noneTPC_1(ipeak).currents(:,32).*1e6;     % nM/ms   
ydot88 = Fwt_noneTPC_1(ipeak).currents(:,33).*1e6;     % nM/ms

owt_y31_y36_noneTPC_1(ipeak) = y31_y36_peakfinder(tflux,ydot31,200,200,ydot36);
owt_y36_noneTPC_1(ipeak) = peakfinder(tflux,ydot36,200,200);
owt_y38_noneTPC_1(ipeak) = peakfinder(tflux,ydot38,2,2);
owt_y88_noneTPC_1(ipeak) = peakfinder(tflux,ydot88,2,2);

% figure(1)
% plot(tflux, Fwt_noneTPC_1(ipeak).currents(:,30));hold on
end

% TPC
for ipeak = 1: numel(Fwt_TPC_1)
   
tflux = Fwt_TPC_1(ipeak).tArray;
ydot31 = Fwt_TPC_1(ipeak).currents(:,30).*1e6;     % nM/ms   
ydot36 = Fwt_TPC_1(ipeak).currents(:,31).*1e6;     % nM/ms
ydot38 = Fwt_TPC_1(ipeak).currents(:,32).*1e6;     % nM/ms   
ydot88 = Fwt_TPC_1(ipeak).currents(:,33).*1e6;     % nM/ms  

owt_y31_y36_TPC_1(ipeak) = y31_y36_peakfinder(tflux,ydot31,200,200,ydot36);
owt_y36_TPC_1(ipeak) = peakfinder(tflux,ydot36,200,200);
owt_y38_TPC_1(ipeak) = peakfinder(tflux,ydot38,2,2);
owt_y88_TPC_1(ipeak) = peakfinder(tflux,ydot88,2,2);

% figure(2)
% plot(tflux, Fwt_TPC_1(ipeak).currents(:,31));hold on
end

% none
for ipeak = 1: numel(Fwt_none_0)
   
tflux = Fwt_none_0(ipeak).tArray;
ydot31 = Fwt_none_0(ipeak).currents(:,30).*1e6;     % nM/ms   
ydot36 = Fwt_none_0(ipeak).currents(:,31).*1e6;     % nM/ms
ydot38 = Fwt_none_0(ipeak).currents(:,32).*1e6;     % nM/ms   
ydot88 = Fwt_none_0(ipeak).currents(:,33).*1e6;     % nM/ms  

owt_y31_y36_none_0(ipeak) = y31_y36_peakfinder(tflux,ydot31,200,200,ydot36);
owt_y36_none_0(ipeak) = peakfinder(tflux,ydot36,200,200);
owt_y38_none_0(ipeak) = peakfinder(tflux,ydot38,2,2);
owt_y88_none_0(ipeak) = peakfinder(tflux,ydot88,2,2);
end
%% y31 integral
close all
figure(7)
bx = [[owt_y31_y36_noneTPC_1(:).sumY],...
      [owt_y31_y36_TPC_1(:).sumY],...
      [owt_y31_y36_none_0(:).sumY],...
      ]; 
by = [ zeros(length([owt_y31_y36_noneTPC_1(:).sumY]), 1);...
       1*ones(length([owt_y31_y36_TPC_1(:).sumY]), 1);...       
       2*ones(length([owt_y31_y36_none_0(:).sumY]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff

%5
% ax.YAxis.Exponent = 7;
% ylim([2e7 26*1e7])
% ylabel({'[Ca] SR (nM)'})
% %4
% ax.YAxis.Exponent = 5;
% ylim([-3e5 5*1e5])
% ylabel({'[Ca] SR (nM)'})
% %3
% ax.YAxis.Exponent = 5;
% ylim([-3e5 5*1e5])
% ylabel({'[Ca] SR (nM)'})
% %2
ax.YAxis.Exponent = 8;
ylim([2e8 8*1e8])
ylabel({'[Ca] SR (nM)'})
%1
% ax.YAxis.Exponent = 7;
% ylim([1e7 28*1e7])
% ylabel({'[Ca] SR (nM)'})

set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y31_2'),'-dtiff','-r300')

%% y31-y36 integral
close all
figure(7)
bx = [[owt_y31_y36_noneTPC_1(:).sum_y31_y36],...
      [owt_y31_y36_TPC_1(:).sum_y31_y36],...
      [owt_y31_y36_none_0(:).sum_y31_y36],...
      ]; 
by = [ zeros(length([owt_y31_y36_noneTPC_1(:).sum_y31_y36]), 1);...
       1*ones(length([owt_y31_y36_TPC_1(:).sum_y31_y36]), 1);...       
       2*ones(length([owt_y31_y36_none_0(:).sum_y31_y36]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];

ax.YAxis.Exponent = 5;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
%5
% ax.YAxis.Exponent = 7;
% ylim([2e7 26*1e7])
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
%4
% ax.YAxis.Exponent = 5;
% ylim([-3e5 5*1e5])
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
%3
% ax.YAxis.Exponent = 5;
% ylim([-15e5 26*1e5])
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})
%2
ax.YAxis.Exponent = 8;
ylim([2e8 8*1e8])
ylabel({'[Ca] Difference of','Junction and SR (nM)'})
%1
% ax.YAxis.Exponent = 7;
% ylim([1e7 28*1e7])
% ylabel({'[Ca] Difference of','Junction and SR (nM)'})

set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y31-y36_2'),'-dtiff','-r300')

% noneTPC_none = median([owt_y31_y36_noneTPC_1(:).sum_y31_y36]) - median([owt_y31_y36_none_0(:).sum_y31_y36])
% TPC_none = median([owt_y31_y36_TPC_1(:).sum_y31_y36]) - median([owt_y31_y36_none_0(:).sum_y31_y36])
%% bp y36 integral
figure(7)
bx = [[owt_y36_noneTPC_1(:).sumY],...
      [owt_y36_TPC_1(:).sumY],...
      [owt_y36_none_0(:).sumY],...
      ]; 
by = [ zeros(length([owt_y36_noneTPC_1(:).sumY]), 1);...
       1*ones(length([owt_y36_TPC_1(:).sumY]), 1);...       
       2*ones(length([owt_y36_none_0(:).sumY]), 1);...             
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
% ylim([0e4 20*1e4])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Junction (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y36_3'),'-dtiff','-r300')

%% bp y88 integral
close all
figure(7)
bx = [[owt_y88_noneTPC_1(:).sumY],...
      [owt_y88_TPC_1(:).sumY],...
      [owt_y88_none_0(:).sumY],...
      ]; 
by = [ zeros(length([owt_y88_noneTPC_1(:).sumY]), 1);...
       1*ones(length([owt_y88_TPC_1(:).sumY]), 1);...       
       2*ones(length([owt_y88_none_0(:).sumY]), 1);...          
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 4;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
% ylim([0e4 4*1e4])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Lysosome (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y88_w'),'-dtiff','-r300')
% close

%% bp y38 integral
close all
figure(7)
bx = [[owt_y38_noneTPC_1(:).sumY],...
      [owt_y38_TPC_1(:).sumY],...
      [owt_y38_none_0(:).sumY],...
      ]; 
by = [ zeros(length([owt_y38_noneTPC_1(:).sumY]), 1);...
       1*ones(length([owt_y38_TPC_1(:).sumY]), 1);...       
       2*ones(length([owt_y38_none_0(:).sumY]), 1);...          
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 3;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
% ylim([-1.4e4 0.8*1e4])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'[Ca] Cytosol (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'y38_w'),'-dtiff','-r300')
% close
%%            1        2     3       4         5     6     7          8          9         10      11         12       13             14            15        16       
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i jucal_2ncx slcal_2ncx I_Ca_junc I_Ca_sl I_ncx_junc I_ncx_sl jucal_2ncx_ca  slcal_2ncx_ca ju_in_out sl_in_out ...
%            sr_in_out sr_in  juncx_ca slncx_ca juncx_ca_srin  slncx_ca_srin jusl_cal_2ncx_ca jutot_ca sltot_ca y15y31_36 J_SRleak koSRCa kiSRCa ydot(31) ydot(36) ydot(38) ydot(88)] ; 
%%           17        18     19       20       21             22            23               24       25       26        27       28     30     31       32       33       34
% SP = 31;
% for ipeak = 1:numel(Fwt_TPC_1)
% 
% figure(1);
% % plot(Fwt_noneTPC_1(ipeak).tArray,Fwt_noneTPC_1(ipeak).currents(:,SP),'r');hold on
% % plot(Fwt_TPC_1(ipeak).tArray,Fwt_TPC_1(ipeak).currents(:,SP),'b');
% % plot(Fwt_none_0(ipeak).tArray,Fwt_none_0(ipeak).currents(:,SP),'k');
% 
% plot(Fwt_noneTPC_1(ipeak).tArray,Fwt_noneTPC_1(ipeak).currents(:,30)- Fwt_noneTPC_1(ipeak).currents(:,31),'r');hold on
% plot(Fwt_TPC_1(ipeak).tArray,Fwt_TPC_1(ipeak).currents(:,30) - Fwt_TPC_1(ipeak).currents(:,31),'b');
% plot(Fwt_none_0(ipeak).tArray,Fwt_none_0(ipeak).currents(:,30) - Fwt_none_0(ipeak).currents(:,31),'k');
% 
% % plot(Swt_TPC_1(ipeak).t,Swt_TPC_1(ipeak).y(:,31),'r');hold on
% % plot(Swt_noneTPC_1(ipeak).t,Swt_noneTPC_1(ipeak).y(:,31),'k');
% % plot(Swt_none_0(ipeak).t,Swt_none_0(ipeak).y(:,31),'b');
% end
% legend('Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
% 
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'RyR property: koSRCa'})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% % print(gcf, fullfile(pwd, 'y36-y31_dad'),'-dtiff','-r300')
%%
for ipeak = 1: numel(Fwt_TPC_1)
   
tflux = Fwt_TPC_1(ipeak).tArray;
yserca = Fwt_TPC_1(ipeak).Jserca.*1e6;    
yryr = Fwt_TPC_1(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_TPC_1(ipeak).currents(:,1));   % abs

owtF_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,13)*1e6,2,2); %mM /ms
% owtF_slcal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,16)*1e6,2,2);

% owtF_sr_in_out_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,25)*1e6,2,2);

% owtF_ncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,2),2,2);
% owtF_juncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,11),2,2);
% owtF_slncx_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,12),2,2);

owtF_jucal_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,9),2,2);

% owtF_y31_36_TPC_1(ipeak) = peakfinder(tflux,Fwt_TPC_1(ipeak).currents(:,26),2,2);
end

for ipeak = 1: numel(Fwt_noneTPC_1)
   
tflux = Fwt_noneTPC_1(ipeak).tArray;
yserca = Fwt_noneTPC_1(ipeak).Jserca.*1e6;    
yryr = Fwt_noneTPC_1(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_noneTPC_1(ipeak).currents(:,1));    

owtF_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,13)*1e6,2,2);
% owtF_slcal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,16)*1e6,2,2);
 
% owtF_sr_in_out_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,25)*1e6,2,2);

% owtF_ncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,2),2,2);
% owtF_juncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,11),2,2);
% owtF_slncx_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,12),2,2);

owtF_jucal_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,9),2,2);

% owtF_y31_36_noneTPC_1(ipeak) = peakfinder(tflux,Fwt_noneTPC_1(ipeak).currents(:,26),2,2);
end

for ipeak = 1: numel(Fwt_none_0)
  
tflux = Fwt_none_0(ipeak).tArray;
yserca = Fwt_none_0(ipeak).Jserca.*1e6;    
yryr = Fwt_none_0(ipeak).J_RyR.*1e6;  
ycal = abs(Fwt_none_0(ipeak).currents(:,1));    

owtF_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
owtF_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
owtF_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);

% owtF_jucal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,13)*1e6,2,2);
% owtF_slcal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,14)*1e6,2,2);

% owtF_ju_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,15)*1e6,2,2);
% owtF_sl_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,16)*1e6,2,2);
 
% owtF_sr_in_out_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,17)*1e6,2,2);
% owtF_juncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,19)*1e6,2,2);
% owtF_slncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,20)*1e6,2,2);

% owtF_juncx_ca_srin_in_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,21)*1e6,2,2);
% owtF_slncx_ca_srin_in_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,22)*1e6,2,2);

% owtF_jusl_cal_2ncx_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,23)*1e6,2,2);

% owtF_jutot_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,24)*1e6,2,2);
% owtF_sltot_ca_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,25)*1e6,2,2);

% owtF_ncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,2),2,2);
% owtF_juncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,11),2,2);
% owtF_slncx_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,12),2,2);

owtF_jucal_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,9),2,2);
% owtF_y31_36_none_0(ipeak) = peakfinder(tflux,Fwt_none_0(ipeak).currents(:,26),2,2);
end
%% bp jucal integral
close all
figure(7)
bx = [[owtF_jucal_noneTPC_1(:).integralY],...
      [owtF_jucal_TPC_1(:).integralY],...
      [owtF_jucal_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_jucal_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_jucal_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_jucal_none_0(:).integralY]), 1);...           
       ];
   
boxplot(abs(bx), by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([1e2 14e2])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'Junctional L-type', '[Ca] Current (pA/pF)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'jucal'),'-dtiff','-r300')
close

%% bp serca integral
close all
figure(7)
bx = [[owtF_serca_noneTPC_1(:).integralY],...
      [owtF_serca_TPC_1(:).integralY],...
      [owtF_serca_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_serca_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_serca_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_serca_none_0(:).integralY]), 1);...             
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 5;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([0.25e5 4.5e5])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'SERCA [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'serca_1'),'-dtiff','-r300')
% close

%% bp RyR integral
close all
figure(7)
bx = [[owtF_ryr_noneTPC_1(:).integralY],...
      [owtF_ryr_TPC_1(:).integralY],...
      [owtF_ryr_none_0(:).integralY],...
      ]; 
by = [ zeros(length([owtF_ryr_noneTPC_1(:).integralY]), 1);...
       1*ones(length([owtF_ryr_TPC_1(:).integralY]), 1);...       
       2*ones(length([owtF_ryr_none_0(:).integralY]), 1);...            
       ];
   
boxplot(bx, by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
set(gca,'TickLabelInterpreter','Tex')
set(gca,'xtick',1:1:3)
% set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
set(gca,'xticklabel',{'WT','WT','WT'})
ax = gca;
ax. Position = [0.25 0.2 0.7 0.7];
ax.YAxis.Exponent = 6;
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
 
ylim([0.25e6 8e6])
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
ylabel({'RyR [Ca] Flux (nM)'})
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 600 600])
print(gcf, fullfile(pwd, 'ryr'),'-dtiff','-r300')
% close

% %% jusl_cal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_jusl_cal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_jusl_cal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_jusl_cal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jusl_cal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jusl_cal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jusl_cal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Balance (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jusl_cal_2ncx_ca'),'-dtiff','-r300')
% 
% 
% %% jutot_ca
% close
% figure(7)
% bx = [
%       [owtF_jutot_ca_noneTPC_1(:).integralY],...
%       [owtF_jutot_ca_TPC_1(:).integralY],...
%       [owtF_jutot_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jutot_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jutot_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jutot_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Balance (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jutot_ca'),'-dtiff','-r300')
% 
% %% juncx_ca
% close
% figure(7)
% bx = [
%       abs([owtF_juncx_ca_noneTPC_1(:).integralY]),...
%       abs([owtF_juncx_ca_TPC_1(:).integralY]),...
%       abs([owtF_juncx_ca_none_0(:).integralY]),...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([6e6 25e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] NCX Efflux (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca'),'-dtiff','-r300')
% 
% %% sr_in_out
% close
% figure(7)
% bx = [
%       [owtF_sr_in_out_noneTPC_1(:).integralY],...
%       [owtF_sr_in_out_TPC_1(:).integralY],...
%       [owtF_sr_in_out_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_sr_in_out_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_sr_in_out_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_sr_in_out_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-5e5 10e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'SR [Ca] Balance of SERCA Influx',' and RyR Efflux (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'sr_in_out'),'-dtiff','-r300')
% 
% 
% %% juncx_ca_srin
% close
% figure(7)
% bx = [
%       [owtF_juncx_ca_srin_in_noneTPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_TPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_srin_in_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_srin_in_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_srin_in_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% % ylabel({'Junctional [Ca] Difference of','Influxes and Effluxes (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca_srin'),'-dtiff','-r300')
% 
% %% juncx_ca_srin
% close
% figure(7)
% bx = [
%       [owtF_juncx_ca_srin_in_noneTPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_TPC_1(:).integralY],...
%       [owtF_juncx_ca_srin_in_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_juncx_ca_srin_in_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_ca_srin_in_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_ca_srin_in_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% % ylabel({'Junctional [Ca] Difference of','Influxes and Effluxes (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'juncx_ca_srin'),'-dtiff','-r300')
% 
% %% ju_in_out
% close
% figure(7)
% bx = [
%       [owtF_ju_in_out_noneTPC_1(:).integralY],...
%       [owtF_ju_in_out_TPC_1(:).integralY],...
%       [owtF_ju_in_out_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_ju_in_out_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_ju_in_out_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_ju_in_out_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% % ylim([-10e6 -2e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Difference of','Influxes (+) and Effluxes (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'ju_in_out'),'-dtiff','-r300')
% 
% %% jucal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_jucal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_jucal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_jucal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_jucal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_jucal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_jucal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 6;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-3e6 22e6])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional [Ca] Difference of CaL',' Influx (+) and NCX Efflux (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'jucal_2ncx_ca'),'-dtiff','-r300')
% 
% %% slcal_2ncx_ca
% close
% figure(7)
% bx = [
%       [owtF_slcal_2ncx_ca_noneTPC_1(:).integralY],...
%       [owtF_slcal_2ncx_ca_TPC_1(:).integralY],...
%       [owtF_slcal_2ncx_ca_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_slcal_2ncx_ca_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_slcal_2ncx_ca_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_slcal_2ncx_ca_none_0(:).integralY]), 1);...        
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 5;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([-6e5 0e5])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Sarcolemmal [Ca] Difference of CaL',' Influx (+) and NCX Efflux (-) (nM)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'slcal_2ncx_ca'),'-dtiff','-r300')

% %% bp cal integral
% figure(7)
% bx = [      [owtF_cal_noneTPC_1(:).integralY],...
%       [owtF_cal_TPC_1(:).integralY],...
%       [owtF_cal_none_0(:).integralY],...
% %       [jdot0F_cal_TPC_1(:).integralY],...
% %       [jdot0F_cal_noneTPC_1(:).integralY],...
% %       [jdot0F_cal_none_0(:).integralY],...
% %       [idot0F_cal_TPC_1(:).integralY],...
% %       [idot0F_cal_noneTPC_1(:).integralY],...
% %       [idot0F_cal_none_0(:).integralY],...
%       ]; 
% by = [ zeros(length([owtF_cal_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_cal_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_cal_none_0(:).integralY]), 1);...
% %        3*ones(length([jdot0F_cal_TPC_1(:).integralY]), 1);...       
% %        4*ones(length([jdot0F_cal_noneTPC_1(:).integralY]), 1);...
% %        5*ones(length([jdot0F_cal_none_0(:).integralY]), 1);...
% %        6*ones(length([idot0F_cal_TPC_1(:).integralY]), 1);...       
% %        7*ones(length([idot0F_cal_noneTPC_1(:).integralY]), 1);...
% %        8*ones(length([idot0F_cal_none_0(:).integralY]), 1);...              
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1.5e2 8e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'L-type Current (pA/pF)'})
% % title({'Hypercalcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'bp_cal_integralbeat'),'-dtiff','-r300')
% % close

% %% I_ncx
% figure(7)
% bx = [abs([owtF_ncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_ncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_ncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_ncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_ncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_ncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 20e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'NCX [Ca] Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx'),'-dtiff','-r300')
% % close
% 
% 
% %% bp I_ncx_junc
% figure(7)
% bx = [abs([owtF_juncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_juncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_juncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_juncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_juncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_juncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 4.6e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Junctional NCX Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx_junc'),'-dtiff','-r300')
% % close
% 
% %% bp I_ncx_sl
% figure(7)
% bx = [abs([owtF_slncx_noneTPC_1(:).integralY]).*2,...
%       abs([owtF_slncx_TPC_1(:).integralY]).*2,...
%       abs([owtF_slncx_none_0(:).integralY]).*2,...
%       ]; 
% by = [ zeros(length([owtF_slncx_noneTPC_1(:).integralY]), 1);...
%        1*ones(length([owtF_slncx_TPC_1(:).integralY]), 1);...       
%        2*ones(length([owtF_slncx_none_0(:).integralY]), 1);...
%        ];
%    
% boxplot(bx, by,'Notch','on','Colors','rbm');
% c = findobj(gca,'Tag','Box');
% set(gca,'TickLabelInterpreter','Tex')
% set(gca,'xtick',1:1:3)
% % set(gca,'xticklabel',{'WT','J_{ls,up} = 0','J_{ls,rel} = 0'})
% set(gca,'xticklabel',{'WT','WT','WT'})
% ax = gca;
% ax.YAxis.Exponent = 2;
% legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northwest');legend boxoff
%  
% ylim([1e2 6e2])
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',35)
% ylabel({'Sarcolemmal NCX [Ca]','Current (pA/pF)'})
% % title({'Hyperncxcemia and ISO',' '})
% title({' ',' '})
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 600 600])
% print(gcf, fullfile(pwd, 'I_ncx_sl'),'-dtiff','-r300')
% % close
%%

% % Sjdot0
% for ipeak = 1: numel(Sjdot0_TPC_1) 
% 
% t3 = Sjdot0_TPC_1(ipeak).t;
% y3 = Sjdot0_TPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% for ipeak = 1: numel(Sjdot0_noneTPC_1) 
% 
% t3 = Sjdot0_noneTPC_1(ipeak).t;
% y3 = Sjdot0_noneTPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% for ipeak = 1: numel(Sjdot0_none_0) 
% 
% t3 = Sjdot0_none_0(ipeak).t;
% y3 = Sjdot0_none_0(ipeak).y.*1e6;
% 
% % biomarkers for Sjdot0
% jdot0_y38_none_0(ipeak) = peakfinder(t3, y3(:,38),200,200);
% jdot0_y88_none_0(ipeak) = peakfinder(t3, y3(:,88),200,200);
% jdot0_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% jdot0_y36_none_0(ipeak) = peakfinder(t3, y3(:,36),200,200);
% end
% 
% % Sidot0
% for ipeak = 1: numel(Sidot0_TPC_1) 
% 
% t3 = Sidot0_TPC_1(ipeak).t;
% y3 = Sidot0_TPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_TPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_TPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_TPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_TPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end
% 
% for ipeak = 1: numel(Sidot0_noneTPC_1) 
% 
% t3 = Sidot0_noneTPC_1(ipeak).t;
% y3 = Sidot0_noneTPC_1(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_noneTPC_1(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_noneTPC_1(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_noneTPC_1(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_noneTPC_1(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end
% 
% for ipeak = 1: numel(Sidot0_none_0) 
% 
% t3 = Sidot0_none_0(ipeak).t;
% y3 = Sidot0_none_0(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38_none_0(ipeak) = peakfinder(t3, y3(:,38),200,200);
% idot0_y88_none_0(ipeak) = peakfinder(t3, y3(:,88),200,200);
% idot0_y31_none_0(ipeak) = srpeakfinder(t3, y3(:,31),200,200);
% idot0_y36_none_0(ipeak) = peakfinder(t3, y3(:,36),200,200);
% 
% end

% 
% % jdot0
% for ipeak = 1: numel(Fjdot0_TPC_1)
%    
% tflux = Fjdot0_TPC_1(ipeak).tArray;
% yserca = Fjdot0_TPC_1(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_TPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_TPC_1(ipeak).I_Ca_store);   
%  
% jdot0F_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2); 
% end
%  
% for ipeak = 1: numel(Fjdot0_noneTPC_1)
%    
% tflux = Fjdot0_noneTPC_1(ipeak).tArray;
% yserca = Fjdot0_noneTPC_1(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_noneTPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_noneTPC_1(ipeak).I_Ca_store);    
%  
% jdot0F_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);  
% end
%  
% for ipeak = 1: numel(Fjdot0_none_0)
%   
% tflux = Fjdot0_none_0(ipeak).tArray;
% yserca = Fjdot0_none_0(ipeak).Jserca.*1e6;    
% yryr = Fjdot0_none_0(ipeak).J_RyR.*1e6;  
% ycal = abs(Fjdot0_none_0(ipeak).I_Ca_store);    
%  
% jdot0F_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
% jdot0F_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
% jdot0F_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);   
% end
% 
% %idot0
% for ipeak = 1: numel(Fidot0_TPC_1)
%    
% tflux = Fidot0_TPC_1(ipeak).tArray;
% yserca = Fidot0_TPC_1(ipeak).Jserca.*1e6;    
% yryr = Fidot0_TPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_TPC_1(ipeak).I_Ca_store);  
%  
% idot0F_serca_TPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_TPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_TPC_1(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
%  
% for ipeak = 1: numel(Fidot0_noneTPC_1)
%    
% tflux = Fidot0_noneTPC_1(ipeak).tArray;
% yserca = Fidot0_noneTPC_1(ipeak).Jserca.*1e6;    
% yryr = Fidot0_noneTPC_1(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_noneTPC_1(ipeak).I_Ca_store);   
%  
% idot0F_serca_noneTPC_1(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_noneTPC_1(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_noneTPC_1(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
%  
% for ipeak = 1: numel(Fidot0_none_0)
%   
% tflux = Fidot0_none_0(ipeak).tArray;
% yserca = Fidot0_none_0(ipeak).Jserca.*1e6;    
% yryr = Fidot0_none_0(ipeak).J_RyR.*1e6;  
% ycal = abs(Fidot0_none_0(ipeak).I_Ca_store);   
%  
% idot0F_serca_none_0(ipeak) = peakfinder(tflux,yserca,200,200);
% idot0F_ryr_none_0(ipeak) = peakfinder(tflux,yryr,200,200);
% idot0F_cal_none_0(ipeak) = peakfinder(tflux,ycal,2,2);    
% end
