#!/bin/sh

#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --time=89:99:00
#SBATCH --job-name=h1_cao1_p2_wt_arc_ncx3
#SBATCH --output=h1_cao1_p2_wt_arc_ncx3.out
#SBATCH --mail-type=ALL
#SBATCH --mail-user=zhaozheng.meng@pharm.ox.ac.uk

echo "working directory = "$SLURM_SUBMIT_DIR
module purge
module load MATLAB/R2019b
matlab -nodisplay -nosplash < h1_cao1_p2_wt_arc_ncx3.m
 
# cp -avr $HOME/sf6/h1_cao1_p2_wt_arc_ncx3 $DATA/Ls_mv/
mv -v $HOME/sf6_ncx3/h1_cao1_p2_wt_arc_ncx3 $DATA/
