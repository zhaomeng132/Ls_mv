#!/bin/sh

#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --time=89:99:00
#SBATCH --job-name=h1_cao1_p2_idot0_arc
#SBATCH --output=h1_cao1_p2_idot0_arc.out
#SBATCH --mail-type=ALL
#SBATCH --mail-user=zhaozheng.meng@pharm.ox.ac.uk

echo "working directory = "$SLURM_SUBMIT_DIR
module purge
module load MATLAB/R2019b
matlab -nodisplay -nosplash < h1_cao1_p2_idot0_arc.m
 
# cp -avr $HOME/h1_cao1_p2_idot0_arc $DATA/Ls_mv/
mv -v $HOME/sf6/h1_cao1_p2_idot0_arc $DATA/
