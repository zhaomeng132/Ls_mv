clear 
close all
addpath('~/downloads/Ls_mv_sf6_meng15/plot_h1_cao1_p123_sf6')

cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat
sf1000_0 = h1_cao1_sf1000_sf6_0;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p1_wtlocal_idot0arc_sf6

load y175_WT_wt15_naadp=01_Ligtot=0.0_1hz_150beat.mat
S1w = S(sf1000_0);
load y175_i_dot0_wt_naadp=01_Ligtot=0.0_1hz_150beat.mat
S1o = S(sf1000_0);

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p2_arc

load y175_WT_naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
S2w = S(sf1000_0);
load y175_i_dot0_naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
S2o = S(sf1000_0);
          
cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p3_arc

load y175_WT_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
S3w = S(sf1000_0);
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
S3o = S(sf1000_0);


cd ~/downloads/Ls_mv_sf6_meng15
mkdir(['./','fig3'])
cd(['./','fig3'])

%% plot trace
Y = [88,38,31,36,37];
Yspace = {'Lysosome','Cytosol','SR','Junction','SL'};
yaxis_lim = [4,2,4,4,3];
for SP = 1: 2%numel(Y)
for idad = 1 : 1%numel(sf1000_0)
    y1w = S1w(idad).y;
    t1w = S1w(idad).t;
    y2w = S2w(idad).y;
    t2w = S2w(idad).t;
    y3w = S3w(idad).y;
    t3w = S3w(idad).t;
    figure(60);
    ax1 = subplot(1,1,1);
    p1 = plot(t1w,y1w(:,Y(SP)).*1e6,'k:');%p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p2 = plot(t2w,y2w(:,Y(SP)).*1e6,'k--');%p2.Color(2) = 1;%  38 cytosolic space
    p3 = plot(t3w,y3w(:,Y(SP)).*1e6,'k-');%p3.Color(3) = 1;%  38 cytosolic space
end 

for idad = 1 : 1%numel(sf1000_0)
    y1o = S1o(idad).y;
    t1o = S1o(idad).t;
    y2o = S2o(idad).y;
    t2o = S2o(idad).t;
    y3o = S3o(idad).y;
    t3o = S3o(idad).t;
    figure(61);
    ax2 = subplot(1,1,1);
    p4 = plot(t1o,y1o(:,Y(SP)).*1e6,'k:');%p1.Color(4) = 0.2; %  38 cytosolic space
    hold on
    p5 = plot(t2o,y2o(:,Y(SP)).*1e6,'k--');%p2.Color(4) = 0.2; %  38 cytosolic space
    p6 = plot(t3o,y3o(:,Y(SP)).*1e6,'k-');%p3.Color(4) = 0.2; %  38 cytosolic space
end

    linkaxes([ax1,ax2],'y');
    yaxis = yaxis_lim(SP);
    fontsize = 40;
    
    f60 = figure(60);
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 3
    legend( [p1 p2 p3], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
    else
    legend( [p1 p2 p3], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
    end
    
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');     
    if SP == 1
    title({'WT_{ }',' '});
    else 
    title({' ',' '});
    end   
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
    set(findobj(gcf,'type','axes'),'box','off') 
    
    f61 = figure(61);  
    ax = gca;
    ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = yaxis;
    if SP == 3
    legend( [p4 p5 p6], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
    else
    legend( [p4 p5 p6], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
    end
    ylabel(sprintf('[Ca] %s (nM)',Yspace{SP}));xlabel('Time (ms)');    
    if SP == 1
    title({'TPC-KO_{ }',' '});
    else 
    title({' ',' '});
    end   
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
    set(findobj(gcf,'type','axes'),'box','off') 
    hold off 
    
    
set(f60,'Units','pixels','Position',[0 0 700 500]) 
set(f61,'Units','pixels','Position',[0 0 700 500])
 
print(f60, fullfile(pwd, sprintf('h1_cao1dot_ %s 1',Yspace{SP})),'-dtiff','-r500');
print(f61, fullfile(pwd, sprintf('h1_cao1dot_ %s 2',Yspace{SP})),'-dtiff','-r500');
 
close all
end

%% inset
close all
Y = [88,38,31,36,37];
Yspace = {'Lysosome','Cytosol','SR','Junction','SL'};
yaxis_lim = [4,2,4,4,3];

for SP = 1 : 2%numel(Y)
for idad = 1 : 1%numel(sf1000_0)
    y1w = S1w(idad).y;
    t1w = S1w(idad).t;
    y2w = S2w(idad).y;
    t2w = S2w(idad).t;
    y3w = S3w(idad).y;
    t3w = S3w(idad).t;
    figure(60);
    ax1 = subplot(1,1,1);
    p1 = plot(t1w,y1w(:,Y(SP)).*1e6,'k:');%p1.Color(1) = 1;%  38 cytosolic space
    hold on
    p2 = plot(t2w,y2w(:,Y(SP)).*1e6,'k--');%p2.Color(2) = 1;%  38 cytosolic space
    p3 = plot(t3w,y3w(:,Y(SP)).*1e6,'k-');%p3.Color(3) = 1;%  38 cytosolic space
end 

for idad = 1 : 1%numel(sf1000_0)
    y1o = S1o(idad).y;
    t1o = S1o(idad).t;
    y2o = S2o(idad).y;
    t2o = S2o(idad).t;
    y3o = S3o(idad).y;
    t3o = S3o(idad).t;
    figure(61);
    ax2 = subplot(1,1,1);
    p4 = plot(t1o,y1o(:,Y(SP)).*1e6,'k:');%p1.Color(4) = 0.2; %  38 cytosolic space
    hold on
    p5 = plot(t2o,y2o(:,Y(SP)).*1e6,'k--');%p2.Color(4) = 0.2; %  38 cytosolic space
    p6 = plot(t3o,y3o(:,Y(SP)).*1e6,'k-');%p3.Color(4) = 0.2; %  38 cytosolic space
end

    linkaxes([ax1,ax2],'y');
    yaxis = yaxis_lim(SP);
    fontsize = 70;
    
    f60 = figure(60);
    ax = gca;
    xlim([0 100])
    ax.YAxis.Exponent = yaxis;
    
    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
    set(findobj(gcf,'type','axes'),'box','off') 
    
    f61 = figure(61);  
    ax = gca;
    xlim([0 100])    
    ax.YAxis.Exponent = yaxis;

    set(gca, 'FontName','Times New Roman','FontSize',fontsize)
    set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
    set(findobj(gcf,'type','axes'),'box','off') 
    hold off 
    
    
set(f60,'Units','pixels','Position',[0 0 700 500]) 
set(f61,'Units','pixels','Position',[0 0 700 500])
 
print(f60, fullfile(pwd, sprintf('h1_cao1dot_inset %s 1',Yspace{SP})),'-dtiff','-r500');
print(f61, fullfile(pwd, sprintf('h1_cao1dot_inset %s 2',Yspace{SP})),'-dtiff','-r500');

close all
end
%% bp
%% idot0
for idad = 1 : numel(sf1000_0)
    y1o = S1o(idad).y;
    t1o = S1o(idad).t;
    y2o = S2o(idad).y;
    t2o = S2o(idad).t;
    y3o = S3o(idad).y;
    t3o = S3o(idad).t;
    per = 0.8;

    [y1stpeakamp1o(idad).y38] = dp(t1o,y1o(:,38).*1e6,per); % cytosolic space
    [y1stpeakamp1o(idad).y38min] = min(y1o(:,38).*1e6); % cytosolic space min
    [y1stpeakamp1o(idad).y31] = dp(t1o,y1o(:,31).*1e6,per); % SR
    [y1stpeakamp1o(idad).y36] = dp(t1o,y1o(:,36).*1e6,per); % Dyadic space
    [y1stpeakamp1o(idad).y88] = dp(t1o,y1o(:,88).*1e6,per); % lysosome
    [y1stpeakamp1o(idad).y26] = dp(t1o,y1o(:,26).*1e6,per); % low cleft
    [y1stpeakamp1o(idad).y27] = dp(t1o,y1o(:,27).*1e6,per); % low sl
    [y1stpeakamp1o(idad).y28] = dp(t1o,y1o(:,28).*1e6,per); % high cleft
    [y1stpeakamp1o(idad).y29] = dp(t1o,y1o(:,29).*1e6,per); % high sl
    [y1stpeakamp1o(idad).y37] = dp(t1o,y1o(:,37).*1e6,per); % sl
    
    [y1stpeakamp2o(idad).y38] = dp(t2o,y2o(:,38).*1e6,per);
    [y1stpeakamp2o(idad).y38min] = min(y2o(:,38).*1e6); % cytosolic space min
    [y1stpeakamp2o(idad).y31] = dp(t2o,y2o(:,31).*1e6,per);
    [y1stpeakamp2o(idad).y36] = dp(t2o,y2o(:,36).*1e6,per);
    [y1stpeakamp2o(idad).y88] = dp(t2o,y2o(:,88).*1e6,per);
    [y1stpeakamp2o(idad).y26] = dp(t2o,y2o(:,26).*1e6,per);
    [y1stpeakamp2o(idad).y27] = dp(t2o,y2o(:,27).*1e6,per);
    [y1stpeakamp2o(idad).y28] = dp(t2o,y2o(:,28).*1e6,per);
    [y1stpeakamp2o(idad).y29] = dp(t2o,y2o(:,29).*1e6,per);
    [y1stpeakamp2o(idad).y37] = dp(t2o,y2o(:,37).*1e6,per); 
    
    [y1stpeakamp3o(idad).y38] = dp(t3o,y3o(:,38).*1e6,per);
    [y1stpeakamp3o(idad).y38min] = min(y3o(:,38).*1e6); % cytosolic space min
    [y1stpeakamp3o(idad).y31] = dp(t3o,y3o(:,31).*1e6,per);
    [y1stpeakamp3o(idad).y36] = dp(t3o,y3o(:,36).*1e6,per);
    [y1stpeakamp3o(idad).y88] = dp(t3o,y3o(:,88).*1e6,per);
    [y1stpeakamp3o(idad).y26] = dp(t3o,y3o(:,26).*1e6,per); 
    [y1stpeakamp3o(idad).y27] = dp(t3o,y3o(:,27).*1e6,per); 
    [y1stpeakamp3o(idad).y28] = dp(t3o,y3o(:,28).*1e6,per);
    [y1stpeakamp3o(idad).y29] = dp(t3o,y3o(:,29).*1e6,per); 
    [y1stpeakamp3o(idad).y37] = dp(t3o,y3o(:,37).*1e6,per); % sl
end 
%% wt
for idad = 1 : numel(sf1000_0)
    y1w = S1w(idad).y;
    t1w = S1w(idad).t;
    y2w = S2w(idad).y;
    t2w = S2w(idad).t;
    y3w = S3w(idad).y;
    t3w = S3w(idad).t;
            
    [y1stpeakamp1w(idad).y38] = dp(t1w,y1w(:,38).*1e6,per); % cytosolic space
    [y1stpeakamp1w(idad).y38min] = min(y1w(:,38).*1e6); % cytosolic space
    [y1stpeakamp1w(idad).y31] = dp(t1w,y1w(:,31).*1e6,per); % SR
    [y1stpeakamp1w(idad).y36] = dp(t1w,y1w(:,36).*1e6,per); % Dyadic space
    [y1stpeakamp1w(idad).y88] = dp(t1w,y1w(:,88).*1e6,per); % lysosome
    [y1stpeakamp1w(idad).y26] = dp(t1w,y1w(:,26).*1e6,per); % low cleft
    [y1stpeakamp1w(idad).y27] = dp(t1w,y1w(:,27).*1e6,per); % low SL
    [y1stpeakamp1w(idad).y28] = dp(t1w,y1w(:,28).*1e6,per); % high cleft
    [y1stpeakamp1w(idad).y29] = dp(t1w,y1w(:,29).*1e6,per); % high SL
    [y1stpeakamp1w(idad).y37] = dp(t1w,y1w(:,37).*1e6,per); % sl

    [y1stpeakamp2w(idad).y38] = dp(t2w,y2w(:,38).*1e6,per);
    [y1stpeakamp2w(idad).y38min] = min(y2w(:,38).*1e6); % cytosolic space    
    [y1stpeakamp2w(idad).y31] = dp(t2w,y2w(:,31).*1e6,per);
    [y1stpeakamp2w(idad).y36] = dp(t2w,y2w(:,36).*1e6,per);
    [y1stpeakamp2w(idad).y88] = dp(t2w,y2w(:,88).*1e6,per);
    [y1stpeakamp2w(idad).y26] = dp(t2w,y2w(:,26).*1e6,per); 
    [y1stpeakamp2w(idad).y27] = dp(t2w,y2w(:,27).*1e6,per); 
    [y1stpeakamp2w(idad).y28] = dp(t2w,y2w(:,28).*1e6,per);
    [y1stpeakamp2w(idad).y29] = dp(t2w,y2w(:,29).*1e6,per);
    [y1stpeakamp2w(idad).y37] = dp(t2w,y2w(:,37).*1e6,per); 

    [y1stpeakamp3w(idad).y38] = dp(t3w,y3w(:,38).*1e6,per);
    [y1stpeakamp3w(idad).y38min] = min(y3w(:,38).*1e6); % cytosolic space    
    [y1stpeakamp3w(idad).y31] = dp(t3w,y3w(:,31).*1e6,per);
    [y1stpeakamp3w(idad).y36] = dp(t3w,y3w(:,36).*1e6,per);
    [y1stpeakamp3w(idad).y88] = dp(t3w,y3w(:,88).*1e6,per);
    [y1stpeakamp3w(idad).y26] = dp(t3w,y3w(:,26).*1e6,per);
    [y1stpeakamp3w(idad).y27] = dp(t3w,y3w(:,27).*1e6,per);
    [y1stpeakamp3w(idad).y28] = dp(t3w,y3w(:,28).*1e6,per); 
    [y1stpeakamp3w(idad).y29] = dp(t3w,y3w(:,29).*1e6,per);
    [y1stpeakamp3w(idad).y37] = dp(t3w,y3w(:,37).*1e6,per);
end 
%% stats standard error
% naadp wt
mean_p2w_p1w = mean(([y1stpeakamp2w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38])
sd_p2w_p1w = std(([y1stpeakamp2w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38]);
se_p2w_p1w = sd_p2w_p1w./sqrt(length([y1stpeakamp2w(:).y38]))

% naadp idot0
mean_p2o_p1o = mean(([y1stpeakamp2o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38])
sd_p2o_p1o = std(([y1stpeakamp2o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38]);
se_p2o_p1o = sd_p2o_p1o./sqrt(length([y1stpeakamp2o(:).y38]))

% iso wt
mean_p3w_p1w = mean(([y1stpeakamp3w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38])
sd_p3w_p1w = std(([y1stpeakamp3w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38]);
se_p3w_p1w = sd_p3w_p1w./sqrt(length([y1stpeakamp3w(:).y38]))

% iso idot0
mean_p3o_p1o = mean(([y1stpeakamp3o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38])
sd_p3o_p1o = std(([y1stpeakamp3o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38]);
se_p3o_p1o = sd_p3o_p1o./sqrt(length([y1stpeakamp3o(:).y38]))

%% fold 
p2w_1w_y88 = median([y1stpeakamp2w(:).y88])/median([y1stpeakamp1w(:).y88])
p2o_1o_y88 = median([y1stpeakamp2o(:).y88])/median([y1stpeakamp1o(:).y88])

p2w_1w_y38 = median([y1stpeakamp2w(:).y38])/median([y1stpeakamp1w(:).y38])
p2o_1o_y38 = median([y1stpeakamp2o(:).y38])/median([y1stpeakamp1o(:).y38])

p2w_1w_y31 = median([y1stpeakamp2w(:).y31])/median([y1stpeakamp1w(:).y31])
p2o_1o_y31 = median([y1stpeakamp2o(:).y31])/median([y1stpeakamp1o(:).y31])

p3w_1w_y88 = median([y1stpeakamp3w(:).y88])/median([y1stpeakamp1w(:).y88])
p3o_1o_y88 = median([y1stpeakamp3o(:).y88])/median([y1stpeakamp1o(:).y88])

p3w_1w_y38 = median([y1stpeakamp3w(:).y38])/median([y1stpeakamp1w(:).y38])
p3o_1o_y38 = median([y1stpeakamp3o(:).y38])/median([y1stpeakamp1o(:).y38])
p3w_3o_y38 = median([y1stpeakamp3w(:).y38])/median([y1stpeakamp3o(:).y38])

p3w_1w_y31 = median([y1stpeakamp3w(:).y31])/median([y1stpeakamp1w(:).y31])
p3o_1o_y31 = median([y1stpeakamp3o(:).y31])/median([y1stpeakamp1o(:).y31])

% %% biomarkers
% 
% for ipeak = 1: numel(S1w) 
% 
% t1w = S1w(ipeak).t;
% y1w = S1w(ipeak).y.*1e6;
% 
% % biomarkers for Swt
% owt1_y38(ipeak) = peakfinder(t1w, y1w(:,38),200,200);
% owt1_y88(ipeak) = peakfinder(t1w, y1w(:,88),200,200);
% % owt_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
% owt1_y36(ipeak) = peakfinder(t1w, y1w(:,36),200,200);
% owt1_y37(ipeak) = peakfinder(t1w, y1w(:,37),200,200);
% 
% % owt1_y31_y36(ipeak) = y31_y36_peakfinder(t1w, y1w(:,31),200,200, y3w(:,36));
% % owt1_y30_y36(ipeak) = y31_y36_peakfinder(t1w, y1w(:,30),200,200, y3w(:,36));
% % figure(1)
% % plot(t3w, y3w(:,31));hold on
% % plot(t3w(owt_y31_y36(ipeak).valleyI), y3w(owt_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
% end
% 
% 
% for ipeak = 1: numel(S1o) 
% 
% t1o = S1o(ipeak).t;
% y1o = S1o(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38(ipeak) = peakfinder(t1o, y1o(:,38),200,200);
% idot0_y88(ipeak) = peakfinder(t1o, y1o(:,88),200,200);
% % idot0_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
% idot0_y36(ipeak) = peakfinder(t1o, y1o(:,36),200,200);
% idot0_y37(ipeak) = peakfinder(t1o, y1o(:,37),200,200);
% 
% % idot0_y31_y36(ipeak) = y31_y36_peakfinder(t1o, y1o(:,31),200,200, y3w(:,36));
% % idot0_y30_y36(ipeak) = y31_y36_peakfinder(t1o, y1o(:,30),200,200, y3w(:,36));
% 
% % figure(3)
% % plot(t3w, y3w(:,31));hold on
% % plot(t3w(idot0_y31_y36(ipeak).valleyI), y3w(idot0_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
% end
% 
% for ipeak = 1: numel(S1w) 
% 
% t2w = S1w(ipeak).t;
% y1w = S1w(ipeak).y.*1e6;
% 
% % biomarkers for Swt
% owt_y38(ipeak) = peakfinder(t2w, y1w(:,38),200,200);
% owt_y88(ipeak) = peakfinder(t2w, y1w(:,88),200,200);
% % owt_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
% owt_y36(ipeak) = peakfinder(t2w, y1w(:,36),200,200);
% owt_y37(ipeak) = peakfinder(t2w, y1w(:,37),200,200);
% 
% owt_y31_y36(ipeak) = y31_y36_peakfinder(t2w, y1w(:,31),200,200, y3w(:,36));
% owt_y30_y36(ipeak) = y31_y36_peakfinder(t2w, y1w(:,30),200,200, y3w(:,36));
% % figure(1)
% % plot(t3w, y3w(:,31));hold on
% % plot(t3w(owt_y31_y36(ipeak).valleyI), y3w(owt_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
% end
% 
% 
% for ipeak = 1: numel(S1o) 
% 
% t2o = S1o(ipeak).t;
% y1o = S1o(ipeak).y.*1e6;
% 
% % biomarkers for Sidot0 
% idot0_y38(ipeak) = peakfinder(t2o, y1o(:,38),200,200);
% idot0_y88(ipeak) = peakfinder(t2o, y1o(:,88),200,200);
% % idot0_y31(ipeak) = srpeakfinder(t3w, y3w(:,31),200,200);
% idot0_y36(ipeak) = peakfinder(t2o, y1o(:,36),200,200);
% idot0_y37(ipeak) = peakfinder(t2o, y1o(:,37),200,200);
% 
% idot0_y31_y36(ipeak) = y31_y36_peakfinder(t2o, y1o(:,31),200,200, y3w(:,36));
% idot0_y30_y36(ipeak) = y31_y36_peakfinder(t2o, y1o(:,30),200,200, y3w(:,36));
% 
% % figure(3)
% % plot(t3w, y3w(:,31));hold on
% % plot(t3w(idot0_y31_y36(ipeak).valleyI), y3w(idot0_y31_y36(ipeak).valleyI,31),'r.','markersize',30);
% end

%% bp y38 wt vs tpcko
close
figure(90)
bx = [[y1stpeakamp1w(:).y38]';...
      [y1stpeakamp1o(:).y38]';...
      [y1stpeakamp2w(:).y38]';...
      [y1stpeakamp2o(:).y38]';...
      [y1stpeakamp3w(:).y38]';...
      [y1stpeakamp3o(:).y38]';...
      ]; 
by = [  zeros(length([y1stpeakamp1w(:).y38]), 1);...
       1*ones(length([y1stpeakamp1o(:).y38]), 1);...
       2*ones(length([y1stpeakamp2w(:).y38]), 1);...
       3*ones(length([y1stpeakamp2o(:).y38]), 1);...
       4*ones(length([y1stpeakamp3w(:).y38]), 1);...
       5*ones(length([y1stpeakamp3o(:).y38]), 1);...
       ];
b = boxplot(bx, by,'Notch','on','Colors','k');

n = findobj(gcf,'tag','Outliers');
for i = 1: numel(n)
set(n(i), 'MarkerEdgeColor',[0 0 0]);
end

ylabel('[Ca] Cytosol (nM)')
    title({' ',' '})    

set(b(:,1),'LineWidth',4);
set(b(:,3),'LineWidth',4);
set(b(:,5),'LineWidth',4);
set(b(:,2),'LineWidth',2);
set(b(:,4),'LineWidth',2);
set(b(:,6),'LineWidth',2);

c = findobj(gca,'Tag','Box');
legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff

ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ylim([0 17e2])   
    ax.YAxis.Exponent = 2;
set(gca,'xtick',1.5:2:5.5, 'XTickLabelRotation',0)
set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf,fullfile('F3_cs'),'-dtiff','-r500');
 

% %% y31 sr
% figure(90)
% bx = [[y1stpeakamp1w(:).y31]';...
%       [y1stpeakamp1o(:).y31]';...
%       [y1stpeakamp2w(:).y31]';...
%       [y1stpeakamp2o(:).y31]';...
%       [y1stpeakamp3w(:).y31]';...
%       [y1stpeakamp3o(:).y31]';...
%       ]; 
% by = [  zeros(length([y1stpeakamp1w(:).y31]), 1);...
%        1*ones(length([y1stpeakamp1o(:).y31]), 1);...
%        2*ones(length([y1stpeakamp2w(:).y31]), 1);...
%        3*ones(length([y1stpeakamp2o(:).y31]), 1);...
%        4*ones(length([y1stpeakamp3w(:).y31]), 1);...
%        5*ones(length([y1stpeakamp3o(:).y31]), 1);...
%        ];
% boxplot(bx, by,'Notch','on','Colors','kr') 
% c = findobj(gca,'Tag','Box');
% legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
% ylabel('[Ca] SR (nM)')
%     title({' ',' '})
% ax = gca;
%     ax.YAxis.Exponent = 5;    
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf,fullfile('F4-sr'),'-dtiff','-r500');

%% y31 junction
figure(90)
bx = [[y1stpeakamp1w(:).y36]';...
      [y1stpeakamp1o(:).y36]';...
      [y1stpeakamp2w(:).y36]';...
      [y1stpeakamp2o(:).y36]';...
      [y1stpeakamp3w(:).y36]';...
      [y1stpeakamp3o(:).y36]';...
      ]; 
by = [  zeros(length([y1stpeakamp1w(:).y36]), 1);...
       1*ones(length([y1stpeakamp1o(:).y36]), 1);...
       2*ones(length([y1stpeakamp2w(:).y36]), 1);...
       3*ones(length([y1stpeakamp2o(:).y36]), 1);...
       4*ones(length([y1stpeakamp3w(:).y36]), 1);...
       5*ones(length([y1stpeakamp3o(:).y36]), 1);...
       ];
b = boxplot(bx, by,'Notch','on','Colors','k');

n = findobj(gcf,'tag','Outliers');
for i = 1: numel(n)
set(n(i), 'MarkerEdgeColor',[0 0 0]);
end

ylabel('[Ca] Junction (nM)')
    title({' ',' '})    

set(b(:,1),'LineWidth',4);
set(b(:,3),'LineWidth',4);
set(b(:,5),'LineWidth',4);
set(b(:,2),'LineWidth',2);
set(b(:,4),'LineWidth',2);
set(b(:,6),'LineWidth',2);

c = findobj(gca,'Tag','Box');
legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff

ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ylim([0 70e4])   
    ax.YAxis.Exponent = 5;
set(gca,'xtick',1.5:2:5.5, 'XTickLabelRotation',0)
set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf,fullfile('F3_junction'),'-dtiff','-r500');

%% bp y88 wt vs tpcko
figure(90)
bx = [[y1stpeakamp1w(:).y88]';...
      [y1stpeakamp1o(:).y88]';...
      [y1stpeakamp2w(:).y88]';...
      [y1stpeakamp2o(:).y88]';...
      [y1stpeakamp3w(:).y88]';...
      [y1stpeakamp3o(:).y88]';...
      ]; 
by = [  zeros(length([y1stpeakamp1w(:).y88]), 1);...
       1*ones(length([y1stpeakamp1o(:).y88]), 1);...
       2*ones(length([y1stpeakamp2w(:).y88]), 1);...
       3*ones(length([y1stpeakamp2o(:).y88]), 1);...
       4*ones(length([y1stpeakamp3w(:).y88]), 1);...
       5*ones(length([y1stpeakamp3o(:).y88]), 1);...
       ];
b = boxplot(bx, by,'Notch','on','Colors','kk'); 
n = findobj(gcf,'tag','Outliers');
for i = 1: numel(n)
set(n(i), 'MarkerEdgeColor',[0 0 0]);
end

ylabel('[Ca] Lysosome (nM)')
    title({' ',' '})

set(b(:,1),'LineWidth',4);
set(b(:,3),'LineWidth',4);
set(b(:,5),'LineWidth',4);
set(b(:,2),'LineWidth',2);
set(b(:,4),'LineWidth',2);
set(b(:,6),'LineWidth',2);

c = findobj(gca,'Tag','Box');
legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff

ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ylim([0 20e4])    
    ax.YAxis.Exponent = 4;
set(gca,'xtick',1.5:2:5.5, 'XTickLabelRotation',0)
set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf,fullfile('F3_ls'),'-dtiff','-r500');


% %% sl
% figure(90)
% bx = [[y1stpeakamp1w(:).y37]';...
%       [y1stpeakamp1o(:).y37]';...
%       [y1stpeakamp2w(:).y37]';...
%       [y1stpeakamp2o(:).y37]';...
%       [y1stpeakamp3w(:).y37]';...
%       [y1stpeakamp3o(:).y37]';...
%       ]; 
% by = [  zeros(length([y1stpeakamp1w(:).y37]), 1);...
%        1*ones(length([y1stpeakamp1o(:).y37]), 1);...
%        2*ones(length([y1stpeakamp2w(:).y37]), 1);...
%        3*ones(length([y1stpeakamp2o(:).y37]), 1);...
%        4*ones(length([y1stpeakamp3w(:).y37]), 1);...
%        5*ones(length([y1stpeakamp3o(:).y37]), 1);...
%        ];
% boxplot(bx, by,'Notch','on','Colors','bk') 
% c = findobj(gca,'Tag','Box');
% legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
% ylabel('[Ca] SL (nM)')
%     title({' ',' '})
% ax = gca;
%     ax.YAxis.Exponent = 3;
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf,fullfile('F4-SL'),'-dtiff','-r500');


% %% pcc
% for idad = 1 : numel(sf1000_0)
%     y1o = S1o(idad).y;
%     t1o = S1o(idad).t;
%     y2o = S2o(idad).y;
%     t2o = S2o(idad).t;
%     y3o = S3o(idad).y;
%     t3o = S3o(idad).t;
%     ca_per50 = 0.5;
%     ca_per80 = 0.8;
%     [ca_RT50o1(idad),ca_RT80o1(idad),ca_peako1(idad),ca_y_rmpo1(idad),ca_ampo1(idad),y_minCao1(idad),yendCaTo1(idad)] = per_cat_fun(t1o,y1o(:,38),ca_per50,ca_per80);  
%     [ca_RT50o2(idad),ca_RT80o2(idad),ca_peako2(idad),ca_y_rmpo2(idad),ca_ampo2(idad),y_minCao2(idad),yendCaTo2(idad)] = per_cat_fun(t2o,y2o(:,38),ca_per50,ca_per80);  
%     [ca_RT50o3(idad),ca_RT80o3(idad),ca_peako3(idad),ca_y_rmpo3(idad),ca_ampo3(idad),y_minCao3(idad),yendCaTo3(idad)] = per_cat_fun(t3o,y3o(:,38),ca_per50,ca_per80);  
%     ap_per = 0.9;
%     [ap_apdo1(idad), ap_peako1(idad),ap_y_rmpo1(idad),ap_ampo1(idad),ap_maxdVmdto1(idad)] = per_apd_fun(t1o,y1o(:,39),ap_per);
%     [ap_apdo2(idad), ap_peako2(idad),ap_y_rmpo2(idad),ap_ampo2(idad),ap_maxdVmdto2(idad)] = per_apd_fun(t2o,y2o(:,39),ap_per);
%     [ap_apdo3(idad), ap_peako3(idad),ap_y_rmpo3(idad),ap_ampo3(idad),ap_maxdVmdto3(idad)] = per_apd_fun(t3o,y3o(:,39),ap_per);
% end 
% 
% %% find W nondad
% for wdad = 1 : numel(sf1000_0)
%     y1w = S1w(wdad).y;
%     t1w = S1w(wdad).t;
%     y2w = S2w(wdad).y;
%     t2w = S2w(wdad).t;
%     y3w = S3w(wdad).y;
%     t3w = S3w(wdad).t;
%     ca_per50 = 0.5;
%     ca_per80 = 0.8;
%     [ca_RT50w1(wdad),ca_RT80w1(wdad),ca_peakw1(wdad),ca_y_rmpw1(wdad),ca_ampw1(wdad),y_minCaw1(wdad),yendCaTw1(wdad)] = per_cat_fun(t1w,y1w(:,38),ca_per50,ca_per80);    
%     [ca_RT50w2(wdad),ca_RT80w2(wdad),ca_peakw2(wdad),ca_y_rmpw2(wdad),ca_ampw2(wdad),y_minCaw2(wdad),yendCaTw2(wdad)] = per_cat_fun(t2w,y2w(:,38),ca_per50,ca_per80);    
%     [ca_RT50w3(wdad),ca_RT80w3(wdad),ca_peakw3(wdad),ca_y_rmpw3(wdad),ca_ampw3(wdad),y_minCaw3(wdad),yendCaTw3(wdad)] = per_cat_fun(t3w,y3w(:,38),ca_per50,ca_per80);    
%     ap_per = 0.9;
%     [ap_apdw1(wdad), ap_peakw1(wdad),ap_y_rmpw1(wdad),ap_ampw1(wdad),ap_maxdVmdtw1(wdad)] = per_apd_fun(t1w,y1w(:,39),ap_per);
%     [ap_apdw2(wdad), ap_peakw2(wdad),ap_y_rmpw2(wdad),ap_ampw2(wdad),ap_maxdVmdtw2(wdad)] = per_apd_fun(t2w,y2w(:,39),ap_per);
%     [ap_apdw3(wdad), ap_peakw3(wdad),ap_y_rmpw3(wdad),ap_ampw3(wdad),ap_maxdVmdtw3(wdad)] = per_apd_fun(t3w,y3w(:,39),ap_per);
% end 
% 
% rng('default');                 % for reproducibility of results
% lhs_p = 9;                      % number of parameters
% lhs_n = 1000;                   % number of models (combinations)  
% X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
% lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
% ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
% sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
% sf = sf(sf1000_0,:);
% protocol = {'CTRL', 'NAADP-AM','ISO'};
% 
% figure(1)
% x = [ca_RT50w1',ca_RT80w1',ca_y_rmpw1',ca_ampw1',ap_apdw1',ap_peakw1',ap_y_rmpw1',ap_ampw1'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 1; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'WT'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-1'),'-dtiff','-r500');
% 
% figure(2)
% x = [ca_RT50w2',ca_RT80w2',ca_y_rmpw2',ca_ampw2',ap_apdw2',ap_peakw2',ap_y_rmpw2',ap_ampw2'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 2; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'WT'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-2'),'-dtiff','-r500');
% 
% figure(3)
% x = [ca_RT50w3',ca_RT80w3',ca_y_rmpw3',ca_ampw3',ap_apdw3',ap_peakw3',ap_y_rmpw3',ap_ampw3'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 3; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'WT'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-3'),'-dtiff','-r500');
% 
% close all
% 
% figure(1)
% x = [ca_RT50o1',ca_RT80o1',ca_y_rmpo1',ca_ampo1',ap_apdo1',ap_peako1',ap_y_rmpo1',ap_ampo1'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 1; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'TPC-KO'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-1_tpc-ko'),'-dtiff','-r500');
% 
% figure(2)
% x = [ca_RT50o2',ca_RT80o2',ca_y_rmpo2',ca_ampo2',ap_apdo2',ap_peako2',ap_y_rmpo2',ap_ampo2'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 2; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'TPC-KO'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-2_tpc-ko'),'-dtiff','-r500');
% 
% figure(3)
% x = [ca_RT50o3',ca_RT80o3',ca_y_rmpo3',ca_ampo3',ap_apdo3',ap_peako3',ap_y_rmpo3',ap_ampo3'];
% y = sf;
% [rho_s,pval_s] = partialcorri(x,y,'type','Spearman');
% yv= {['Ca_{RT',num2str(ca_per50*100),'}'],['Ca_{RT',num2str(ca_per80*100),'}'],'Ca_{Dia}','Ca_{AMP}',['AP_{APD',num2str(ap_per*100),'}'],'AP_{Peak}','AP_{RMP}','AP_{AMP}'};
% xv= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
% hs=heatmap(xv,yv,round(rho_s,+2),'ColorLimits',[-1 1]);colormap('redblue')
% P = 3; 
% hs.Title = {sprintf('%s Protocol',protocol{P}),'TPC-KO'};
% set(gca, 'FontName','Times New Roman','FontSize',40)
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 1600 1000])
% print(gcf,fullfile('pcc-3_tpc-ko'),'-dtiff','-r500');
% 
% close all
%% load fluxes wt 1000

Cond = {'TPC-KO','WT'};
cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_sf1000_p123_FLUX_


load y175_FLUX_WT_herz1_cao1__wt_naadp=01_Ligtot=0.0_1hz_150beat.mat
F1w = F(sf1000_0);
    load y175_FLUX_WT_herz1_cao1__naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
    F2w = F(sf1000_0);
        load y175_FLUX_WT_herz1_cao1__iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
        F3w = F(sf1000_0);
     
load y175_FLUX_WT_i_dot0_cao1__wt_naadp=01_Ligtot=0.0_1hz_150beat.mat
F1o = F(sf1000_0);
    load y175_FLUX_WT_i_dot0_cao1__naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
    F2o = F(sf1000_0);
        load y175_FLUX_WT_i_dot0_cao1__iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
        F3o = F(sf1000_0);

cd ~/downloads/Ls_mv_sf6_meng15
mkdir(['./','fig3'])
cd(['./','fig3'])

%% plot flux
% WT
for idad = 1: 1%numel(sf1000_0)
    
    figure(8);ax1 = subplot(1,1,1);
    p1 =plot(F1w(idad).tArray,F1w(idad).JLS2J.*1e6,'k:');
    hold on
    p2 =plot(F2w(idad).tArray,F2w(idad).JLS2J.*1e6,'k--');
    p3 =plot(F3w(idad).tArray,F3w(idad).JLS2J.*1e6,'k-');
    
    figure(9);ax3 = subplot(1,1,1);
    p4 =plot(F1w(idad).tArray,F1w(idad).JLS2I.*1e6,'k:');
    hold on
    p5 =plot(F2w(idad).tArray,F2w(idad).JLS2I.*1e6,'k--');
    p6 =plot(F3w(idad).tArray,F3w(idad).JLS2I.*1e6,'k-');
    
    figure(10);ax5 = subplot(1,1,1);
    p7 =plot(F1w(idad).tArray,F1w(idad).Jserca.*1e6,'k:');
    hold on
    p8 =plot(F2w(idad).tArray,F2w(idad).Jserca.*1e6,'k--');
    p9 =plot(F3w(idad).tArray,F3w(idad).Jserca.*1e6,'k-');
    
    figure(11);ax7 = subplot(1,1,1);
    p10 =plot(F1w(idad).tArray,F1w(idad).JRyR.*1e6,'k:');
    hold on
    p11 =plot(F2w(idad).tArray,F2w(idad).JRyR.*1e6,'k--');  
    p12 =plot(F3w(idad).tArray,F3w(idad).JRyR.*1e6,'k-');
    
    figure(12);ax9 = subplot(1,1,1);
    p13 =plot(F1w(idad).tArray,F1w(idad).ICaL,'k:');
    hold on
    p14 =plot(F2w(idad).tArray,F2w(idad).ICaL,'k--');
    p15 =plot(F3w(idad).tArray,F3w(idad).ICaL,'k-');
    
    figure(13);ax11 = subplot(1,1,1);
    p16 =plot(F1w(idad).tArray,F1w(idad).Incx,'k:');
    hold on
    p17 =plot(F2w(idad).tArray,F2w(idad).Incx,'k--'); 
    p18 =plot(F3w(idad).tArray,F3w(idad).Incx,'k-'); 
end

% idot0
for odad = 1 : 1%numel(sf1000_0)

    figure(14);ax2 = subplot(1,1,1);
    p19 =plot(F1o(odad).tArray,F1o(odad).JLS2J.*1e6,'k:');
    hold on
    p20=plot(F2o(odad).tArray,F2o(odad).JLS2J.*1e6,'k--');
    p21= plot(F3o(odad).tArray,F3o(odad).JLS2J.*1e6,'k-');
    
    figure(15);ax4 = subplot(1,1,1);
    p22 =plot(F1o(odad).tArray,F1o(odad).JLS2I.*1e6,'k:');
    hold on
    p23 =plot(F2o(odad).tArray,F2o(odad).JLS2I.*1e6,'k--');
    p24 =plot(F3o(odad).tArray,F3o(odad).JLS2I.*1e6,'k-');
    
    figure(16);ax6 = subplot(1,1,1);
    p25 =plot(F1o(odad).tArray,F1o(odad).Jserca.*1e6,'k:');
    hold on
    p26 =plot(F2o(odad).tArray,F2o(odad).Jserca.*1e6,'k--');
    p27 =plot(F3o(odad).tArray,F3o(odad).Jserca.*1e6,'k-');
    
    figure(17);ax8 = subplot(1,1,1);
    p28 =plot(F1o(odad).tArray,F1o(odad).JRyR.*1e6,'k:');
    hold on
    p29 =plot(F2o(odad).tArray,F2o(odad).JRyR.*1e6,'k--');  
    p30 =plot(F3o(odad).tArray,F3o(odad).JRyR.*1e6,'k-');
    
    figure(18);ax10 = subplot(1,1,1);
    p31 =plot(F1o(odad).tArray,F1o(odad).ICaL,'k:');
    hold on
    p32 =plot(F2o(odad).tArray,F2o(odad).ICaL,'k--');
    p33 =plot(F3o(odad).tArray,F3o(odad).ICaL,'k-');
    
    figure(19);ax12 = subplot(1,1,1);
    p34 =plot(F1o(odad).tArray,F1o(odad).Incx,'k:');
    hold on
    p35 =plot(F2o(odad).tArray,F2o(odad).Incx,'k--');
    p36 =plot(F3o(odad).tArray,F3o(odad).Incx,'k-');

end 

    linkaxes([ax1,ax2],'y');linkaxes([ax3,ax4],'y');linkaxes([ax5,ax6],'y');
    linkaxes([ax7,ax8],'y');linkaxes([ax9,ax10],'y');linkaxes([ax11,ax12],'y');
C = 2;
f8 = figure(8);subplot(1,1,1); ylabel('J_{ls,up} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p1 p2 p3], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f8,'Units','pixels','Position',[0 0 700 500])
               print(f8, fullfile(pwd, sprintf('%s ls2j',Cond{C})),'-dtiff','-r500');
f9 = figure(9);subplot(1,1,1); ylabel('J_{ls,rel} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p4 p5 p6], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               ax = gca;
               ax.YAxis.Exponent = 3;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f9,'Units','pixels','Position',[0 0 700 500])
               print(f9, fullfile(pwd, sprintf('%s ls2i',Cond{C})),'-dtiff','-r500');
f10 = figure(10);subplot(1,1,1); ylabel('J_{SERCA} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p7 p8 p9], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = 2;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f10,'Units','pixels','Position',[0 0 700 500])
               print(f10, fullfile(pwd, sprintf('%s SERCA',Cond{C})),'-dtiff','-r500');         
f11 = figure(11);subplot(1,1,1); ylabel('J_{RyR} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = 4;
               legend( [p10 p11 p12], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f11,'Units','pixels','Position',[0 0 700 500])
               print(f11, fullfile(pwd, sprintf('%s RyR',Cond{C})),'-dtiff','-r500');         
f12 = figure(12);subplot(1,1,1); ylabel('I_{CaL} (pA/pF)');xlabel('Time (ms)');title({'WT_{ }',' '});
               legend( [p13 p14 p15], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               ax = gca;
               ax.YAxis.Exponent = 1;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f12,'Units','pixels','Position',[0 0 700 500])
               print(f12, fullfile(pwd, sprintf('%s CaL',Cond{C})),'-dtiff','-r500');         
f13 = figure(13);subplot(1,1,1); ylabel('I_{NCX} (pA/pF)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p16 p17 p18], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               ax = gca;
               ax.YAxis.Exponent = -1;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f13,'Units','pixels','Position',[0 0 700 500])
               print(f13, fullfile(pwd, sprintf('%s NCX',Cond{C})),'-dtiff','-r500');         

C = 1;              
f8 = figure(14);subplot(1,1,1); ylabel('J_{ls,up} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p19 p20 p21], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f8,'Units','pixels','Position',[0 0 700 500])
               print(f8, fullfile(pwd, sprintf('%s ls2j',Cond{C})),'-dtiff','-r500');
f9 = figure(15);subplot(1,1,1); ylabel('J_{ls,rel} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               ax = gca;
               ax.YAxis.Exponent = 3;
               legend( [p22 p23 p24], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f9,'Units','pixels','Position',[0 0 700 500])
               print(f9, fullfile(pwd, sprintf('%s ls2i',Cond{C})),'-dtiff','-r500');
f10 = figure(16);subplot(1,1,1); ylabel('J_{SERCA} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = 2;
               legend( [p25 p26 p27], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f10,'Units','pixels','Position',[0 0 700 500])
               print(f10, fullfile(pwd, sprintf('%s SERCA',Cond{C})),'-dtiff','-r500');         
f11 = figure(17);subplot(1,1,1); ylabel('J_{RyR} (nM/ms)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p28 p29 p30], {'CTRL', 'NAADP-AM', 'ISO'},'Location','northeast');legend boxoff 
               ax = gca;
               ax. Position = [0.2 0.2 0.7 0.7];
               ax.YAxis.Exponent = 4;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f11,'Units','pixels','Position',[0 0 700 500])
               print(f11, fullfile(pwd, sprintf('%s RyR',Cond{C})),'-dtiff','-r500');         
f12 = figure(18);subplot(1,1,1); ylabel('I_{CaL} (pA/pF)');xlabel('Time (ms)');title({'TPC-KO_{ }',' '});
               legend( [p31 p32 p33], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               ax = gca;
               ax.YAxis.Exponent = 1;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f12,'Units','pixels','Position',[0 0 700 500])
               print(f12, fullfile(pwd, sprintf('%s CaL',Cond{C})),'-dtiff','-r500');         
f13 = figure(19);subplot(1,1,1); ylabel('I_{NCX} (pA/pF)');xlabel('Time (ms)');    title({' ',' '});
               legend( [p34 p35 p36], {'CTRL', 'NAADP-AM', 'ISO'},'Location','southeast');legend boxoff 
               ax = gca;
               ax.YAxis.Exponent = -1;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',40)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',2);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f13,'Units','pixels','Position',[0 0 700 500])
               print(f13, fullfile(pwd, sprintf('%s NCX',Cond{C})),'-dtiff','-r500');   

close all

%% inset 
% WT
for idad = 1: 1%numel(sf1000_0)
    
    
    figure(10);ax5 = subplot(1,1,1);
    p7 =plot(F1w(idad).tArray,F1w(idad).Jserca.*1e6,'k:');
    hold on
    p8 =plot(F2w(idad).tArray,F2w(idad).Jserca.*1e6,'k--');
    p9 =plot(F3w(idad).tArray,F3w(idad).Jserca.*1e6,'k-');
    
    figure(11);ax7 = subplot(1,1,1);
    p10 =plot(F1w(idad).tArray,F1w(idad).JRyR.*1e6,'k:');
    hold on
    p11 =plot(F2w(idad).tArray,F2w(idad).JRyR.*1e6,'k--');  
    p12 =plot(F3w(idad).tArray,F3w(idad).JRyR.*1e6,'k-');
    
end

% idot0
for odad = 1 : 1%numel(sf1000_0)


    figure(16);ax6 = subplot(1,1,1);
    p25 =plot(F1o(odad).tArray,F1o(odad).Jserca.*1e6,'k:');
    hold on
    p26 =plot(F2o(odad).tArray,F2o(odad).Jserca.*1e6,'k--');
    p27 =plot(F3o(odad).tArray,F3o(odad).Jserca.*1e6,'k-');
    
    figure(17);ax8 = subplot(1,1,1);
    p28 =plot(F1o(odad).tArray,F1o(odad).JRyR.*1e6,'k:');
    hold on
    p29 =plot(F2o(odad).tArray,F2o(odad).JRyR.*1e6,'k--');  
    p30 =plot(F3o(odad).tArray,F3o(odad).JRyR.*1e6,'k-');
    

end 
    linkaxes([ax5,ax6],'y');linkaxes([ax7,ax8],'y');
C = 2;

f10 = figure(10);subplot(1,1,1);
               xlim([0 200])
               ax = gca;

               ax.YAxis.Exponent = 2;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',70)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f10,'Units','pixels','Position',[0 0 700 500])
               print(f10, fullfile(pwd, sprintf('%s SERCA_inset',Cond{C})),'-dtiff','-r500');         
f11 = figure(11);subplot(1,1,1);
               xlim([0 50])
               ax = gca;

               ax.YAxis.Exponent = 4;

               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',70)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f11,'Units','pixels','Position',[0 0 700 500])
               print(f11, fullfile(pwd, sprintf('%s RyR_inset',Cond{C})),'-dtiff','-r500');         

C = 1;              

f10 = figure(16);subplot(1,1,1); 
               xlim([0 200])
               ax = gca;

               ax.YAxis.Exponent = 2;

               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',70)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f10,'Units','pixels','Position',[0 0 700 500])
               print(f10, fullfile(pwd, sprintf('%s SERCA_inset',Cond{C})),'-dtiff','-r500');         
f11 = figure(17);subplot(1,1,1);
               xlim([0 50])
               ax = gca;

               ax.YAxis.Exponent = 4;
               set(findobj(gcf,'type','axes'),'FontName','Times New Roman','FontSize',70)
               set(findobj(gcf, 'Type', 'Line'),'LineWidth',4);
               set(findobj(gcf,'type','axes'),'box','off')
               set(f11,'Units','pixels','Position',[0 0 700 500])
               print(f11, fullfile(pwd, sprintf('%s RyR_inset',Cond{C})),'-dtiff','-r500');         

close all
%% bp 
% idot0
for odad = 1 : numel(sf1000_0)

    t1o = F1o(odad).tArray;
    yjls2J1o = F1o(odad).JLS2J.*1e6;
    yjls2I1o = F1o(odad).JLS2I.*1e6;
    yjserca1o = F1o(odad).Jserca.*1e6;
    yjryr1o = F1o(odad).JRyR.*1e6;
    yical1o = F1o(odad).ICaL;
    yincx1o = F1o(odad).Incx;
    
    per = 0.8;
    [y1stpeakamp1o(odad).yjls2J] = dp(t1o,yjls2J1o,per);

    [y1stpeakamp1o(odad).yjls2I] = dp(t1o,yjls2I1o,per);
    
    [y1stpeakamp1o(odad).yjserca] = dp(t1o,yjserca1o,per);

    [y1stpeakamp1o(odad).yjryr] = dp(t1o,yjryr1o,per);

    [y1stpeakamp1o(odad).yical] = dp(t1o,yical1o,per);

    [y1stpeakamp1o(odad).yincx] = dp(t1o,yincx1o,per);
    
    t2o = F2o(odad).tArray;
    yjls2J2o = F2o(odad).JLS2J.*1e6;
    yjls2I2o = F2o(odad).JLS2I.*1e6;
    yjserca2o = F2o(odad).Jserca.*1e6;
    yjryr2o = F2o(odad).JRyR.*1e6;
    yical2o = F2o(odad).ICaL;
    yincx2o = F2o(odad).Incx;
    
    [y1stpeakamp2o(odad).yjls2J] = dp(t2o,yjls2J2o,per);

    [y1stpeakamp2o(odad).yjls2I] = dp(t2o,yjls2I2o,per);
    
    [y1stpeakamp2o(odad).yjserca] = dp(t2o,yjserca2o,per);

    [y1stpeakamp2o(odad).yjryr] = dp(t2o,yjryr2o,per);

    [y1stpeakamp2o(odad).yical] = dp(t2o,yical2o,per);

    [y1stpeakamp2o(odad).yincx] = dp(t2o,yincx2o,per);
    
    t3o = F3o(odad).tArray;
    yjls2J3o = F3o(odad).JLS2J.*1e6;
    yjls2I3o = F3o(odad).JLS2I.*1e6;
    yjserca3o = F3o(odad).Jserca.*1e6;
    yjryr3o = F3o(odad).JRyR.*1e6;
    yical3o = F3o(odad).ICaL;
    yincx3o = F3o(odad).Incx;
    
    [y1stpeakamp3o(odad).yjls2J] = dp(t3o,yjls2J3o,per);

    [y1stpeakamp3o(odad).yjls2I] = dp(t3o,yjls2I3o,per);
    
    [y1stpeakamp3o(odad).yjserca] = dp(t3o,yjserca3o,per);

    [y1stpeakamp3o(odad).yjryr] = dp(t3o,yjryr3o,per);

    [y1stpeakamp3o(odad).yical] = dp(t3o,yical3o,per);

    [y1stpeakamp3o(odad).yincx] = dp(t3o,yincx3o,per);

end 
% WT
for wdad = 1 : numel(sf1000_0) 
    
    t1w = F1w(wdad).tArray;
    yjls2J1w = F1w(wdad).JLS2J.*1e6;
    yjls2I1w = F1w(wdad).JLS2I.*1e6;
    yjserca1w = F1w(wdad).Jserca.*1e6;
    yjryr1w = F1w(wdad).JRyR.*1e6;
    yical1w = F1w(wdad).ICaL;
    yincx1w = F1w(wdad).Incx;
    
    per = 0.8;
    [y1stpeakamp1w(wdad).yjls2J] = dp(t1w,yjls2J1w,per);

    [y1stpeakamp1w(wdad).yjls2I] = dp(t1w,yjls2I1w,per);
    
    [y1stpeakamp1w(wdad).yjserca] = dp(t1w,yjserca1w,per);

    [y1stpeakamp1w(wdad).yjryr] = dp(t1w,yjryr1w,per);

    [y1stpeakamp1w(wdad).yical] = dp(t1w,yical1w,per);

    [y1stpeakamp1w(wdad).yincx] = dp(t1w,yincx1w,per);
  
    t2w = F2w(wdad).tArray;
    yjls2J2w = F2w(wdad).JLS2J.*1e6;
    yjls2I2w = F2w(wdad).JLS2I.*1e6;
    yjserca2w = F2w(wdad).Jserca.*1e6;
    yjryr2w = F2w(wdad).JRyR.*1e6;
    yical2w = F2w(wdad).ICaL;
    yincx2w = F2w(wdad).Incx;
    
    per = 0.8;
    [y1stpeakamp2w(wdad).yjls2J] = dp(t2w,yjls2J2w,per);

    [y1stpeakamp2w(wdad).yjls2I] = dp(t2w,yjls2I2w,per);
    
    [y1stpeakamp2w(wdad).yjserca] = dp(t2w,yjserca2w,per);

    [y1stpeakamp2w(wdad).yjryr] = dp(t2w,yjryr2w,per);

    [y1stpeakamp2w(wdad).yical] = dp(t2w,yical2w,per);

    [y1stpeakamp2w(wdad).yincx] = dp(t2w,yincx2w,per);

 
    t3w = F3w(wdad).tArray;
    yjls2J3w = F3w(wdad).JLS2J.*1e6;
    yjls2I3w = F3w(wdad).JLS2I.*1e6;
    yjserca3w = F3w(wdad).Jserca.*1e6;
    yjryr3w = F3w(wdad).JRyR.*1e6;
    yical3w = F3w(wdad).ICaL;
    yincx3w = F3w(wdad).Incx;
    
    per = 0.8;
    [y1stpeakamp3w(wdad).yjls2J] = dp(t3w,yjls2J3w,per);

    [y1stpeakamp3w(wdad).yjls2I] = dp(t3w,yjls2I3w,per);
    
    [y1stpeakamp3w(wdad).yjserca] = dp(t3w,yjserca3w,per);

    [y1stpeakamp3w(wdad).yjryr] = dp(t3w,yjryr3w,per);

    [y1stpeakamp3w(wdad).yical] = dp(t3w,yical3w,per);

    [y1stpeakamp3w(wdad).yincx] = dp(t3w,yincx3w,per);
end

%% fold 
p2w_1w_ls2i = median([y1stpeakamp2w(:).yjls2I])/median([y1stpeakamp1w(:).yjls2I])
p2o_1o_ls2i = median([y1stpeakamp2o(:).yjls2I])/median([y1stpeakamp1o(:).yjls2I])

p2w_1w_serca = median([y1stpeakamp2w(:).yjserca])/median([y1stpeakamp1w(:).yjserca])
p2o_1o_serca = median([y1stpeakamp2o(:).yjserca])/median([y1stpeakamp1o(:).yjserca])

p2w_1w_ryr = median([y1stpeakamp2w(:).yjryr])/median([y1stpeakamp1w(:).yjryr])
p2o_1o_ryr = median([y1stpeakamp2o(:).yjryr])/median([y1stpeakamp1o(:).yjryr])
%         
% p3w_1w_ls2i = median([y1stpeakamp3w(:).yjls2I])/median([y1stpeakamp1w(:).yjls2I])
% p3o_1o_ls2i = median([y1stpeakamp3o(:).yjls2I])/median([y1stpeakamp1o(:).yjls2I])
% 
% p3w_1w_serca = median([y1stpeakamp3w(:).yjserca])/median([y1stpeakamp1w(:).yjserca])
% p3o_1o_serca = median([y1stpeakamp3o(:).yjserca])/median([y1stpeakamp1o(:).yjserca])
p3w_3o_serca = median([y1stpeakamp3w(:).yjserca])/median([y1stpeakamp3o(:).yjserca])

% p3w_1w_ryr = median([y1stpeakamp3w(:).yjryr])/median([y1stpeakamp1w(:).yjryr])
% p3o_1o_ryr = median([y1stpeakamp3o(:).yjryr])/median([y1stpeakamp1o(:).yjryr])
p3w_3o_ryr = median([y1stpeakamp3w(:).yjryr])/median([y1stpeakamp3o(:).yjryr])
% %%
% figure(30)
% bx = [[y1stpeakamp1w(:).yjls2J]';...
%       [y1stpeakamp1w(:).yjls2I]';...
%       [y1stpeakamp2w(:).yjls2J]';...
%       [y1stpeakamp2w(:).yjls2I]';...
%       [y1stpeakamp3w(:).yjls2J]';...
%       [y1stpeakamp3w(:).yjls2I]';...
%       ]; 
% by = [ zeros(length([y1stpeakamp1w(:).yjls2J]), 1);...
%        ones(length([y1stpeakamp1w(:).yjls2I]), 1);... 
%        2*ones(length([y1stpeakamp2w(:).yjls2J]), 1);...
%        4*ones(length([y1stpeakamp2w(:).yjls2I]), 1);...
%        5*ones(length([y1stpeakamp3w(:).yjls2J]), 1);...
%        6*ones(length([y1stpeakamp3w(:).yjls2I]), 1);...
%        ];
% boxplot(bx, by,'Notch','on','Colors','bk') 
% c = findobj(gca,'Tag','Box');
% legend([c(6);c(5)],'J_{ls,up}','J_{ls,rel}','Location','northwest');legend boxoff
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
% ylabel('J_{ls,up}, J_{ls,rel} (nM/ms)')
%     title({' ',' '});
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf,fullfile('F4-ls2ji'),'-dtiff','-r500');
% 
%     figure(30)
%     bx = [[y1stpeakamp1w(:).yjls2J]';...
%           [y1stpeakamp1o(:).yjls2J]';...
%           [y1stpeakamp2w(:).yjls2J]';...
%           [y1stpeakamp2o(:).yjls2J]';...
%           [y1stpeakamp3w(:).yjls2J]';...
%           [y1stpeakamp3o(:).yjls2J]';...
%           ]; 
%     by = [ zeros(length([y1stpeakamp1w(:).yjls2J]), 1);...
%            ones(length([y1stpeakamp1o(:).yjls2J]), 1);... 
%            2*ones(length([y1stpeakamp2w(:).yjls2J]), 1);...
%            4*ones(length([y1stpeakamp2o(:).yjls2J]), 1);...
%            5*ones(length([y1stpeakamp3w(:).yjls2J]), 1);...
%            6*ones(length([y1stpeakamp3o(:).yjls2J]), 1);...
%            ];
%     boxplot(bx, by,'Notch','on','Colors','bk') 
%     c = findobj(gca,'Tag','Box');
%     legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
%     set(gca,'xtick',1.5:2:5.5)
%     set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
%     set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
%     ylabel('J_{ls,up} (nM/ms)')
%         title({' ',' '});
%     set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
%     set(gcf,'Units','pixels','Position',[0 0 700 500])
%     print(gcf,fullfile('F4-ls2j'),'-dtiff','-r500');
%     
%     figure(30)
%     bx = [[y1stpeakamp1w(:).yjls2I]';...
%           [y1stpeakamp1o(:).yjls2I]';...
%           [y1stpeakamp2w(:).yjls2I]';...
%           [y1stpeakamp2o(:).yjls2I]';...
%           [y1stpeakamp3w(:).yjls2I]';...
%           [y1stpeakamp3o(:).yjls2I]';...
%           ]; 
%     by = [ zeros(length([y1stpeakamp1w(:).yjls2I]), 1);...
%            ones(length([y1stpeakamp1o(:).yjls2I]), 1);... 
%            2*ones(length([y1stpeakamp2w(:).yjls2I]), 1);...
%            4*ones(length([y1stpeakamp2o(:).yjls2I]), 1);...
%            5*ones(length([y1stpeakamp3w(:).yjls2I]), 1);...
%            6*ones(length([y1stpeakamp3o(:).yjls2I]), 1);...
%            ];
%     boxplot(bx, by,'Notch','on','Colors','bk') 
%     c = findobj(gca,'Tag','Box');
%     legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
%     set(gca,'xtick',1.5:2:5.5)
%     set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
%     set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
%     ylabel('J_{ls,rel} (nM/ms)')
%         title({' ',' '});
%     set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
%     set(gcf,'Units','pixels','Position',[0 0 700 500])
%     print(gcf,fullfile('F4-ls2i'),'-dtiff','-r500');
    
%% bp serca  WT vs idot0
close all
figure(30)
bx = [[y1stpeakamp1w(:).yjserca]';...
      [y1stpeakamp1o(:).yjserca]';...
      [y1stpeakamp2w(:).yjserca]';...
      [y1stpeakamp2o(:).yjserca]';...
      [y1stpeakamp3w(:).yjserca]';...
      [y1stpeakamp3o(:).yjserca]';...
      ]; 
by = [ zeros(length([y1stpeakamp1w(:).yjserca]), 1);...
       ones(length([y1stpeakamp1o(:).yjserca]), 1);... 
       2*ones(length([y1stpeakamp2w(:).yjserca]), 1);...
       4*ones(length([y1stpeakamp2o(:).yjserca]), 1);...
       5*ones(length([y1stpeakamp3w(:).yjserca]), 1);...
       6*ones(length([y1stpeakamp3o(:).yjserca]), 1);...
       ];
b = boxplot(bx, by,'Notch','on','Colors','kk');
n = findobj(gcf,'tag','Outliers');
for i = 1: numel(n)
set(n(i), 'MarkerEdgeColor',[0 0 0]);
end

ylabel('J_{SERCA} (nM/ms)')
    title({' ',' '})

set(b(:,1),'LineWidth',4);
set(b(:,3),'LineWidth',4);
set(b(:,5),'LineWidth',4);
set(b(:,2),'LineWidth',2);
set(b(:,4),'LineWidth',2);
set(b(:,6),'LineWidth',2);

c = findobj(gca,'Tag','Box');
legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff

ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ylim([0 8e2])   
    ax.YAxis.Exponent = 2;
set(gca,'xtick',1.5:2:5.5, 'XTickLabelRotation',0)
set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf,fullfile('F3_serca'),'-dtiff','-r500');

%% ryr WT vs idot0 
close all
figure(30)
bx = [[y1stpeakamp1w(:).yjryr]';...
      [y1stpeakamp1o(:).yjryr]';...
      [y1stpeakamp2w(:).yjryr]';...
      [y1stpeakamp2o(:).yjryr]';...
      [y1stpeakamp3w(:).yjryr]';...
      [y1stpeakamp3o(:).yjryr]';...
      ]; 
by = [ zeros(length([y1stpeakamp1w(:).yjryr]), 1);...
       ones(length([y1stpeakamp1o(:).yjryr]), 1);... 
       2*ones(length([y1stpeakamp2w(:).yjryr]), 1);...
       4*ones(length([y1stpeakamp2o(:).yjryr]), 1);...
       5*ones(length([y1stpeakamp3w(:).yjryr]), 1);...
       6*ones(length([y1stpeakamp3o(:).yjryr]), 1);...
       ];
b = boxplot(bx, by,'Notch','on','Colors','kk');
n = findobj(gcf,'tag','Outliers');
for i = 1: numel(n)
set(n(i), 'MarkerEdgeColor',[0 0 0]);
end

ylabel('J_{RyR} (nM/ms)')
    title({' ',' '})

set(b(:,1),'LineWidth',4);
set(b(:,3),'LineWidth',4);
set(b(:,5),'LineWidth',4);
set(b(:,2),'LineWidth',2);
set(b(:,4),'LineWidth',2);
set(b(:,6),'LineWidth',2);

c = findobj(gca,'Tag','Box');
legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff

ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
ylim([0 20e4]) 
    ax.YAxis.Exponent = 4;
set(gca,'xtick',1.5:2:5.5, 'XTickLabelRotation',0)
set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
set(gcf,'Units','pixels','Position',[0 0 700 500])
print(gcf,fullfile('F3_ryr'),'-dtiff','-r500');

% %% ical
% figure(30)
% bx = [[y1stpeakamp1w(:).yical]';...
%       [y1stpeakamp1o(:).yical]';...
%       [y1stpeakamp2w(:).yical]';...
%       [y1stpeakamp2o(:).yical]';...
%       [y1stpeakamp3w(:).yical]';...
%       [y1stpeakamp3o(:).yical]';...
%       ]; 
% by = [ zeros(length([y1stpeakamp1w(:).yical]), 1);...
%        ones(length([y1stpeakamp1o(:).yical]), 1);... 
%        2*ones(length([y1stpeakamp2w(:).yical]), 1);...
%        4*ones(length([y1stpeakamp2o(:).yical]), 1);...
%        5*ones(length([y1stpeakamp3w(:).yical]), 1);...
%        6*ones(length([y1stpeakamp3o(:).yical]), 1);...
%        ];
% boxplot(bx, by,'Notch','on','Colors','bk') 
% c = findobj(gca,'Tag','Box');
% legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
% ylabel('I_{CaL} (pA/pF)')
% ax = gca;
%     ax.YAxis.Exponent = 1;
%     title({' ',' '});
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf,fullfile('F4-cal'),'-dtiff','-r500');
% 
% %% ncx 
% figure(30)
% bx = [[y1stpeakamp1w(:).yincx]';...
%       [y1stpeakamp1o(:).yincx]';...
%       [y1stpeakamp2w(:).yincx]';...
%       [y1stpeakamp2o(:).yincx]';...
%       [y1stpeakamp3w(:).yincx]';...
%       [y1stpeakamp3o(:).yincx]';...
%       ]; 
% by = [ zeros(length([y1stpeakamp1w(:).yincx]), 1);...
%        ones(length([y1stpeakamp1o(:).yincx]), 1);... 
%        2*ones(length([y1stpeakamp2w(:).yincx]), 1);...
%        4*ones(length([y1stpeakamp2o(:).yincx]), 1);...
%        5*ones(length([y1stpeakamp3w(:).yincx]), 1);...
%        6*ones(length([y1stpeakamp3o(:).yincx]), 1);...
%        ];
% boxplot(bx, by,'Notch','on','Colors','bk') 
% c = findobj(gca,'Tag','Box');
% legend([c(6);c(5)],'WT','TPC-KO','Location','northwest');legend boxoff
% set(gca,'xtick',1.5:2:5.5)
% set(gca,'xticklabel',{'CTRL','NAADP-AM','ISO'})
% set(gca,'box','off');set(gca, 'FontName','Times New Roman','FontSize',40)
% ylabel('I_{NCX} (pA/pF)');ylim([0 2.5])
% ax = gca;
%     ax.YAxis.Exponent = -1;
%     title({' ',' '});
% set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
% set(gcf,'Units','pixels','Position',[0 0 700 500])
% print(gcf,fullfile('F4-ncx'),'-dtiff','-r500');
% close all

function [ca_RT50, ca_RT80,ca_peak,ca_y_rmp, ca_amp,y_minCa,yendCaT] = per_cat_fun(t,CaT,ca_per50,ca_per80)
% dCaT = (CaT(2:end) - CaT(1:end-1))./(t(2:end) - t(1:end-1));
% [B,I] = sort(dCaT,'ascend');
% SC.I = I;
% SC.dCaT = dCaT;
yendCaT = CaT(end);
[y_maxCa, maxCa_idx] = max(CaT);
[y_minCa, minCa_idx] = min(CaT);
camax_t2peak = t(maxCa_idx);
camin_t2peak = t(minCa_idx);
ca_peak = y_maxCa;


% [minCa, minCa_idx] = min(CaT);
% x_rmp = t(minCa_idx);
ca_y_rmp = CaT(end,1);

if ca_y_rmp < y_maxCa
ca_amp = y_maxCa - ca_y_rmp;
y_Cathreshold50 = ca_y_rmp + ca_amp*(1-ca_per50);
    y_Cathreshold80 = ca_y_rmp + ca_amp*(1-ca_per80);
x_Cathreshold50 = interp1(CaT(maxCa_idx:end), t(maxCa_idx:end), y_Cathreshold50);
    x_Cathreshold80 = interp1(CaT(maxCa_idx:end), t(maxCa_idx:end), y_Cathreshold80);
ca_RT50 = x_Cathreshold50 - camax_t2peak;
    ca_RT80 = x_Cathreshold80 - camax_t2peak;
else ca_amp = ca_y_rmp - y_minCa;
    y_Cathreshold50 = y_minCa + ca_amp*(1-ca_per50);
        y_Cathreshold80 = y_minCa + ca_amp*(1-ca_per80);
    x_Cathreshold50 = interp1(CaT(minCa_idx:end), t(y_minCa:end), y_Cathreshold50);
        x_Cathreshold80 = interp1(CaT(minCa_idx:end), t(y_minCa:end), y_Cathreshold80);
    ca_RT50 = x_Cathreshold50 - camin_t2peak;
        ca_RT80 = x_Cathreshold80 - camin_t2peak;
end

% if minCa >= CaT(end)
%    ca_RT = t(end) - ca_t2peak;
% else  ca_RT = x_rmp - ca_t2peak;
% end
end

function [apd, ap_peak,ap_y_rmp,ap_amp,y_maxdVmdt,y_minV,yendV] = per_apd_fun(t,V,ap_per)
dVm = (V(2:end) - V(1:end-1))./(t(2:end) - t(1:end-1));
% [B,I] = sort(dVm,'ascend');
% SV.dVm = dVm;
yendV = V(end);
[y_maxV, maxV_idx] = max(V);
[y_minV, minV_idx] = min(V);
ap_peak  = y_maxV;
[y_maxdVmdt, maxdVmdt_idx] = max(dVm);
x_maxdVmdt = t(maxdVmdt_idx);

ap_y_rmp = V(end,1);
apa = ap_peak-ap_y_rmp;
ap_amp = apa;
y_threshold = ap_y_rmp + apa*(1-ap_per);
x_threshold = interp1(V(maxV_idx:end), t(maxV_idx:end), y_threshold);

apd = x_threshold- x_maxdVmdt;
end