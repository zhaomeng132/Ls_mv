clear all
close all
addpath(pwd)
% C = 2;
% cond = {'without TPC','TPC'};
P = 2;
protocol ={'WT','NAADP-AM','ISO'};
% sprintf('%s %s',protocol{P},cond{C})

cd ~/downloads/Ls_mv_sf6_meng15/baseline

% baseline idot0
load baseline_y175_i_dot0_wt_naadp=01_Ligtot=0.0_1hz_150beat.mat
p1oy = S.y;
p1ot = S.t;
    load baseline_y175_i_dot0_naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
    p2oy = S.y;
    p2ot = S.t;
        load baseline_y175_i_dot0_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
        p3oy = S.y;
        p3ot = S.t;
% baseline  w
load baseline_y175_WT_wt_naadp=01_Ligtot=0.0_1hz_150beat.mat
p1wy = S.y;
p1wt = S.t;
    load baseline_y175_WT_naadp_naadp=15_Ligtot=0.0_1hz_150beat.mat
    p2wy = S.y;
    p2wt = S.t;
       load baseline_y175_WT_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
        p3wy = S.y;
        p3wt = S.t;
        
% % camkiiko_dot8
% load baseline_y175_WT_wt_naadp=01_Ligtot=0.0_KO_dot8_1hz_150beat.mat
% p1wckodot8y = S.y;
% p1wckodot8t = S.t;
%     load baseline_y175_WT_naadp_naadp=15_Ligtot=0.0_KO_dot8_1hz_150beat.mat
%     p2wckodot8y = S.y;
%     p2wckodot8t = S.t;
%     

% % camkiiko_dot2
% cd ~/downloads/SS/h1_cao1_p123_/h1_cao1_p2_kn93_
% load  baseline_y175_WT_wt_naadp=01_Ligtot=0.0_KO_dot2_1hz_150beat.mat
% p1wckodot2y = S.y;
% p1wckodot2t = S.t;
%     load  baseline_y175_WT_naadp_naadp=15_Ligtot=0.0_KO_dot2_1hz_150beat.mat
%     p2wckodot2y = S.y;
%     p2wckodot2t = S.t;

cd ~/downloads/Ls_mv_sf6_meng15/
mkdir(['./','fig2_'])
cd(['./','fig2_'])

%%
close all
figure(1)
plot(p1wt,p1wy(:,38).*1e6,'k:');
hold on
plot(p2wt,p2wy(:,38).*1e6,'k-'); 
hold off
ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');     
legend({'WT','NAADP-AM'})
legend boxoff   
ylim([0 700])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('F2-1'),'-dpng','-r500');
%%
close all
figure(2)
plot(p1ot,p1oy(:,38).*1e6,'k:');
hold on
plot(p2ot,p2oy(:,38).*1e6,'k-'); 
hold off
ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');     
legend({'TPC-KO','NAADP-AM'})
legend boxoff   
ylim([0 700])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('F2-2'),'-dpng','-r500');

%%
close all
figure(3)
plot(p1wt,p1wy(:,38).*1e6,'k:');
hold on
plot(p3wt,p3wy(:,38).*1e6,'k-'); 
hold off
ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');     
legend({'WT','ISO'})
legend boxoff   
ylim([0 700])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
% saveas(gcf,sprintf('%s fig1-3.png',protocol{P}))
print(gcf,fullfile('F2-3'),'-dpng','-r500');

%%
close all
figure(4)
plot(p1ot,p1oy(:,38).*1e6,'k:');
hold on
plot(p3ot,p3oy(:,38).*1e6,'k-'); 
hold off
ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');     
legend({'TPC-KO','ISO'})
legend boxoff   
ylim([0 700])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
% saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
print(gcf,fullfile('F2-4'),'-dpng','-r500');

% close all
% figure(5)
% plot(p1ot,p1oy(:,39),'Color','#0000ff');
% hold on
% plot(p3ot,p3oy(:,39),'Color','#1f7a1f'); 
% hold off
% ylabel('Vm (mV)');xlabel('Time (ms)');
% legend({'TPC-KO','ISO'})
% legend boxoff   
% xlim([0 50])
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-5.png',protocol{P}))
% print(gcf,fullfile('F2-5'),'-dpng','-r500');
% 
% 
% figure(6)
% plot(p1wt,p1wy(:,39),'k');
% hold on
% plot(p3wt,p3wy(:,39),'r'); 
% hold off
% ylabel('Vm (mV)');xlabel('Time (ms)');
% legend({'WT','ISO'})
% legend boxoff   
% xlim([0 50])
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-6.png',protocol{P}))
% print(gcf,fullfile('F2-6'),'-dpng','-r500');

% figure(7)
% plot(p1wckodot8t,p1wckodot8y(:,38).*1e6,'Color','#0000ff');
% hold on
% plot(p2wckodot8t,p2wckodot8y(:,38).*1e6,'Color','#1f7a1f'); 
% hold off
% ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');title('CaMKII 20% Blocking')
% legend({'KN93','KN93 + NAADP-AM'})
% legend boxoff   
% ylim([0 700])
% % ax = gca;
% %     ax.YAxis.Exponent = 2;
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
% print(gcf,fullfile('F2-7'),'-dpng','-r500');


% figure(8)
% plot(p1wckodot2t,p1wckodot2y(:,38).*1e6,'Color','#0000ff');
% hold on
% plot(p2wckodot2t,p2wckodot2y(:,38).*1e6,'Color','#1f7a1f'); 
% hold off
% ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');
% legend({'KN93','KN93 + NAADP-AM'})
% legend boxoff   
% ylim([0 700])
% ax = gca;
% ax. Position = [0.2 0.2 0.7 0.7];
%     ax.YAxis.Exponent = 2;
% set(gca, 'FontName','Times New Roman','FontSize',35)
% set(findall(gca, 'Type', 'Line'),'LineWidth',2);
% set(gca,'box','off')
% set(gcf,'Units','pixels','Position',[0 0 500 500])
% % saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
% print(gcf,fullfile('F2-8'),'-dpng','-r500');

% close all
% %% NCX
% cd /Users/meng2/Downloads/SS/Ls_mv/baseline_h_cao1_p3_local_NCXscale
% load y175_WT_herz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
% 
% sf_6 = linspace(1,6,6);
% %% plot y38
% for ipeak = 1: numel(S)  
% 
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(S(ipeak).t1,S(ipeak).y1(:,39),'DisplayName',['NCX=',num2str(sf_6(ipeak))]);
%     hold on
% end
% 
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('Em (mV)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, WT_{}',''});
% legend boxoff
%     ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.6];
% ax.YAxis.Exponent = 0;
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
%       
% print(f60, fullfile(pwd, 'hy_wt_y39_NCX'),'-dpng','-r500');
% 
% close all
% %% cal
% close all
% cd /Users/meng2/Downloads/SS/Ls_mv/baseline_h_cao1_p3_local_calscale
% load y175_WT_herz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
% 
% n = 6;
% sf_7 = linspace(1,11,n);
% %% plot y38
% for ipeak = 1: numel(S)  
% 
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(S(ipeak).t1,S(ipeak).y1(:,39),'DisplayName',['CaL=',num2str(sf_7(ipeak))]);
%     hold on
% end
% 
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('Em (mV)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, WT_{}',''});
% legend boxoff
%     ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.6];
% ax.YAxis.Exponent = 0;
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
%       
% print(f60, fullfile(pwd, 'hy_wt_y39_cal'),'-dpng','-r500');
% close all
% %% kr
% close all
% cd /Users/meng2/Downloads/SS/Ls_mv/baseline_h_cao1_p3_local_krscale
% load y175_WT_herz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat
% 
% n = 5;
% sf_9 = linspace(0.2,1,n);
% %% plot y38
% for ipeak = 1: numel(S)  
% 
%     figure(60)
%     ax2 = subplot(1,1,1);
%     p1 = plot(S(ipeak).t1,S(ipeak).y1(:,39),'DisplayName',['Kr=',num2str(sf_9(ipeak))]);
%     hold on
% end
% 
% f60 = figure(60);
% ax2 = subplot(1,1,1);ylabel('Em (mV)');xlabel('Time (ms)'); 
% title({'Hypercalcemia and ISO, WT_{}',''});
% legend boxoff
%     ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.6];
% ax.YAxis.Exponent = 0;
%     set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
%     set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
%     set(findobj(f60,'type','axes'),'box','off')
%     set(f60,'Units','pixels','Position',[0 0 700 500])
%       
% print(f60, fullfile(pwd, 'hy_wt_y39_kr'),'-dpng','-r500');
% % close all

