clear all
close all
addpath('/Users/meng2/Downloads/SS/Ls_mv_sf6/plot_h1_cao1_p123_sf6')

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p1_arc_ncx3

load y175_WT_wt_naadp=01_Ligtot=0.0_1hz_150beat_ncx3.mat
S1w1000= S;
load y175_i_dot0_wt_naadp=01_Ligtot=0.0_1hz_150beat_ncx3.mat
S1o1000= S;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p2_arc_ncx3

load y175_WT_naadp_naadp=15_Ligtot=0.0_1hz_150beat_ncx3.mat
S2w1000= S;
load y175_i_dot0_naadp_naadp=15_Ligtot=0.0_1hz_150beat_ncx3.mat
S2o1000= S;
          
cd ~/downloads/SS/Ls_mv_sf6/h1_cao1_p3_arc_ncx3

load y175_WT_iso15_naadp=15_Ligtot=0.1_1hz_150beat_ncx3.mat
S3w1000= S;
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_1hz_150beat_ncx3.mat
S3o1000= S;

SP = 1; 
Y = [38,31,36,88,37];
Yspace = {'Cytosol','SR','Junction','Lysosome','SL'};

%% check dad p3o
close all
for idad = 1 : numel(S2o1000)
    y1o = S1o1000(idad).y;
    t1o = S1o1000(idad).t;
    y2o = S2o1000(idad).y;
    t2o = S2o1000(idad).t;
    y3o = S3o1000(idad).y;
    t3o = S3o1000(idad).t;
    
    y1w = S1w1000(idad).y;
    t1w = S1w1000(idad).t;
    y2w = S2w1000(idad).y;
    t2w = S2w1000(idad).t;
    y3w = S3w1000(idad).y;
    t3w = S3w1000(idad).t;
    
    rate = 150000;
    rate1 = 1.5;
    [TF1o,~] = islocalmax(y1o(:,38),'MinProminence',max(y1o(:,38))/rate);
    if y1o(end,38) > min(y1o(:,38))*rate1
    TF1o(end) = 1;
    end 
    T1o(idad) =numel(find(TF1o));
    
    [TF2o,~] = islocalmax(y2o(:,38),'MinProminence',max(y2o(:,38))/rate);
    if y2o(end,38) > min(y2o(:,38))*rate1
    TF2o(end) = 1;
    end 
    T2o(idad) =numel(find(TF2o));

    [TF3o,~] = islocalmax(y3o(:,38),'MinProminence',max(y3o(:,38))/rate);
    if y3o(end,38) > min(y3o(:,38))*rate1
    TF3o(end) = 1;
    end 
    T3o(idad) =numel(find(TF3o));
    
    [TF1w,~] = islocalmax(y1w(:,38),'MinProminence',max(y1w(:,38))/rate);
    if y1w(end,38) > min(y1w(:,38))*rate1
    TF1w(end) = 1;
    end 
    T1w(idad) =numel(find(TF1w));
    
    [TF2w,~] = islocalmax(y2w(:,38),'MinProminence',max(y2w(:,38))/rate);
    if y2w(end,38) > min(y2w(:,38))*rate1
    TF2w(end) = 1;
    end 
    T2w(idad) =numel(find(TF2w));

    [TF3w,~] = islocalmax(y3w(:,38),'MinProminence',max(y3w(:,38))/rate);
    if y3w(end,38) > min(y3w(:,38))*rate1
    TF3w(end) = 1;
    end 
    T3w(idad) =numel(find(TF3w));

end 
p1_w = find(T1w>=2);
p1_w_0 = find(T1w<2);
p2_w = find(T2w>=2);
p2_w_0 = find(T2w<2);
p3_w = find(T3w>=2);
p3_w_0 = find(T3w<2);

%
p1_o = find(T1o>=2);
p1_o_0 = find(T1o<2);
p2_o = find(T2o>=2);
p2_o_0 = find(T2o<2);
p3_o = find(T3o>=2);
p3_o_0 = find(T3o<2);

linspace1 = 1:1:1000;
h1_cao1_sf1000_1 = unique([p1_w, p2_w, p3_w, p1_o, p2_o, p3_o]);
h1_cao1_sf1000_0 = linspace1(find(ismember(linspace1,h1_cao1_sf1000_1)~=1));
num = numel(h1_cao1_sf1000_0)
h1_cao1_sf1000_sf6_0_ncx3 = h1_cao1_sf1000_0;

cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','sort_ncx3'])
cd(['./','sort_ncx3'])
save('h1_cao1_sf1000_sf6_0_ncx3.mat','h1_cao1_sf1000_sf6_0_ncx3');

for idad = 1: numel(h1_cao1_sf1000_0)
    y1o = S1o1000(h1_cao1_sf1000_0(idad)).y;
    t1o = S1o1000(h1_cao1_sf1000_0(idad)).t;
    y2o = S2o1000(h1_cao1_sf1000_0(idad)).y;
    t2o = S2o1000(h1_cao1_sf1000_0(idad)).t;
    y3o = S3o1000(h1_cao1_sf1000_0(idad)).y;
    t3o = S3o1000(h1_cao1_sf1000_0(idad)).t;
    
    y1w = S1w1000(h1_cao1_sf1000_0(idad)).y;
    t1w = S1w1000(h1_cao1_sf1000_0(idad)).t;
    y2w = S2w1000(h1_cao1_sf1000_0(idad)).y;
    t2w = S2w1000(h1_cao1_sf1000_0(idad)).t;
    y3w = S3w1000(h1_cao1_sf1000_0(idad)).y;
    t3w = S3w1000(h1_cao1_sf1000_0(idad)).t;
    per = 0.8;
    [y1stpeakamp1o(idad).y38] = dp(t1o,y1o(:,38).*1e6,per); % cytosolic space
        [y1stpeakamp2o(idad).y38] = dp(t2o,y2o(:,38).*1e6,per);
            [y1stpeakamp3o(idad).y38] = dp(t3o,y3o(:,38).*1e6,per);
        [y1stpeakamp1w(idad).y38] = dp(t1w,y1w(:,38).*1e6,per); % cytosolic space
            [y1stpeakamp2w(idad).y38] = dp(t2w,y2w(:,38).*1e6,per);
                [y1stpeakamp3w(idad).y38] = dp(t3w,y3w(:,38).*1e6,per);
                end

mean_p2w_p1w = mean(([y1stpeakamp2w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38])
sd_p2w_p1w = std(([y1stpeakamp2w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38]);
se_p2w_p1w = sd_p2w_p1w./sqrt(length([y1stpeakamp2w(:).y38]))

% naadp idot0
mean_p2o_p1o = mean(([y1stpeakamp2o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38])
sd_p2o_p1o = std(([y1stpeakamp2o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38]);
se_p2o_p1o = sd_p2o_p1o./sqrt(length([y1stpeakamp2o(:).y38]))

% iso wt
mean_p3w_p1w = mean(([y1stpeakamp3w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38])
sd_p3w_p1w = std(([y1stpeakamp3w(:).y38] - [y1stpeakamp1w(:).y38])./[y1stpeakamp1w(:).y38]);
se_p3w_p1w = sd_p3w_p1w./sqrt(length([y1stpeakamp3w(:).y38]))

% iso idot0
mean_p3o_p1o = mean(([y1stpeakamp3o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38])
sd_p3o_p1o = std(([y1stpeakamp3o(:).y38] - [y1stpeakamp1o(:).y38])./[y1stpeakamp1o(:).y38]);
se_p3o_p1o = sd_p3o_p1o./sqrt(length([y1stpeakamp3o(:).y38]))

%%
% load h1_cao1_sf1000_0.mat 
S1o = S1o1000(h1_cao1_sf1000_0);
S1w = S1w1000(h1_cao1_sf1000_0);
S2o = S2o1000(h1_cao1_sf1000_0);
S2w = S2w1000(h1_cao1_sf1000_0);
S3o = S3o1000(h1_cao1_sf1000_0);
S3w = S3w1000(h1_cao1_sf1000_0);
for idad = 1 : numel(h1_cao1_sf1000_0)
    y1o = S1o(idad).y;
    t1o = S1o(idad).t;
    y2o = S2o(idad).y;
    t2o = S2o(idad).t;
    y3o = S3o(idad).y;
    t3o = S3o(idad).t;
    
    y1w = S1w(idad).y;
    t1w = S1w(idad).t;
    y2w = S2w(idad).y;
    t2w = S2w(idad).t;
    y3w = S3w(idad).y;
    t3w = S3w(idad).t;
    
    figure(55);
    p3 = plot(t1o,y1o(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on
    
    figure(56);
    p3 = plot(t1w,y1w(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on

    figure(57);
    p3 = plot(t2o,y2o(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on
    
    figure(58);
    p3 = plot(t2w,y2w(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on

    figure(59);
    p3 = plot(t3o,y3o(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on
    
    figure(60);
    p3 = plot(t3w,y3w(:,Y(SP)).*1e6,'Color','#0033cc');%p3.Color(3) = 1;%  38 cytosolic space
    hold on
    
end


