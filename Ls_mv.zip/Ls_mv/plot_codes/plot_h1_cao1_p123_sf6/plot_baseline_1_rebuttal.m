
%%
Pomax = 0.014; % with tpc or 0 without tpc
naadp = linspace(1,500,500);  % in nM or 10nm from <https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2761823/>
% naadp = linspace(log10(0/1e9), log10(400/1e9),500);
% naadp = linspace(1.2341e-04,0.0498,0.0498);
naadp = naadp./1e9; %nM to M
Pomean = 23;              % in nM
Posd = 1.5;
Potpc = Pomax*exp(-(log(naadp)-log(Pomean)).^2/(2*Posd^2));
% Potpc = Pomax*exp(-(naadp-log(Pomean)).^2/(2*Posd^2));
% Potpc = Pomax*exp(-(log10(naadp)-log10(Pomean)).^2/(2*Posd^2));

figure(1)
plot(naadp,Potpc,'k');
% plot(log(naadp),Potpc,'k');
% plot(log10(naadp),Potpc,'k');
title({'Simulated_{ }',' '});  
% ylabel('TPC2 open probability');xlabel('[NAADP] (M)');
% ylabel('TPC2 open probability');xlabel('log([NAADP]) (M)');
% ylim([0 0.02])
% ylim([0 20e-3])

ax = gca;
% ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 0;
set(gca, 'FontName','Times New Roman','FontSize',40)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('naadp_tpc'),'-dtiff','-r500');
%%
plot(naadp,Potpc,'k');
title({'Simulated_{ }',' '});  
ylabel('CLC open probability');xlabel('[NAADP] (nM)');
ylim([0 0.02])

ax = gca;
% ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 0;
set(gca, 'FontName','Times New Roman','FontSize',40)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
print(gcf,fullfile('naadp_clc'),'-dtiff','-r500');
% close all

%%
cd /Users/meng2/Downloads/Ls_mv_sf6_meng15/baseline_h_cao1_p3_rel2block
% baseline  w idot0
load y175_i_dot0_herz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat

cd ~/downloads/Ls_mv_sf6_meng15
mkdir(['./','figs7_s9'])
cd(['./','figs7_s9'])

figure(4)
plot(S.t0,S.y0(:,38).*1e6,'Color','k');
hold on
plot(S.t1+1e3,S.y1(:,38).*1e6,'Color','r');

hold off
ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)');     
  
ylim([0 700])
ax = gca;
ax. Position = [0.2 0.2 0.7 0.7];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',35)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 500 500])
% saveas(gcf,sprintf('%s fig1-4.png',protocol{P}))
print(gcf,fullfile('iso_rel2block'),'-dtiff','-r500');

%% baseline_h_cao1_p3_local_jstocs_1
clear all
close all
cd /Users/meng2/Downloads/Ls_mv_sf6_meng15/baseline_h_cao1_p3_local_jstocs_1
load y175_WT_herz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat

cd ~/downloads/Ls_mv_sf6_meng15
mkdir(['./','fig rebuttal 2'])
cd(['./','fig rebuttal 2'])

% baseline ls_ji_scale
lhs_p = 9;
n = 4;
sf = repmat(1,n,lhs_p);
sf_ls_ji = linspace(10,40,4);
sf_1 = sf_ls_ji'.*sf(:,1);
sf_2 = sf_ls_ji'.*sf(:,2);
sf(:,1) = sf_1;
sf(:,2) = sf_2;
sf = [repmat(1,1,lhs_p); sf];

linestyle = {'-', '-', '-', '-', '-'};
linemarker = {'.', '.', '.', '.', '.'};


for i = 1:size(sf,1)
figure(i)    
plot(S(i).t0,S(i).y0(:,38).*1e6, 'k', 'LineStyle', linestyle(i), 'Marker', linemarker(i), 'DisplayName',['j_{CLC} =', num2str(sf(i,2).*20),', j_{TPC} =', num2str(sf(i,2).*25)]);
legend('location', 'best');hold on
title({'ISO WT_{ }',' '});  
ylabel('[Ca] Cytosol');xlabel('Time (ms)');     
legend boxoff   
ylim([0 800])

ax = gca;
ax. Position = [0.25 0.2 0.65 0.6];
    ax.YAxis.Exponent = 2;
set(gca, 'FontName','Times New Roman','FontSize',40)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 700 700])
print(gcf,fullfile(['ls2iscale_ori_2_', num2str(i)]),'-dtiff','-r500');
close all
end


%%
clear all
close all
cd /Users/meng2/Downloads/Ls_mv_sf6_meng15/baseline_h_cao1_p3_local_jstocs_1/FLUX_
load y175_FLUX_WT_hz1_iso15_naadp=15_Ligtot=0.1_1hz_150beat.mat

cd ~/downloads/Ls_mv_sf6_meng15
mkdir(['./','fig rebuttal 2'])
cd(['./','fig rebuttal 2'])

% baseline ls_ji_scale
lhs_p = 9;
n = 4;
sf = repmat(1,n,lhs_p);
sf_ls_ji = linspace(10,40,4);
sf_1 = sf_ls_ji'.*sf(:,1);
sf_2 = sf_ls_ji'.*sf(:,2);
sf(:,1) = sf_1;
sf(:,2) = sf_2;
sf = [repmat(1,1,lhs_p); sf];

linestyle = {'-', '-', '-', '-', '-'};
linemarker = {'.', '.', '.', '.', '.'};

%             1        2     3       4         5     6     7Total leak                   8 Passive leak only  9             10
% currents = [I_Catot  I_ncx J_serca J_SRCarel Jls2j Jls2i J_SRCarel*Vsr/Vmyo + J_SRleak J_SRleak             I_Ca_tot_junc I_Ca_tot_sl]; 
for i = 1:size(sf,1)
figure(i)
plot(F(i).tArray,F(i).JLS2J.*1e6,  'k', 'LineStyle', linestyle(i), 'Marker', linemarker(i), 'DisplayName',['j_{CLC} =', num2str(sf(i,2).*20),', j_{TPC} =', num2str(sf(i,2).*25)]);
legend('location', 'southeast');hold on
title({'ISO WT_{ }',' '});  
ylabel('J_{ls,up} (nM/ms)');xlabel('Time (ms)');     
legend boxoff   
% ylim([0 800])

ax = gca;
ax. Position = [0.25 0.2 0.65 0.6];
    ax.YAxis.Exponent = 5;
set(gca, 'FontName','Times New Roman','FontSize',40)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 700 700])
print(gcf,fullfile(['ls2iscale_ori_2_jsup_', num2str(i)]),'-dtiff','-r500');
close all
end
%%
close all
for i = 1:size(sf,1)
figure(i)
plot(F(i).tArray,F(i).JLS2I.*1e6,'k', 'LineStyle', linestyle(i), 'Marker', linemarker(i), 'DisplayName',['j_{CLC} =', num2str(sf(i,2).*20),', j_{TPC} =', num2str(sf(i,2).*25)]);
legend('location', 'best');hold on

title({'ISO WT_{ }',' '});  
ylabel('J_{ls,rel} (nM/ms)');xlabel('Time (ms)');     
legend boxoff   
% ylim([-400 50])

ax = gca; 
ax. Position = [0.25 0.2 0.65 0.6];
num1 = [1 1 1 2 2];
    ax.YAxis.Exponent = num1(i);
set(gca, 'FontName','Times New Roman','FontSize',40)
set(findall(gca, 'Type', 'Line'),'LineWidth',2);
set(gca,'box','off')
set(gcf,'Units','pixels','Position',[0 0 700 700])
print(gcf,fullfile(['ls2iscale_ori_2_jlsrel', num2str(i)]),'-dtiff','-r500');
close all
end
