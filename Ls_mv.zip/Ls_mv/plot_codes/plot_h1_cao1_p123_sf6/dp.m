function [amp] = dp(t,y,per)
dy = (y(2:end) - y(1:end-1))./(t(2:end) - t(1:end-1));
% [B,I] = sort(dy,'ascend');
dymax = max(dy);

yflatend = y(end);
[y_max, iymax] = max(y);
[y_min, iymin] = min(y);
begin_t2peakmax = t(iymax);
begin_t2peakmin = t(iymin);
%% find peak

    
if  y_min> 0 %yflatend < y_max
%     [TF, prommax] = islocalmax(y,'MinProminence',abs(y_min*1.2));
    amp = y_max - y_min;
%     y_thresPer= yflatend + amp*(1-per);  % ?
%     iymax= find(TF,1,'first');  % update first peak incase it is not the min promenence
%     TFpeakloc = find(TF==1);
% %     if numel(find(TF==1))>1
% %     x_thresPer = interp1(y(iymax:TFpeakloc(2)), t(iymax:TFpeakloc(2)), y_thresPer);    
% %     else
% %     x_thresPer = interp1(y(iymax:end), t(iymax:end), y_thresPer);
% %     end
%     
% 
%     ypeak = y_max;
%     begin_t2peak = begin_t2peakmax;
%     % find uppeak
% 
% %     numpeak = numel(find(TF ==1));
% %     iuppeak1 = numpeak ~= 1;
%     iuppeak1 = TF;
%     uppeak2 = yflatend>1.2*y_min;
%     iuppeak2 = [zeros(1,length(TF)-1),uppeak2];
%     peaktot = logical(iuppeak1+iuppeak2);
%     
%     numpeak = numel(find(peaktot==1));
%     peakloc = find(peaktot==1);
%     y1stpeakamp = y(peakloc(1)) - y_min;
%     if numpeak > 1
%     y2ndpeakamp = y(peakloc(2)) - y_min;
%     x_thresPer = interp1(y(iymax:peakloc(2)), t(iymax:peakloc(2)), y_thresPer); 
%     tPeak2tendPer = x_thresPer - begin_t2peakmax;
%     else
%         y2ndpeakamp = nan;
%         x_thresPer = interp1(y(iymax:end), t(iymax:end), y_thresPer);
%         tPeak2tendPer = x_thresPer - begin_t2peakmax;
%     end
else
    amp = y_max - y_min;
        % find downpeak
% %     [TF,prommin] = islocalmin(y,'MinProminence',abs(y_max*0.5));
%     [TF,prommin] = islocalmin(y,'MinProminence',abs(y_max*0.2));  %iso 
%     y_thresPer = y_min + amp*(1-per);
%     iymin = find(TF,1,'first');  % update first peak incase it is not the min promenence
%     TFpeakloc = find(TF==1);
% %     if numel(find(TF==1))>1
% %     x_thresPer = interp1(y(iymin:TFpeakloc(2)), t(iymin:TFpeakloc(2)), y_thresPer);
% %     else
% %     x_thresPer = interp1(y(iymin:end), t(iymin:end), y_thresPer);
% %     end
%     
% 
%     ypeak = y_min;
%     begin_t2peak = begin_t2peakmin;
%     idownpeak1 = TF;
%     downpeak2 = yflatend>abs(1.2*y_min);
%     idownpeak2 = [zeros(1,length(TF)-1),downpeak2];
%     peaktot = logical(idownpeak1+idownpeak2);
%   
%     numpeak = numel(find(peaktot==1));
%     peakloc = find(peaktot==1);
%     y1stpeakamp =  y_max -y(peakloc(1));
%     if numpeak > 1
%     y2ndpeakamp = y_max - y(peakloc(2));
%     x_thresPer = interp1(y(iymin:peakloc(2)), t(iymin:peakloc(2)), y_thresPer);
%     tPeak2tendPer = x_thresPer - begin_t2peakmin;
%     else
%         y2ndpeakamp = nan;
%         x_thresPer = interp1(y(iymin:end), t(iymin:end), y_thresPer);
%         tPeak2tendPer = x_thresPer - begin_t2peakmin;
%     end
end
% tPeak2tendPer = NaN;
%     figure(19)
%     plot(t,y,'k',t(TF),y(TF),'r*');
%     hold on
end
