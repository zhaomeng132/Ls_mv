function Fpeak = y31_y36_peakfinder(T,Y,rate1, rate2, y36)







%% method 5
% Fpeak.sumY = sum(Y.*T)/numel(T);
% Fpeak.sum_y31_y36 = sum(Y.*T)/numel(T) - sum(y36.*T)/numel(T);
%% method 4
% Y1 = (Y(2:end) - Y(2-1:end-1))./(T(2:end) - T(2-1:end-1));
% Y1 = [0; Y1];
% y36_1 = (y36(2:end) - y36(2-1:end-1))./(T(2:end) - T(2-1:end-1));
% y36_1 = [0; y36_1];
% 
% Fpeak.sumY = trapz(T, Y1);
% Fpeak.sum_y31_y36 = trapz(T, Y1) - trapz(T, y36_1);
%% method 3
% Fpeak.sumY = trapz(T, Y);
% Fpeak.sum_y31_y36 = trapz(T, Y) - trapz(T, y36);
%% method 2
% Fpeak.sumY = trapz(T, Y);
% Fpeak.sum_y31_y36 = trapz(T, Y) - trapz(T, y36);
%% method 1
[TFmin3w,~] = islocalmin(abs(Y),'MinProminence',max(abs(Y))/rate1);
if abs(Y(end)) > max(abs(Y))*1.3
TFmin3w(end) = 1;
end 
peakidx = find(TFmin3w);
[TFmax3w,~] = islocalmax(abs(Y),'MinProminence',max(abs(Y))/rate2);
valleyidx = find(TFmax3w);

% find the main before 200ms
[~, T200_id] = min(abs(T- 200));
% Y300 = Y(T300_id);
% T300_idx = find(Y == Y300);
peakidx_beforeT200 = peakidx(find(peakidx < T200_id)); % 1 or >1
if isempty(peakidx_beforeT200)
peakidx_beforeT200 = 1;
% Fpeak.peakidx_beforeT200 = peakidx_beforeT200; % if no first peak, there must be a previous dad peak peaking at or before the beat start 
else   
peakidx_beforeT200 = peakidx_beforeT200(end); % for >1, use the last
% Fpeak.peakidx_beforeT200 = peakidx_beforeT200; 
end

% Fpeak.peakI = peakidx_beforeT200;

% find extra peaks id after the main before 200ms
dadid = peakidx(find(peakidx > peakidx_beforeT200));

% find extra valleys id after main      
valleyidx = valleyidx(find(valleyidx > peakidx_beforeT200));  

    % find extra valleys id after 190ms
    [~, T190_id] = min(abs(T- 190));                             % modify 22.02.23, before 200
    valleyidx = valleyidx(find(valleyidx > T190_id)); 

if isempty(valleyidx)
    
% Y1 = Y(T200_id:end);                                           % option 3
% T1 = T(T200_id:end);
% dY1 = (Y1(2:end) - Y1(1:end-1))./(T1(2:end) - T1(1:end-1));    
% approx_valley = find(dY1 > 100, 1, 'last'); 
% dY2 = dY1(approx_valley-1:end);
% % valleyid = peakidx_beforeT300 + approx_valley -1;
% approx_valley2 = find(dY2 < 10, 1); 
% valleyid = T200_id + approx_valley -1 + approx_valley2 -1;
% if isempty(valleyid)
% valleyid = numel(T) -1;    
% end

Y_decay = Y(peakidx_beforeT200:end);                             % option 2, method 1
[~, iminY_decay] = min(abs(Y_decay-Y(1)));
valleyid = peakidx_beforeT200 + iminY_decay -1; % modify 29 jun 
if valleyid == numel(T)
valleyid = valleyid -1; 
end   

%     valleyid = numel(T) -1;                                    % option 1

else    
% find the largest valley id
valleylist = Y(valleyidx);
[~, ivalley] = max(valleylist);
valleyid = valleyidx(ivalley);
end                                          
    
% Fpeak.valleyI = valleyid;  
% Fpeak.valleyY = Y(valleyid);  
% Fpeak.initialY = Y(1);  
% Fpeak.val_iniY = Y(valleyid)-Y(1);
% 
% Fpeak.valleyIlist = valleyidx;
% Fpeak.valleyTlist = T(valleyidx); 

% peak integral
[peakmaxY,~] = max([Y(valleyid),Y(1)]);                              % option 3, method 1
yline  = linspace(peakmaxY,peakmaxY,numel(Y(1:valleyid)));

% yline  = linspace(Y(valleyid),Y(valleyid),numel(Y(1:valleyid)));   % option 2
% yline  = linspace(Y(1),Y(valleyid),numel(Y(1:valleyid)));          % option 1

xline = linspace(T(1),T(valleyid),numel(T(1:valleyid)));
peak_integral = trapz(xline, yline) - trapz(T(1:valleyid),Y(1:valleyid));
% dad integral
[dadmaxY,~] = max([Y(valleyid),Y(end)]);
yline  = linspace(dadmaxY,dadmaxY,numel(Y(valleyid:end)));
xline = linspace(T(valleyid),T(end),numel(T(valleyid:end)));
dad_integral = trapz(xline, yline) - trapz(T(valleyid:end),Y(valleyid:end));

Fpeak.sumY = peak_integral + dad_integral;                           % y31 SR, method 1

y31_y36_dad_integral = dad_integral - trapz(T(valleyid:end),y36(valleyid:end));

y31_y36_peak_integral = peak_integral - trapz(T(1:valleyid),y36(1:valleyid));

Fpeak.sum_y31_y36 = y31_y36_dad_integral + y31_y36_peak_integral;    % y31-y36 SR-junction, method 1
end