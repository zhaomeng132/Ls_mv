clear all
close all

cd ~/downloads/SS/Ls_mv_sf6
load h1_cao1_sf1000_sf6_0.mat

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_WT_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S3w = S;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_i_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S3o = S;

cd ~/downloads/SS/Ls_mv_sf6/h1_cao1dot8_p3_arc
load y175_j_dot0_iso15_naadp=15_Ligtot=0.1_WT_1hz_150beat.mat
S = S(h1_cao1_sf1000_sf6_0);
S3j = S;


cd ~/downloads/SS/Ls_mv_sf6/

%%
clear bump_w bump_o bump_j
bump_w_2peak = [];
bump_o_2peak = [];
bump_w_3peak = [];
bump_o_3peak = [];
for ica = 1: numel(S3w)
y3w = S3w(ica).y(:,38).*1e6;
t3w = S3w(ica).t;
y3o = S3o(ica).y(:,38).*1e6;
t3o = S3o(ica).t;
% y3j = S3j(ica).y(:,38).*1e6;
% t3j = S3j(ica).t;

rate0 = 200; % 200
rate1 = 1.3 ; % 1.3
bump_rate = 0.20; % 0.16
% wt
[TF3w,~] = islocalmax(y3w,'MinProminence',max(y3w)/rate0);
idw = find(TF3w); 

if y3w(end) > min(y3w)*rate1
  TF3w(end) = 1;
end

% 1 find bump scr when peak number equals 2, based on peaks of 3 at largest
if numel(idw) == 2 && (y3w(idw(2)) - min(y3w))/(max(y3w) - min(y3w))< bump_rate && t3w(idw(2)) < 500+t3w(1)
   bump_w_2peak = [bump_w_2peak,ica];
end

    % peaks of 3 at largest modify 15.02.23 
%     if numel(idw) >= 3
%        bump_w_3peak = [bump_w_3peak,ica];
%     end
% 2 find bump scr when peak number equals 3, based on peaks of 3 at largest
if numel(idw) == 3 && (y3w(idw(2)) - min(y3w))/(max(y3w) - min(y3w))< bump_rate && t3w(idw(2)) < 500+t3w(1)
   bump_w_3peak = [bump_w_3peak,ica];
end

T3w(ica) = numel(find(TF3w));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% idot0
[TF3o,~] = islocalmax(y3o,'MinProminence',max(y3o)/rate0); %300
ido = find(TF3o);

if y3o(end) > min(y3o)*rate1 % 1.3
TF3o(end) = 1;
end

% 1 find bump scr when peak number equals 2, based on peaks of 3 at largest
if numel(ido) == 2 && (y3o(ido(2)) - min(y3o))/(max(y3o) - min(y3o))< bump_rate && t3o(ido(2)) < 500+t3o(1)
   bump_o_2peak = [bump_o_2peak, ica];
end

    % peaks of 3 at largest modify 15.02.23 
%     if numel(ido) >= 3
%        bump_o_3peak = [bump_o_3peak,ica];
%     end
% 2 find bump scr when peak number equals 3, based on peaks of 3 at largest
if numel(ido) == 3 && (y3o(ido(2)) - min(y3o))/(max(y3o) - min(y3o))< bump_rate && t3o(ido(2)) < 500+t3o(1)
   bump_o_3peak = [bump_o_3peak,ica];
end
    
T3o(ica) = numel(find(TF3o));

end

cao18_w_1 = find(T3w>=2);
cao18_w_0 = find(T3w<2);  % cross check

cao18_i_1 = find(T3o>=2);
cao18_i_0 = find(T3o<2); % cross check

% modify 14.02.23
%nobump, excluding the bump peak as 2nd peak in traces with 2 or 3 peaks
bump_w = [bump_w_2peak, bump_w_3peak];    % 46
bump_o = [bump_o_2peak, bump_o_3peak];    % 29
bump_w_o = unique([bump_w,bump_o]);

cao18_w_1 = cao18_w_1(find(ismember(cao18_w_1,bump_w)~=1));
cao18_i_1 = cao18_i_1(find(ismember(cao18_i_1,bump_o)~=1)); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% cao18_w1_ratio = numel(cao18_w_1)/numel(h1_cao1_sf1000_sf6_0);
% cao18_i1_ratio = numel(cao18_i_1)/numel(h1_cao1_sf1000_sf6_0);

% 1
cao1dot8_iTPC_1 = intersect(cao18_w_1, cao18_i_0);
cd ~/downloads/SS/Ls_mv_sf6/
save('cao1dot8_iTPC_1.mat','cao1dot8_iTPC_1');

% 2
cao1dot8_inoneTPC_1 = intersect(cao18_w_1,cao18_i_1);
save('cao1dot8_inoneTPC_1.mat','cao1dot8_inoneTPC_1');

% 3
cao1dot8_inone_0 = intersect(cao18_w_0,cao18_i_0);
save('cao1dot8_inone_0.mat','cao1dot8_inone_0');

% 4 
cao1dot8_woi1 = intersect(cao18_w_0, cao18_i_1);

% check total number
numel([cao1dot8_iTPC_1, cao1dot8_inoneTPC_1, cao1dot8_inone_0, cao1dot8_woi1, bump_w_o])
%% find the rest
% cao1dot8_tot = sort([cao1dot8_iTPC_1, cao1dot8_inoneTPC_1, cao1dot8_inone_0]);
% 
% linspace_423 = linspace(1,423,423);
% % A not in a
% rest1 = linspace_423(find(ismember(linspace_423, cao1dot8_tot)~=1));
% 
% rest2 = rest1(find(ismember(rest1,bump_w_o)~=1))
%% plot traces of 3 peaks

sf343_scr = [];
for ip = 1:numel(sf343_scr)

figure(1);
ax1 = subplot(1,1,1);
plot(S3w(sf343_scr(ip)).t,S3w(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

figure(2);
ax2 = subplot(1,1,1);
plot(S3o(sf343_scr(ip)).t,S3o(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

end

%% non-TPC
cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','traces'])
cd(['./','traces'])

close all
sf343_scr = [cao1dot8_inoneTPC_1];
for ip = 1:numel(sf343_scr)

figure(1);
ax1 = subplot(1,1,1);
plot(S3w(sf343_scr(ip)).t,S3w(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

figure(2);
ax2 = subplot(1,1,1);
plot(S3o(sf343_scr(ip)).t,S3o(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

end

linkaxes([ax1,ax2],'y');
f60 = figure(1);
ax1 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, WT_{}','non-TPC-specific'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(2);
ax2 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, J_{ls,rel} = 0','non-TPC-specific'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'sw_y38_non-TPC'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'si_y38_non-TPC'),'-dtiff','-r300');

%% none
cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','traces'])
cd(['./','traces'])

close all
sf343_scr = [cao1dot8_inone_0];
for ip = 1:numel(sf343_scr)

figure(1);
ax1 = subplot(1,1,1);
plot(S3w(sf343_scr(ip)).t,S3w(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

figure(2);
ax2 = subplot(1,1,1);
plot(S3o(sf343_scr(ip)).t,S3o(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

end

linkaxes([ax1,ax2],'y');
f60 = figure(1);
ax1 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, WT_{}','non-arrhythmic'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(2);
ax2 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, J_{ls,rel} = 0','non-arrhythmic'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'sw_y38_none'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'si_y38_none'),'-dtiff','-r300');

%% TPC
cd ~/downloads/SS/Ls_mv_sf6
mkdir(['./','traces'])
cd(['./','traces'])

close all
sf343_scr = [cao1dot8_iTPC_1];
for ip = 1:numel(sf343_scr)

figure(1);
ax1 = subplot(1,1,1);
plot(S3w(sf343_scr(ip)).t,S3w(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

figure(2);
ax2 = subplot(1,1,1);
plot(S3o(sf343_scr(ip)).t,S3o(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

end

linkaxes([ax1,ax2],'y');
f60 = figure(1);
ax1 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, WT_{}','TPC-specific'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f60,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f60, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f60,'type','axes'),'box','off')
    set(f60,'Units','pixels','Position',[0 0 700 500])

f61 = figure(2);
ax2 = subplot(1,1,1);ylabel('[Ca] Cytosol (nM)');xlabel('Time (ms)'); 
title({'Hypercalcemia and ISO, J_{ls,rel} = 0','TPC-specific'});
% title({' ',' '})
    ax = gca;
%     ax. Position = [0.2 0.2 0.7 0.7];
ax.YAxis.Exponent = 2;
    set(findobj(f61,'type','axes'),'FontName','Times New Roman','FontSize',35)
    set(findobj(f61, 'Type', 'Line'),'LineWidth',2);
    set(findobj(f61,'type','axes'),'box','off')
    set(f61,'Units','pixels','Position',[0 0 700 500])

print(f60, fullfile(pwd, 'sw_y38_TPC'),'-dtiff','-r300');
print(f61, fullfile(pwd, 'si_y38_TPC'),'-dtiff','-r300');

%% jdot0 id 1 343
for ip = 1:numel(cao1dot8_iTPC_1)

% figure(3);
% plot(S3j(sf343_scr(ip)).t,S3j(sf343_scr(ip)).y(:,38).*1e6,'Color' , '#000000');
% % legend
% hold on

y3j = S3j(cao1dot8_iTPC_1(ip)).y;
t3j = S3j(cao1dot8_iTPC_1(ip)).t;
rate0 = 200; % 200
rate1 = 1.3; % 1.3

[TF3j,~] = islocalmax(y3j(:,38),'MinProminence',max(y3j(:,38))/rate0); %300

id = find(TF3j);

if y3j(end,38) > min(y3j(:,38))*rate1 % 1.3
TF3j(end) = 1;
end

T3j_sf343_scr(ip) = numel(find(TF3j));

end 
% id 1 -cao1dot8_iTPC_1
cao1dot8_iTPC1_j1 = find(T3j_sf343_scr>=2);

% id 1 - 343
cao1dot8_iTPC_1_jdot_1 = cao1dot8_iTPC_1(cao1dot8_iTPC1_j1);
cao1dot8_iTPC_1_jdot_0 = cao1dot8_iTPC_1(find(ismember(cao1dot8_iTPC_1,cao1dot8_iTPC_1_jdot_1)~=1));

cao1dot8_iTPC1_j1_per = numel(cao1dot8_iTPC_1_jdot_1) / numel(cao1dot8_iTPC_1)

% if ls buffer lost, scr ls2j be only in the tpc-specific

cd ~/downloads/SS/Ls_mv_sf6/
save('cao1dot8_iTPC_1_jdot_1.mat','cao1dot8_iTPC_1_jdot_1');
save('cao1dot8_iTPC_1_jdot_0.mat','cao1dot8_iTPC_1_jdot_0');


%%
% ls_dadtot = h1_p3_wt(find(ismember(h1_p3_wt,h1_p3_tpcko)~=1));
% cao1dot8_p3_wyno_sf343_rate1_3 = ls_dadtot;
% % cd ~/downloads/SS/h1_cao1dot8_p3_/
% % save('cao1dot8_p3_wyno_sf343_rate1_3.mat','cao1dot8_p3_wyno_sf343_rate1_3');
% sf343_scr = cao1dot8_p3_wyno_sf343_rate1_3;
%% plot scr wt
% close all
% for ip = 1:numel(h1_p3_wt)
% 
% figure(1);
% plot(S3w(h1_p3_wt(ip)).t,S3w(h1_p3_wt(ip)).y(:,38).*1e6,'Color' , '#000000');
% %     legend
% hold on
% % pause(0.5)
% 
% end
% 
% % idot0 
% for ip = 1:numel(h1_p3_tpcko)
% 
% figure(2);
% plot(S3o(h1_p3_tpcko(ip)).t,S3o(h1_p3_tpcko(ip)).y(:,38).*1e6,'Color' , '#000000');
% %     legend
% hold on
% 
% end

%%
% jdot0 
sr_num = cao1dot8_iTPC_1_jdot_1;
for ip = 1:numel(sr_num)

figure(2);
plot(S3j(sr_num(ip)).t,S3j(sr_num(ip)).y(:,38).*1e6,'Color' , '#000000');hold on

end
%% plot bump
% for ip = 1:numel(ls_dadtot_bump)
% 
% figure(1);
% plot(S3w(ls_dadtot_bump(ip)).t,S3w(ls_dadtot_bump(ip)).y(:,38).*1e6,'Color' , '#000000');
% %     legend
% hold on
% % pause(0.5)
% 
% end
% 
% for ip = 1:numel(ls_dadtot_bump)
% 
% figure(2);
% plot(S3o(ls_dadtot_bump(ip)).t,S3o(ls_dadtot_bump(ip)).y(:,38).*1e6,'Color' , '#000000');
% %     legend
% hold on
% 
% end
cd ~/downloads/SS/Ls_mv_sf6/traces

inoneTPC_1= cao1dot8_inoneTPC_1;
iTPC_1 = cao1dot8_iTPC_1;
inone_0 = cao1dot8_inone_0;

rng('default');                 % for reproducibility of results
lhs_p = 9;                      % number of parameters
lhs_n = 1000;                     % number of models (combinations)  
X0 = lhsdesign(lhs_n,lhs_p);    % generate normalised sampling (in [0,1])
lb = repmat(0.5,1,lhs_p);       % lower scaling bounds (can be different)
ub = repmat(2,1,lhs_p);         % upper scaling bounds (can be different)
sf = bsxfun(@plus,bsxfun(@times,X0,ub-lb),lb);
sf = sf(h1_cao1_sf1000_sf6_0,:);

% index 0 - 343

sf_noneTPC_1 = sf(inoneTPC_1,:);
sf_TPC_1 = sf(iTPC_1,:);
sf_none_0 = sf(inone_0,:);

close all

bx = [
     sf_noneTPC_1(:,1);sf_TPC_1(:,1);sf_none_0(:,1);...
     sf_noneTPC_1(:,2);sf_TPC_1(:,2);sf_none_0(:,2);...
     sf_noneTPC_1(:,3);sf_TPC_1(:,3);sf_none_0(:,3);...
     sf_noneTPC_1(:,4);sf_TPC_1(:,4);sf_none_0(:,4);...
     sf_noneTPC_1(:,5);sf_TPC_1(:,5);sf_none_0(:,5);...
     sf_noneTPC_1(:,6);sf_TPC_1(:,6);sf_none_0(:,6);...
     sf_noneTPC_1(:,7);sf_TPC_1(:,7);sf_none_0(:,7);...
     sf_noneTPC_1(:,8);sf_TPC_1(:,8);sf_none_0(:,8);...
     sf_noneTPC_1(:,9);sf_TPC_1(:,9);sf_none_0(:,9);...
     ];
 
 
by = [ zeros(length(sf_noneTPC_1), 1);1*ones(length([sf_TPC_1]), 1);2*ones(length([sf_none_0]), 1);... 
       3*ones(length([sf_noneTPC_1]), 1);4*ones(length([sf_TPC_1]), 1);5*ones(length([sf_none_0]), 1);... 
       6*ones(length([sf_noneTPC_1]), 1);7*ones(length([sf_TPC_1]), 1);8*ones(length([sf_none_0]), 1);... 
       9*ones(length([sf_noneTPC_1]), 1);10*ones(length([sf_TPC_1]), 1);11*ones(length([sf_none_0]), 1);...
       12*ones(length([sf_noneTPC_1]), 1);13*ones(length([sf_TPC_1]), 1);14*ones(length([sf_none_0]), 1);... 
       15*ones(length([sf_noneTPC_1]), 1);16*ones(length([sf_TPC_1]), 1);17*ones(length([sf_none_0]), 1);...
       18*ones(length([sf_noneTPC_1]), 1);19*ones(length([sf_TPC_1]), 1);20*ones(length([sf_none_0]), 1);...
       21*ones(length([sf_noneTPC_1]), 1);22*ones(length([sf_TPC_1]), 1);23*ones(length([sf_none_0]), 1);...
       24*ones(length([sf_noneTPC_1]), 1);25*ones(length([sf_TPC_1]), 1);26*ones(length([sf_none_0]), 1);...
     ];

figure(1);
boxplot(bx,by,'Notch','on','Colors','rbm');
c = findobj(gca,'Tag','Box');
ylabel({'Variations of Conductances'})
ylim([0.5 3])
set(gca,'TickLabelInterpreter','Tex')
lbl= {'J_{ls,up}','J_{ls,rel}','J_{ls,lk}','J_{SERCA}','J_{RyR}','I_{NCX}','I_{CaL}','I_{to}','I_{Kr}'};
set(gca,'xticklabel',lbl)
set(gca,'xtick',2:3:26)
set(gca,'ytick',0.5:0.5:2)
set(gca,'box','off');
legend([c(3);c(2);c(1)],'Pro-arrhythmic: others','Pro-arrhythmic: TPC-specific','Non-pro-arrhythmic','Location','northeast');legend boxoff
 
set(gca, 'FontName','Times New Roman','FontSize',35)
% title({'Hypercalcemia and ISO',' '})
title({' ',' '})
set(findall(gcf, 'Type', 'Line'),'LineWidth',2);
set(gcf,'Units','pixels','Position',[0 0 1500 500])
print(gcf, fullfile(pwd, '1'),'-dpng','-r300')
% close
